<?php if ( is_active_sidebar( 'blog-sidebar' ) ) : ?>
	<aside class="sidebar widget-area">
		<?php	dynamic_sidebar( 'blog-sidebar' ); ?>
	</aside>
<?php endif; ?>
