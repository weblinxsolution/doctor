<?php

/**
 * Theme Constants
 */
$theme         = wp_get_theme();
$theme_version = $theme->get( 'Version' );

// Try to get the parent theme object
$theme_parent = $theme->parent();

// Set current theme version as parent not child
if ( $theme_parent ) {
	$theme_version = $theme_parent->Version;
}

define( 'ARTS_THEME_SLUG', 'kinsey' );
define( 'ARTS_THEME_PATH', get_template_directory() );
define( 'ARTS_THEME_URL', get_template_directory_uri() );
define( 'ARTS_THEME_PLUGINS_REMOTE_SOURCE', true );
define( 'ARTS_THEME_VERSION', $theme_version );

require_once ARTS_THEME_PATH . '/inc/constants.php';

/**
 * Polyfills
 */
require_once ARTS_THEME_PATH . '/inc/polyfills/get_page_by_title.php';

/**
* ACF: Registered Fields & Helpers
*/
require_once ARTS_THEME_PATH . '/inc/acf/acf_fields.php';
require_once ARTS_THEME_PATH . '/inc/acf/acf_helpers.php';

/**
 * Autoptimize plugin
 */
require_once ARTS_THEME_PATH . '/inc/autoptimize/autoptimize_filter_html_noptimize.php';
require_once ARTS_THEME_PATH . '/inc/autoptimize/autoptimize_filter_js_exclude.php';

/**
 * Blog
 */
require_once ARTS_THEME_PATH . '/inc/blog/add_pingback_url.php';
require_once ARTS_THEME_PATH . '/inc/blog/ajax_post_comment.php';
require_once ARTS_THEME_PATH . '/inc/blog/blog_filter_is_active.php';
require_once ARTS_THEME_PATH . '/inc/blog/comments.php';
require_once ARTS_THEME_PATH . '/inc/blog/get_post_author.php';
require_once ARTS_THEME_PATH . '/inc/blog/get_post_categories.php';
require_once ARTS_THEME_PATH . '/inc/blog/pagination.php';
require_once ARTS_THEME_PATH . '/inc/blog/password_form.php';
require_once ARTS_THEME_PATH . '/inc/blog/query_posts.php';
require_once ARTS_THEME_PATH . '/inc/blog/wrap_category_archive_count.php';

/**
 * Header Footer Elementor plugin
 */
require_once ARTS_THEME_PATH . '/inc/hfe/hfe_helpers.php';
require_once ARTS_THEME_PATH . '/inc/hfe/hfe_render_header.php';
require_once ARTS_THEME_PATH . '/inc/hfe/hfe_render_footer.php';

/**
 * Elementor Helpers
 */
require_once ARTS_THEME_PATH . '/inc/elementor/elementor_canvas_template.php';
require_once ARTS_THEME_PATH . '/inc/elementor/elementor_compatibility.php';
require_once ARTS_THEME_PATH . '/inc/elementor/elementor_custom_icons.php';
require_once ARTS_THEME_PATH . '/inc/elementor/elementor_helpers.php';

/**
 * Footer Widget Area
 */
require_once ARTS_THEME_PATH . '/inc/footer/has_footer_active_sidebars.php';

/**
 * Theme Helpers & Enhancements
 */
require_once ARTS_THEME_PATH . '/inc/markup/get_split_text_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_header_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_hfe_header_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_hfe_footer_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_main_container_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_footer_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_animation_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_animation_inner_outer_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_button_attributes.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_cursor_attributes_theme_mod.php';
require_once ARTS_THEME_PATH . '/inc/markup/get_cursor_attributes.php';

require_once ARTS_THEME_PATH . '/inc/helpers/print_attributes.php';
require_once ARTS_THEME_PATH . '/inc/helpers/parse_args_recursive.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_all_image_sizes.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_parallax_attributes.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_mask_attributes.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_lazy_image_attributes.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_taxonomy_term_names.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_header_layout.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_woocommerce_urls.php';
require_once ARTS_THEME_PATH . '/inc/helpers/is_referer_from_same_domain.php';
require_once ARTS_THEME_PATH . '/inc/helpers/is_preloader_enabled.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_page_titles.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_post_looped.php';
require_once ARTS_THEME_PATH . '/inc/helpers/get_post_looped_overridden.php';

/**
 * Frontend Styles & Scripts
 */
require_once ARTS_THEME_PATH . '/inc/frontend/enqueue_block_widgets_assets.php';
require_once ARTS_THEME_PATH . '/inc/frontend/enqueue_theme_assets.php';
require_once ARTS_THEME_PATH . '/inc/frontend/enqueue_bottom_nav_assets.php';
require_once ARTS_THEME_PATH . '/inc/frontend/enqueue_preview_assets.php';
require_once ARTS_THEME_PATH . '/inc/frontend/localize_data.php';

/**
 * Additional body classes
 */
require_once ARTS_THEME_PATH . '/inc/core/add_body_classes.php';

/**
 * BC for "body_open" function
 */
require_once ARTS_THEME_PATH . '/inc/core/body_open.php';

/**
 * Load Required Plugins
 */
require_once ARTS_THEME_PATH . '/inc/core/load_plugins.php';

/**
 * Nav Menu
 */
require_once ARTS_THEME_PATH . '/inc/core/navigation.php';

/**
 * Theme Support Features
 */
require_once ARTS_THEME_PATH . '/inc/core/theme_support.php';

/**
 * Widget Areas
 */
require_once ARTS_THEME_PATH . '/inc/core/widget_areas.php';

/**
 * Contact Form 7 plugin
 */
require_once ARTS_THEME_PATH . '/inc/contact-form-7/unwrap_form_fields.php';

/**
 * WPForms: Force enable "Load Assets Globally" option if AJAX is on
 */
require_once ARTS_THEME_PATH . '/inc/wpforms/wpforms.php';

/**
 * Customizer Extension
 */
require_once ARTS_THEME_PATH . '/inc/customizer/customizer.php';

/**
 * Demo Import
 */
require_once ARTS_THEME_PATH . '/inc/import/import.php';

/**
 * Remove rendering of SVG duotone filters
 */
require_once ARTS_THEME_PATH . '/inc/core/remove_duotone_filters.php';

