<?php

/**
 * Hide ACF Menu
 */
add_filter( 'acf/settings/show_admin', '__return_false' );

if ( function_exists( 'acf_add_local_field_group' ) ) {

	// Additional content
	acf_add_local_field_group(
		array(
			'key'                   => 'group_612f76979e311',
			'title'                 => esc_html__( 'Additional Content', 'kinsey' ),
			'fields'                => array(
				array(
					'key'               => 'field_612f77bd82c99',
					'label'             => esc_html__( 'Properties', 'kinsey' ),
					'name'              => 'properties',
					'type'              => 'repeater',
					'instructions'      => '',
					'required'          => 0,
					'conditional_logic' => 0,
					'wrapper'           => array(
						'width' => '',
						'class' => '',
						'id'    => '',
					),
					'collapsed'         => '',
					'min'               => 0,
					'max'               => 0,
					'layout'            => 'table',
					'button_label'      => '',
					'sub_fields'        => array(
						array(
							'key'               => 'field_612f77e982c9a',
							'label'             => esc_html__( 'Name', 'kinsey' ),
							'name'              => 'name',
							'type'              => 'text',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'default_value'     => '',
							'placeholder'       => '',
							'prepend'           => '',
							'append'            => '',
							'maxlength'         => '',
						),
						array(
							'key'               => 'field_612f782082c9b',
							'label'             => esc_html__( 'Value', 'kinsey' ),
							'name'              => 'value',
							'type'              => 'text',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'default_value'     => '',
							'placeholder'       => '',
							'prepend'           => '',
							'append'            => '',
							'maxlength'         => '',
						),
					),
				),
				array(
					'key'               => 'field_612f78c215a3f',
					'label'             => esc_html__( 'Subheading', 'kinsey' ),
					'name'              => 'subheading',
					'type'              => 'text',
					'instructions'      => '',
					'required'          => 0,
					'conditional_logic' => 0,
					'wrapper'           => array(
						'width' => '',
						'class' => '',
						'id'    => '',
					),
					'default_value'     => '',
					'placeholder'       => '',
					'prepend'           => '',
					'append'            => '',
					'maxlength'         => '',
				),
				array(
					'key'               => 'field_612f786f5cba5',
					'label'             => esc_html__( 'Description', 'kinsey' ),
					'name'              => 'description',
					'type'              => 'textarea',
					'instructions'      => '',
					'required'          => 0,
					'conditional_logic' => 0,
					'wrapper'           => array(
						'width' => '',
						'class' => '',
						'id'    => '',
					),
					'default_value'     => '',
					'placeholder'       => '',
					'maxlength'         => '',
					'rows'              => '',
					'new_lines'         => '',
				),
				array(
					'key'               => 'field_612f83362ce48',
					'label'             => esc_html__( 'Buttons', 'kinsey' ),
					'name'              => 'buttons',
					'type'              => 'repeater',
					'instructions'      => '',
					'required'          => 0,
					'conditional_logic' => 0,
					'wrapper'           => array(
						'width' => '',
						'class' => '',
						'id'    => '',
					),
					'collapsed'         => '',
					'min'               => 0,
					'max'               => 0,
					'layout'            => 'table',
					'button_label'      => '',
					'sub_fields'        => array(
						array(
							'key'               => 'field_612f83692ce49',
							'label'             => esc_html__( 'Button', 'kinsey' ),
							'name'              => 'button',
							'type'              => 'link',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'return_format'     => 'array',
						),
						array(
							'key'               => 'field_619b3f65d6fe7',
							'label'             => esc_html__( 'Appearance', 'kinsey' ),
							'name'              => 'button_appearance',
							'type'              => 'group',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'layout'            => 'block',
							'sub_fields'        => array(
								array(
									'key'               => 'field_619b3fd2d6fe8',
									'label'             => esc_html__( 'Style', 'kinsey' ),
									'name'              => 'button_style',
									'type'              => 'select',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => 0,
									'wrapper'           => array(
										'width' => '',
										'class' => '',
										'id'    => '',
									),
									'choices'           => array(
										''              => esc_html__( 'Normal', 'kinsey' ),
										'button-circle' => esc_html__( 'Circle Small', 'kinsey' ),
										'button-circle button-circle_medium' => esc_html__( 'Circle Medium', 'kinsey' ),
										'button-circle button-circle_big' => esc_html__( 'Circle Big', 'kinsey' ),
									),
									'default_value'     => 'button-normal',
									'allow_null'        => 0,
									'multiple'          => 0,
									'ui'                => 0,
									'return_format'     => 'value',
									'ajax'              => 0,
									'placeholder'       => '',
								),
								array(
									'key'               => 'field_619b4029d6fe9',
									'label'             => esc_html__( 'Border', 'kinsey' ),
									'name'              => 'button_border',
									'type'              => 'select',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => 0,
									'wrapper'           => array(
										'width' => '',
										'class' => '',
										'id'    => '',
									),
									'choices'           => array(
										'button_solid'    => esc_html__( 'Solid', 'kinsey' ),
										'button_bordered' => esc_html__( 'Bordered', 'kinsey' ),
									),
									'default_value'     => 'button_bordered',
									'allow_null'        => 0,
									'multiple'          => 0,
									'ui'                => 0,
									'return_format'     => 'value',
									'ajax'              => 0,
									'placeholder'       => '',
								),
								array(
									'key'               => 'field_619b40d4d6fea',
									'label'             => esc_html__( 'Color', 'kinsey' ),
									'name'              => 'button_color',
									'type'              => 'select',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => 0,
									'wrapper'           => array(
										'width' => '',
										'class' => '',
										'id'    => '',
									),
									'choices'           => ARTS_THEME_COLORS_ARRAY,
									'default_value'     => '',
									'allow_null'        => 0,
									'multiple'          => 0,
									'ui'                => 0,
									'return_format'     => 'value',
									'ajax'              => 0,
									'placeholder'       => '',
								),
							),
						),
						array(
							'key'               => 'field_619b4786228d1',
							'label'             => esc_html__( 'Interactive Cursor', 'kinsey' ),
							'name'              => 'button_cursor',
							'type'              => 'group',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'layout'            => 'block',
							'sub_fields'        => array(
								array(
									'key'               => 'field_619b47bd4444f',
									'label'             => esc_html__( 'Enable Cursor', 'kinsey' ),
									'name'              => 'cursor_button_enabled',
									'type'              => 'true_false',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => 0,
									'wrapper'           => array(
										'width' => '',
										'class' => '',
										'id'    => '',
									),
									'message'           => '',
									'default_value'     => 0,
									'ui'                => 1,
									'ui_on_text'        => '',
									'ui_off_text'       => '',
								),
								array(
									'key'               => 'field_619b482f44450',
									'label'             => esc_html__( 'Scale', 'kinsey' ),
									'name'              => 'cursor_button_scale_selector',
									'type'              => 'select',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => array(
										array(
											array(
												'field'    => 'field_619b47bd4444f',
												'operator' => '==',
												'value'    => '1',
											),
										),
									),
									'wrapper'           => array(
										'width' => '',
										'class' => '',
										'id'    => '',
									),
									'choices'           => array(
										'current'    => esc_html__( 'By Element\'s Width or Height', 'kinsey' ),
										'multiplier' => esc_html__( 'By Multiplier', 'kinsey' ),
									),
									'default_value'     => false,
									'allow_null'        => 1,
									'multiple'          => 0,
									'ui'                => 0,
									'return_format'     => 'value',
									'ajax'              => 0,
									'placeholder'       => '',
								),
								array(
									'key'               => 'field_619b4937b6fe3',
									'label'             => esc_html__( 'Scale Multiplier', 'kinsey' ),
									'name'              => 'cursor_button_scale',
									'type'              => 'range',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => array(
										array(
											array(
												'field'    => 'field_619b47bd4444f',
												'operator' => '==',
												'value'    => '1',
											),
											array(
												'field'    => 'field_619b482f44450',
												'operator' => '==',
												'value'    => 'multiplier',
											),
										),
									),
									'wrapper'           => array(
										'width' => '',
										'class' => '',
										'id'    => '',
									),
									'default_value'     => '1.0',
									'min'               => '0.0',
									'max'               => '4.0',
									'step'              => '0.1',
									'prepend'           => '',
									'append'            => 'x',
								),
								array(
									'key'               => 'field_619b49c046f59',
									'label'             => esc_html__( 'Hide Native Cursor', 'kinsey' ),
									'name'              => 'cursor_button_hide_native_enabled',
									'type'              => 'true_false',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => array(
										array(
											array(
												'field'    => 'field_619b47bd4444f',
												'operator' => '==',
												'value'    => '1',
											),
										),
									),
									'wrapper'           => array(
										'width' => '',
										'class' => '',
										'id'    => '',
									),
									'default_value'     => 0,
									'message'           => '',
									'ui'                => 0,
									'ui_on_text'        => '',
									'ui_off_text'       => '',
								),
								array(
									'key'               => 'field_619b49f3950b3',
									'label'             => esc_html__( 'Enable Magnetic Effect', 'kinsey' ),
									'name'              => 'cursor_button_magnetic_enabled',
									'type'              => 'true_false',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => array(
										array(
											array(
												'field'    => 'field_619b47bd4444f',
												'operator' => '==',
												'value'    => '1',
											),
										),
									),
									'wrapper'           => array(
										'width' => '',
										'class' => '',
										'id'    => '',
									),
									'default_value'     => 0,
									'message'           => '',
									'ui'                => 0,
									'ui_on_text'        => '',
									'ui_off_text'       => '',
								),
							),
						),
					),
				),
			),
			'location'              => array(
				array(
					array(
						'param'    => 'post_type',
						'operator' => '==',
						'value'    => 'arts_portfolio_item',
					),
				),
				array(
					array(
						'param'    => 'post_type',
						'operator' => '==',
						'value'    => 'arts_service',
					),
				),
				array(
					array(
						'param'    => 'post_type',
						'operator' => '==',
						'value'    => 'page',
					),
				),
			),
			'menu_order'            => 0,
			'position'              => 'normal',
			'style'                 => 'default',
			'label_placement'       => 'top',
			'instruction_placement' => 'label',
			'hide_on_screen'        => '',
			'active'                => true,
			'description'           => '',
		)
	);

	// Additional featured media
	acf_add_local_field_group(
		array(
			'key'                   => 'group_6130e216ed2bb',
			'title'                 => esc_html__( 'Additional Featured Media', 'kinsey' ),
			'fields'                => array(
				array(
					'key'               => 'field_612f76f5fa1eb',
					'label'             => esc_html__( 'Featured Video', 'kinsey' ),
					'name'              => 'featured_video',
					'type'              => 'file',
					'instructions'      => esc_html__( 'Set featured video', 'kinsey' ),
					'required'          => 0,
					'conditional_logic' => 0,
					'wrapper'           => array(
						'width' => '',
						'class' => '',
						'id'    => '',
					),
					'return_format'     => 'url',
					'library'           => 'all',
					'min_size'          => '',
					'max_size'          => '',
					'mime_types'        => 'mp4, webm, ogg, ogv',
				),
			),
			'location'              => array(
				array(
					array(
						'param'    => 'post_type',
						'operator' => '==',
						'value'    => 'arts_portfolio_item',
					),
				),
				array(
					array(
						'param'    => 'post_type',
						'operator' => '==',
						'value'    => 'arts_service',
					),
				),
				array(
					array(
						'param'    => 'post_type',
						'operator' => '==',
						'value'    => 'page',
					),
				),
			),
			'menu_order'            => 0,
			'position'              => 'side',
			'style'                 => 'seamless',
			'label_placement'       => 'top',
			'instruction_placement' => 'label',
			'hide_on_screen'        => '',
			'active'                => true,
			'description'           => '',
		)
	);

	// Label for nav menu items
	acf_add_local_field_group(
		array(
			'key'                   => 'group_60fc01eb8a377',
			'title'                 => esc_html__( 'Nav Menu Item', 'kinsey' ),
			'fields'                => array(
				array(
					'key'               => 'field_60fc0205d5b43',
					'label'             => esc_html__( 'Additional Label (Only Fullscreen Overlay Menu)', 'kinsey' ),
					'name'              => 'additional_label',
					'type'              => 'text',
					'instructions'      => '',
					'required'          => 0,
					'conditional_logic' => 0,
					'wrapper'           => array(
						'width' => '',
						'class' => '',
						'id'    => '',
					),
					'default_value'     => '',
					'placeholder'       => '',
					'prepend'           => '',
					'append'            => '',
					'maxlength'         => '',
				),
			),
			'location'              => array(
				array(
					array(
						'param'    => 'nav_menu_item',
						'operator' => '==',
						'value'    => 'location/main_menu',
					),
				),
				array(
					array(
						'param'    => 'nav_menu_item',
						'operator' => '==',
						'value'    => 'location/additional_menu',
					),
				),
			),
			'menu_order'            => 0,
			'position'              => 'normal',
			'style'                 => 'default',
			'label_placement'       => 'top',
			'instruction_placement' => 'label',
			'hide_on_screen'        => '',
			'active'                => true,
			'description'           => '',
		)
	);

	// Additional media fields
	acf_add_local_field_group(
		array(
			'key'                   => 'group_6c18abc1c9e8d',
			'title'                 => esc_html__( 'Additional Media Fields', 'kinsey' ),
			'fields'                => array(
				array(
					'key'               => 'field_6f20ba4d108d3',
					'label'             => esc_html__( 'External URL', 'kinsey' ),
					'name'              => 'external_media',
					'type'              => 'link',
					'instructions'      => esc_html__( 'Internal Page or External Media Source (Youtube, Vimeo)', 'kinsey' ),
					'required'          => 0,
					'conditional_logic' => 0,
					'wrapper'           => array(
						'width' => '',
						'class' => '',
						'id'    => '',
					),
					'return_format'     => 'array',
				),
			),
			'location'              => array(
				array(
					array(
						'param'    => 'attachment',
						'operator' => '==',
						'value'    => 'image',
					),
				),
			),
			'menu_order'            => 0,
			'position'              => 'normal',
			'style'                 => 'default',
			'label_placement'       => 'top',
			'instruction_placement' => 'label',
			'hide_on_screen'        => '',
			'active'                => true,
			'description'           => '',
		)
	);
}
