<?php

/**
 * Get default title with optional subtitle depending on the page
 *
 * @return array
 */
if ( ! function_exists( 'arts_get_page_titles' ) ) {
	function arts_get_page_titles() {
		$page_title    = '';
		$page_subtitle = '';
		$page_text     = '';
		$titles        = array();

		if ( arts_is_built_with_elementor() ) {

			$page_title    = get_the_title();
			$page_subtitle = arts_get_field( 'subheading' );
			$page_text     = arts_get_field( 'description' );

		} elseif ( is_category() ) {

			$page_title    = get_category( get_query_var( 'cat' ) )->name;
			$page_subtitle = esc_html__( 'Posts in category', 'kinsey' );

		} elseif ( is_author() ) {

			$page_title    = get_userdata( get_query_var( 'author' ) )->display_name;
			$page_subtitle = esc_html__( 'Posts by author', 'kinsey' );

		} elseif ( is_tag() ) {

			$page_title    = single_tag_title( '', false );
			$page_subtitle = esc_html__( 'Posts with tag', 'kinsey' );

		} elseif ( is_day() ) {

			$page_title    = get_the_date();
			$page_subtitle = esc_html__( 'Day archive', 'kinsey' );

		} elseif ( is_month() ) {

			$page_title    = get_the_date( 'F Y' );
			$page_subtitle = esc_html__( 'Month archive', 'kinsey' );

		} elseif ( is_year() ) {

			$page_title    = get_the_date( 'Y' );
			$page_subtitle = esc_html__( 'Year archive', 'kinsey' );

		} elseif ( is_home() ) {

			$page_title = wp_title( '', false );

		} elseif ( is_search() ) {

			$default_title = esc_html__( 'Search', 'kinsey' );
			$page_title    = get_theme_mod( 'search_title', $default_title );

		} else {

			$page_title    = get_the_title();
			$page_subtitle = '';

		}

		if ( ! $page_title ) {
			$page_title = esc_html__( 'Blog', 'kinsey' );
		}

		if ( ! $page_text ) {
			$page_text = get_the_archive_description();
		}

		$titles[0] = $page_title;
		$titles[1] = $page_subtitle;
		$titles[2] = $page_text;

		return $titles;

	}
}
