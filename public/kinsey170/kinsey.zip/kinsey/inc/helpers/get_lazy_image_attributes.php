<?php

if ( ! function_exists( 'arts_get_lazy_image_attributes' ) ) {
	function arts_get_lazy_image_attributes( $args ) {
		$attributes = array(
			'image' => array(),
			'lazy'  => array(),
		);

		if ( ! $args['id'] ) {
			return $attributes;
		}

		$lazy_placeholder_src       = '#';
		$lazy_placeholder_type      = get_theme_mod( 'lazy_placeholder_type', 'inline' );
		$lazy_placeholder_inline    = get_theme_mod( 'lazy_placeholder_inline', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAHCGzyUAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAAaADAAQAAAABAAAAAQAAAADa6r/EAAAAC0lEQVQI12NolQQAASYAn89qhTcAAAAASUVORK5CYII=' );
		$lazy_placeholder_image_url = get_theme_mod( 'lazy_placeholder_image_url', '' );

		if ( $lazy_placeholder_type === 'inline' && ! empty( $lazy_placeholder_inline ) ) {
			$lazy_placeholder_src = $lazy_placeholder_inline;
		}

		if ( $lazy_placeholder_type === 'custom_image' && ! empty( $lazy_placeholder_image_url ) ) {
			$lazy_placeholder_src = $lazy_placeholder_image_url;
		}

		$full_size_images_enabled = get_theme_mod( 'full_size_images_enabled', false );
		$attrs                    = wp_get_attachment_image_src( $args['id'], $args['size'] );
		$srcset                   = '';
		$sizes                    = '';

		if ( ! $full_size_images_enabled ) {
			$srcset = wp_get_attachment_image_srcset( $args['id'], $args['size'] );
			$sizes  = wp_get_attachment_image_sizes( $args['id'], $args['size'] );
		}

		if ( $args['image'] ) {
			$attributes['image'] = arts_parse_args_recursive( $attributes['image'], $args['image'] );

			// don't append placeholder to Swiper lazy images
			if ( array_key_exists( 'class', $args['image'] ) && ( in_array( 'swiper-lazy', $args['image']['class'] ) || $args['image']['class'] === 'swiper-lazy' ) ) {
				$lazy_placeholder_src = '#';
			}
		}

		if ( $args['type'] === 'background' && empty( $attributes['image']['class'] ) ) {
			$attributes['image']['class'][] = 'lazy-bg';
			$attributes['image']['class'][] = 'of-cover';
		}

		$attributes['image']['src'] = $lazy_placeholder_src;

		if ( $attrs ) {
			if ( $attrs[0] ) {
				$attributes['image']['data-src'] = $attrs[0];
			}

			if ( $attrs[1] ) {
				$attributes['image']['width'] = $attrs[1];
			}

			if ( $attrs[2] ) {
				$attributes['image']['height'] = $attrs[2];
			}
		}

		if ( $srcset ) {
			$attributes['image']['data-srcset'] = $srcset;
		}

		if ( $sizes ) {
			$attributes['image']['data-sizes'] = $sizes;
		}

		$attributes['image']['alt'] = get_post_meta( $args['id'], '_wp_attachment_image_alt', true );

		if ( $args['lazy_wrapper'] ) {
			$attributes['lazy'] = array(
				'class' => array( 'lazy' ),
			);

			if ( $attrs && $attrs[1] && $attrs[2] ) {
				$attributes['lazy']['style'] = 'padding-bottom: ' . $attrs[2] / $attrs[1] * 100 . '%; height: 0;';
			}
		}

		return $attributes;
	}
}
