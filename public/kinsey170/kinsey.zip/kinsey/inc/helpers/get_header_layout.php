<?php

function arts_get_header_layout() {
	$menu_style    = get_theme_mod( 'menu_style', 'classic' );
	$header_layout = $menu_style === 'classic' ? get_theme_mod( 'header_layout_classic', 'classic-logo-left-menu-right' ) : get_theme_mod( 'header_layout_fullscreen', 'fullscreen-logo-left-burger-right' );

	return $header_layout;
}
