<?php

if ( ! function_exists( 'arts_get_parallax_attributes' ) ) {
	function arts_get_parallax_attributes( $args ) {
		$attributes = array(
			'outer' => array(
				'class' => array( 'js-arts-parallax', 'overflow' ),
			),
			'inner' => array(),
		);

		$attributes['outer']['data-arts-parallax-target'] = $args['target'];

		if ( $args['outer'] ) {
			$attributes['outer'] = arts_parse_args_recursive( $attributes['outer'], $args['outer'] );
		}

		if ( $args['scrub'] ) {
			$attributes['outer']['data-arts-parallax-scrub'] = $args['scrub'];
		}

		if ( $args['target'] === 'innerElement' ) {
			$attributes['inner']['class'] = array( 'js-arts-parallax__scrub', 'w-100', 'h-100' );

			if ( $args['inner'] ) {
				$attributes['inner'] = arts_parse_args_recursive( $attributes['inner'], $args['inner'] );
			}

			// Translate + scale for inner element
			if ( $args['factor']['x'] ) {
				$attributes['outer']['data-arts-parallax-factor-x'] = $args['factor']['x'];
			}

			if ( $args['factor']['y'] ) {
				$attributes['outer']['data-arts-parallax-factor-y'] = $args['factor']['y'];
			}

			if ( $args['scale']['from'] ) {
				$attributes['outer']['data-arts-parallax-scale-from'] = $args['scale']['from'];
			}

			if ( $args['scale']['to'] ) {
				$attributes['outer']['data-arts-parallax-scale-to'] = $args['scale']['to'];
			}
		}

		if ( $args['target'] === 'self' ) {

			// Translate
			if ( $args['translate']['from']['x'] ) {
				$attributes['outer']['data-arts-parallax-x-from'] = $args['translate']['from']['x'];
			}

			if ( $args['translate']['from']['y'] ) {
				$attributes['outer']['data-arts-parallax-y-from'] = $args['translate']['from']['y'];
			}

			if ( $args['translate']['to']['x'] ) {
				$attributes['outer']['data-arts-parallax-x-to'] = $args['translate']['to']['x'];
			}

			if ( $args['translate']['to']['y'] ) {
				$attributes['outer']['data-arts-parallax-y-to'] = $args['translate']['to']['y'];
			}

			// Scale
			if ( $args['scale']['from'] ) {
				$attributes['outer']['data-arts-parallax-scale-from'] = $args['scale']['from'];
			}

			if ( $args['scale']['to'] ) {
				$attributes['outer']['data-arts-parallax-scale-to'] = $args['scale']['to'];
			}

			// Rotate
			if ( $args['rotate']['from'] ) {
				$attributes['outer']['data-arts-parallax-rotate-from'] = $args['rotate']['from'];
			}

			if ( $args['rotate']['to'] ) {
				$attributes['outer']['data-arts-parallax-rotate-to'] = $args['rotate']['to'];
			}
		}

		// Velocity
		if ( $args['velocity']['effect'] === true ) {
			$attributes['outer']['data-arts-parallax-velocity-effect'] = $args['velocity']['effect'];

			if ( $args['velocity']['value'] ) {
				$attributes['outer']['data-arts-parallax-velocity-value'] = $args['velocity']['value'];
			}

			if ( $args['velocity']['unit'] ) {
				$attributes['outer']['data-arts-parallax-velocity-unit'] = $args['velocity']['unit'];
			}

			if ( $args['resistance'] ) {
				$attributes['outer']['data-arts-parallax-resistance'] = $args['resistance'];
			}
		}

		return $attributes;
	}
}
