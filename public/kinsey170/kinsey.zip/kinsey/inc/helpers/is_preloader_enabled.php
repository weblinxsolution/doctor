<?php

if ( ! function_exists( 'arts_is_preloader_enabled' ) ) {
	function arts_is_preloader_enabled() {
		$preloader_enabled   = get_theme_mod( 'preloader_enabled', false );
		$preloader_show_once = get_theme_mod( 'preloader_show_once', false );

		if ( $preloader_enabled && ! arts_is_elementor_editor_active() ) {
			if ( $preloader_show_once ) {
				return ! arts_is_referer_from_same_domain();
			}

			return true;
		}
	}
}
