<?php

function arts_print_attributes( $attributes ) {

	// expecting a non-empty array with keys & values
	if ( ! is_array( $attributes ) || empty( $attributes ) ) {
		return;
	}

	$attribute_pairs = array();

	foreach ( $attributes as $key => $val ) {

		// no need to print an empty array
		if ( is_array( $val ) && empty( $val ) ) {
			continue;
		}

		// usually we prepare a class set in this way
		if ( is_array( $val ) ) {
			// remove duplicates
			$val = array_unique( $val );

			$val = implode( ' ', $val );
		}

		if ( is_int( $key ) ) {
			$attribute_pairs[] = $val;
		} else {
			$val = htmlspecialchars( $val, ENT_QUOTES );

			// different escaping function for URLs
			if ( $key === 'href' ) {
				$attribute_pairs[] = esc_attr( $key ) . '="' . esc_url( $val ) . '"';
			} else {
				$attribute_pairs[] = esc_attr( $key ) . '="' . esc_attr( $val ) . '"';
			}
		}
	}

	// all attributes and values are escaped
	// and are safe to output
	echo join( ' ', $attribute_pairs );
}
