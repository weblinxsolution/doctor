<?php

if ( ! function_exists( 'arts_is_referer_from_same_domain' ) ) {
	function arts_is_referer_from_same_domain() {
		$referer = wp_get_referer();
		$host    = get_site_url();

		if ( $referer ) {
			if ( parse_url( $referer, PHP_URL_HOST ) === parse_url( $host, PHP_URL_HOST ) ) {
				return true;
			}
		}

		return false;
	}
}
