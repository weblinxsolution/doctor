<?php

if ( ! function_exists( 'arts_parse_args_recursive' ) ) {
	/**
	 * Like wp_parse_args but supports recursivity
	 * By default converts the returned type based on the $args and $defaults
	 *
	 * @param  array|object $args                   Values to merge with $defaults.
	 * @param  array|object $defaults               Array, Object that serves as the defaults or string.
	 * @param  boolean      $preserve_type          Optional. Convert output array into object if $args or $defaults if it is. Default true.
	 * @param  boolean      $preserve_integer_keys  Optional. If given, integer keys will be preserved and merged instead of appended.
	 *
	 * @return array|object  $output                 Merged user defined values with defaults.
	 */
	function arts_parse_args_recursive( $args, $defaults, $preserve_type = true, $preserve_integer_keys = false ) {
		$output = array();
		foreach ( array( $defaults, $args ) as $list ) {
			foreach ( (array) $list as $key => $value ) {
				if ( is_integer( $key ) && ! $preserve_integer_keys ) {
					$output[] = $value;
				} elseif (
					isset( $output[ $key ] ) &&
					( is_array( $output[ $key ] ) || is_object( $output[ $key ] ) ) &&
					( is_array( $value ) || is_object( $value ) )
				) {
					$output[ $key ] = arts_parse_args_recursive( $value, $output[ $key ], $preserve_type, $preserve_integer_keys );
				} else {
					$output[ $key ] = $value;
				}
			}
		}
		return ( $preserve_type && ( is_object( $args ) || is_object( $defaults ) ) ) ? (object) $output : $output;
	}
}
