<?php

if ( ! function_exists( 'arts_get_mask_attributes' ) ) {
	function arts_get_mask_attributes( $args ) {
		$attributes = array(
			'outer' => array(
				'class' => array( 'mask-reveal' ),
			),
		);

		if ( $args['animation'] === true ) {
			$attributes['outer']['data-arts-os-animation']      = 'true';
			$attributes['outer']['data-arts-os-animation-name'] = 'animateMask';
		}

		if ( $args['params'] ) {
			$attributes['outer']['data-arts-os-animation-params'] = json_encode( $args['params'] );
		}

		return $attributes;
	}
}
