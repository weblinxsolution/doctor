<?php

/**
 * Extra markup for Elementor Canvas template: BEFORE
 */
add_action( 'elementor/page_templates/canvas/before_content', 'arts_elementor_canvas_before_content' );
function arts_elementor_canvas_before_content() {
	$preloader_enabled                                   = arts_is_preloader_enabled();
	$ajax_enabled                                        = get_theme_mod( 'ajax_enabled', false );
	$main_container_attributes                           = arts_get_main_container_attributes();
	$has_hfe_header                                      = arts_hfe_header_enabled();
	$elementor_header_footer_builder_header_render_place = get_theme_mod( 'elementor_header_footer_builder_header_render_place', 'outside' );
	$elementor_header_footer_builder_header_wrapper_enabled = get_theme_mod( 'elementor_header_footer_builder_header_wrapper_enabled', true );
	$hfe_print_header_in_canvas_template                    = true;

	if ( function_exists( 'get_hfe_header_id' ) ) {
		$hfe_print_header_in_canvas_template = get_post_meta( get_hfe_header_id(), 'display-on-canvas-template', true );
	}
	?>

	<?php if ( $ajax_enabled ) : ?>
		<div data-barba="wrapper">
	<?php endif; ?>

	<?php if ( $preloader_enabled ) : ?>
		<!-- PAGE PRELOADER -->
		<?php get_template_part( 'template-parts/preloader/preloader' ); ?>
		<!-- - PAGE PRELOADER -->
	<?php endif; ?>

	<?php if ( $ajax_enabled ) : ?>
		<?php
			$header_container  = get_theme_mod( 'header_container', 'container-fluid' );
			$header_layout     = arts_get_header_layout();
			$header_attributes = arts_get_header_attributes();

			// hide the page header
			$header_attributes['class'][] = 'hidden';
			$header_attributes['class'][] = 'pointer-events-none';
		?>
		<?php if ( $has_hfe_header ) : ?>
			<?php if ( $elementor_header_footer_builder_header_render_place === 'outside' && $elementor_header_footer_builder_header_wrapper_enabled ) : ?>
				<?php arts_hfe_render_header(); // print hidden header in AJAX mode ?>
			<?php endif; ?>
		<?php else : ?>
			<!-- PAGE HEADER -->
			<header <?php arts_print_attributes( $header_attributes ); ?>>
				<!-- top bar -->
				<div class="header__container header__controls <?php echo esc_attr( $header_container ); ?>">
					<?php get_template_part( 'template-parts/header/header', $header_layout ); ?>
				</div>
				<!-- - top bar -->
				<!-- fullscreen overlay container -->
				<?php get_template_part( 'template-parts/header/partials/fullscreen-overlay-container' ); ?>
				<!-- - fullscreen overlay container -->
			</header>
			<!-- - PAGE HEADER -->
		<?php endif; ?>
	<?php else : ?>
		<?php if ( $has_hfe_header && $hfe_print_header_in_canvas_template ) : ?>
			<?php if ( $elementor_header_footer_builder_header_render_place === 'outside' ) : ?>
				<?php arts_hfe_render_header(); ?>
			<?php endif; ?>
		<?php endif; ?>
	<?php endif; ?>

	<!-- PAGE MAIN CONTAINER -->
	<div <?php arts_print_attributes( $main_container_attributes ); ?>>
		<?php if ( function_exists( 'elementor_theme_do_location' ) ) : ?>
			<?php elementor_theme_do_location( 'popup' ); ?>
		<?php endif; ?>
		<!-- PAGE CONTENT -->
		<main class="page-wrapper__content">
			<?php if ( $has_hfe_header && $hfe_print_header_in_canvas_template && $elementor_header_footer_builder_header_render_place === 'inside' ) : ?>
				<?php arts_hfe_render_header(); ?>
			<?php endif; ?>
	<?php
}

/**
 * Extra markup for Elementor Canvas template: AFTER
 */
add_action( 'elementor/page_templates/canvas/after_content', 'arts_elementor_canvas_after_content' );
function arts_elementor_canvas_after_content() {
	$ajax_enabled                        = get_theme_mod( 'ajax_enabled', false );
	$ajax_spinner_desktop_enabled        = get_theme_mod( 'ajax_spinner_desktop_enabled', false );
	$ajax_spinner_mobile_enabled         = get_theme_mod( 'ajax_spinner_mobile_enabled', true );
	$outdated_browsers_enabled           = get_theme_mod( 'outdated_browsers_enabled', false );
	$hfe_print_footer_in_canvas_template = true;

	if ( function_exists( 'get_hfe_footer_id' ) ) {
		$hfe_print_footer_in_canvas_template = get_post_meta( get_hfe_footer_id(), 'display-on-canvas-template', true );
	}
	?>
			<?php if ( function_exists( 'hfe_render_footer' ) && arts_hfe_footer_enabled() && $hfe_print_footer_in_canvas_template ) : ?>
				<?php arts_hfe_render_footer(); ?>
			<?php endif; ?>
		</main>
		<!-- - PAGE CONTENT -->
	</div>
	<!-- - PAGE MAIN CONTAINER -->

	<?php if ( $ajax_enabled ) : ?>
			<!-- Curtain Cursor Blocking -->
			<div class="blocking-curtain" id="js-page-blocking-curtain"></div>
			<!-- - Curtain Cursor Blocking -->
		</div>
		<?php if ( $ajax_spinner_desktop_enabled || $ajax_spinner_mobile_enabled ) : ?>
			<!-- Loading Spinner -->
			<?php get_template_part( 'template-parts/spinner/spinner' ); ?>
			<!-- - Loading Spinner -->
		<?php endif; ?>
		<!-- Curtain AJAX Transition -->
		<div class="transition-curtain" id="js-page-transition-curtain"></div>
		<!-- - Curtain AJAX Transition -->
	<?php endif; ?>
	<?php if ( $outdated_browsers_enabled ) : ?>
		<div id="outdated"></div>
	<?php endif; ?>
	<canvas id="js-webgl"></canvas>
	<?php
}
