<?php

/**
 * Merlin WP theme wizard setup
 * Load only if One Click Demo Import plugin
 * is not activated
 */
if ( ! class_exists( 'OCDI_Plugin' ) ) {
	require_once ARTS_THEME_PATH . '/inc/import/merlin/vendor/autoload.php';
	require_once ARTS_THEME_PATH . '/inc/import/merlin/class-merlin.php';
	require_once ARTS_THEME_PATH . '/inc/import/merlin/merlin-config.php';
}

/**
 * Filter set for both OCDI and Merlin
 */
require_once ARTS_THEME_PATH . '/inc/import/setup-filters.php';
