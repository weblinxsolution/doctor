<?php

if ( ! function_exists( 'arts_get_header_attributes' ) ) {
	function arts_get_header_attributes() {
		$header_position                               = get_theme_mod( 'header_position', 'sticky' );
		$header_layout                                 = arts_get_header_layout();
		$page_404_header_overrides_enabled             = is_404() && get_theme_mod( 'page_404_header_overrides_enabled', true );
		$post_image_masthead_force_light_theme_enabled = is_singular( 'post' ) && get_theme_mod( 'post_image_masthead_force_light_theme_enabled', true );
		$post_image_layout                             = get_theme_mod( 'post_image_layout', 'responsive' );

		$attributes = array(
			'id'                                  => 'page-header',
			'class'                               => array( 'header', "header_{$header_layout}" ),
			'data-arts-theme-text'                => arts_get_overridden_document_option( 'header_main_theme', 'page_header_settings_overridden', 'dark' ),
			'data-arts-header-logo'               => arts_get_overridden_document_option( 'header_main_logo', 'page_header_settings_overridden', 'primary' ),
			'data-arts-header-overlay-theme-text' => arts_get_overridden_document_option( 'header_overlay_menu_elements_theme', 'page_header_settings_overridden', 'light' ),
		);

		if ( $header_position === 'sticky' ) {
			$attributes['class'][] = 'js-header-sticky';
			$attributes['class'][] = 'header_fixed';

			$attributes['data-arts-header-sticky-theme']      = arts_get_overridden_document_option( 'header_sticky_theme', 'page_header_settings_overridden', 'bg-light-1' );
			$attributes['data-arts-header-sticky-logo']       = arts_get_overridden_document_option( 'header_sticky_logo', 'page_header_settings_overridden', 'primary' );
			$attributes['data-arts-header-sticky-theme-text'] = arts_get_overridden_document_option( 'header_sticky_elements_theme', 'page_header_settings_overridden', 'dark' );

			if ( empty( $attributes['data-arts-header-sticky-theme'] ) ) {
				$attributes['class'][] = 'header_sticky_no-shadow';
			}
		} else {
			$attributes['class'][]                   = 'header_absolute';
			$attributes['data-arts-scroll-absolute'] = 'true';
		}

		/**
		 * Style Override for 404 Page
		 */
		if ( $page_404_header_overrides_enabled ) {
			$attributes['data-arts-theme-text']  = get_theme_mod( 'page_404_header_main_theme', 'light' );
			$attributes['data-arts-header-logo'] = get_theme_mod( 'page_404_header_main_logo', 'secondary' );

			if ( $header_position === 'sticky' ) {
				$attributes['data-arts-header-sticky-theme']      = get_theme_mod( 'page_404_header_sticky_theme', 'bg-dark-1' );
				$attributes['data-arts-header-sticky-logo']       = get_theme_mod( 'page_404_header_sticky_logo', 'secondary' );
				$attributes['data-arts-header-sticky-theme-text'] = get_theme_mod( 'page_404_header_sticky_elements_theme', 'light' );
			}
		}

		/**
		 * Style Override for Single Post
		 */
		if ( $post_image_layout === 'fullscreen' && $post_image_masthead_force_light_theme_enabled ) {
			$attributes['data-arts-theme-text']  = 'light';
			$attributes['data-arts-header-logo'] = 'secondary';
		}

		$attributes = apply_filters( 'arts/page_header/attributes', $attributes );

		return $attributes;
	}
}
