<?php

if ( ! function_exists( 'arts_get_animation_inner_outer_attributes' ) ) {
	function arts_get_animation_inner_outer_attributes( $name, $args ) {
		$attributes = array(
			'outer' => array(),
			'inner' => array(),
		);

		if ( array_key_exists( 'outer', $args ) && $args['outer'] ) {
			$attributes['outer'] = $args['outer'];
		}

		if ( array_key_exists( 'inner', $args ) && $args['inner'] ) {
			$attributes['inner'] = $args['inner'];
		}

		if ( array_key_exists( 'enabled', $args ) && $args['enabled'] === true ) {

			$attributes['outer']['data-arts-os-animation'] = 'true';

			if ( $name ) {
				$attributes['outer']['data-arts-os-animation-name'] = $name;
			}

			if ( array_key_exists( 'params', $args ) && $args['params'] ) {
				$attributes['outer']['data-arts-os-animation-params'] = json_encode( $args['params'] );
			}
		}

		return $attributes;
	}
}
