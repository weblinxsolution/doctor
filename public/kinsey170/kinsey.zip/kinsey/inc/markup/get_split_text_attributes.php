<?php

if ( ! function_exists( 'arts_get_split_text_attributes' ) ) {

	function arts_get_split_text_attributes( $attributes, $args = array() ) {
		if ( ! array_key_exists( 'class', $attributes ) ) {
			$attributes['class'] = array();
		}

		$defaults = array(
			'by'        => 'lines',
			'set'       => 'lines',
			'direction' => '',
			'distance'  => '',
			'overflow'  => 'lines',
			'animation' => true,
		);

		$args = wp_parse_args( $args, $defaults );

		$attributes['class'][] = 'arts-split-text';
		$attributes['class'][] = 'js-arts-split-text';

		if ( $args['by'] ) {
			$attributes['data-arts-split-text'] = $args['by'];
		}

		if ( $args['set'] ) {
			$attributes['data-arts-split-text-set'] = $args['set'];
		}

		if ( $args['direction'] ) {
			$attributes['data-arts-split-text-set-direction'] = $args['direction'];
		}

		if ( $args['distance'] ) {
			$attributes['data-arts-split-text-set-distance'] = $args['distance'];
		}

		if ( $args['overflow'] ) {
			$attributes['data-arts-split-text-overflow-wrap'] = $args['overflow'];
		}

		if ( $args['animation'] === true ) {
			$attributes['data-arts-os-animation']      = 'true';
			$attributes['data-arts-os-animation-name'] = 'animateText';
		}

		if ( is_array( $args['animation'] ) ) {
			$attributes = arts_get_animation_attributes( $attributes, 'animateText', $args['animation'] );
		}

		return $attributes;
	}
}
