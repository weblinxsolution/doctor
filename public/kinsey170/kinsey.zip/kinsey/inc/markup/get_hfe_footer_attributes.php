<?php

if ( ! function_exists( 'arts_get_hfe_footer_attributes' ) ) {

	function arts_get_hfe_footer_attributes() {
		$elementor_header_footer_builder_footer_wrapper_enabled = get_theme_mod( 'elementor_header_footer_builder_footer_wrapper_enabled', true );

		if ( ! $elementor_header_footer_builder_footer_wrapper_enabled ) {
			return;
		}

		$attributes            = arts_get_footer_attributes();
		$attributes['class'][] = 'footer_hfe';

		$attributes = apply_filters( 'arts/page_hfe_footer/attributes', $attributes );

		return $attributes;
	}
}
