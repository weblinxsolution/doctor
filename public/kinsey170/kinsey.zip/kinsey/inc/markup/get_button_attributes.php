<?php

if ( ! function_exists( 'arts_get_button_attributes' ) ) {

	function arts_get_button_attributes( $attributes, $button ) {
		if ( ! $button ) {
			return $attributes;
		}

		if ( ! array_key_exists( 'attributes', $attributes ) ) {
			$attributes['attributes'] = array();
		}

		if ( ! array_key_exists( 'class', $attributes['attributes'] ) ) {
			$attributes['attributes']['class'] = array();
		}

		if ( array_key_exists( 'title', $button ) ) {
			$attributes['title']       = $button['title'];
			$attributes['title_hover'] = $button['title'];
		}

		if ( array_key_exists( 'url', $button ) ) {
			$attributes['attributes']['href'] = $button['url'];
		}

		if ( array_key_exists( 'target', $button ) && ! empty( $button['target'] ) ) {
			$attributes['attributes']['target'] = $button['target'];
		}

		if ( array_key_exists( 'rel', $button ) && ! empty( $button['rel'] ) ) {
			$attributes['attributes']['rel'] = $button['rel'];
		}

		if ( array_key_exists( 'button_style', $button ) ) {
			$attributes['attributes']['class'][] = $button['button_style'];
		}

		if ( array_key_exists( 'button_border', $button ) ) {
			$attributes['attributes']['class'][] = $button['button_border'];
		}

		if ( array_key_exists( 'button_color', $button ) ) {
			$attributes['attributes']['class'][] = $button['button_color'];
		}

		if ( array_key_exists( 'cursor_button_enabled', $button ) && $button['cursor_button_enabled'] ) {
			$attributes['attributes']['data-arts-cursor'] = 'true';

			if ( array_key_exists( 'cursor_button_scale_selector', $button ) && $button['cursor_button_scale_selector'] ) {

				if ( $button['cursor_button_scale_selector'] === 'current' ) {
					$attributes['attributes']['data-arts-cursor-scale'] = 'current';
				}

				if ( $button['cursor_button_scale_selector'] === 'multiplier' && array_key_exists( 'cursor_button_scale', $button ) ) {
					$attributes['attributes']['data-arts-cursor-scale'] = $button['cursor_button_scale'];
				}
			}

			if ( array_key_exists( 'cursor_button_hide_native_enabled', $button ) && $button['cursor_button_hide_native_enabled'] ) {
				$attributes['attributes']['data-arts-cursor-hide-native'] = 'true';
			}

			if ( array_key_exists( 'cursor_button_magnetic_enabled', $button ) && $button['cursor_button_magnetic_enabled'] ) {
				$attributes['attributes']['data-arts-cursor-magnetic'] = 'true';
			}
		}

		return $attributes;
	}
}
