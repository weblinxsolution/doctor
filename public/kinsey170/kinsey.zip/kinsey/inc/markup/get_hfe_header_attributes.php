<?php

if ( ! function_exists( 'arts_get_hfe_header_attributes' ) ) {

	function arts_get_hfe_header_attributes() {
		$elementor_header_footer_builder_header_render_place    = get_theme_mod( 'elementor_header_footer_builder_header_render_place', 'outside' );
		$elementor_header_footer_builder_header_wrapper_enabled = get_theme_mod( 'elementor_header_footer_builder_header_wrapper_enabled', true );

		if ( ! $elementor_header_footer_builder_header_wrapper_enabled || $elementor_header_footer_builder_header_render_place === 'inside' ) {
			return;
		}

		$attributes                          = arts_get_header_attributes();
		$ajax_enabled                        = get_theme_mod( 'ajax_enabled', false );
		$is_elementor_canvas_template        = arts_elementor_get_document_option( 'template' ) === 'elementor_canvas';
		$hfe_print_header_in_canvas_template = true;

		$attributes['class'][] = 'header_hfe';

		if ( function_exists( 'get_hfe_header_id' ) ) {
			$hfe_print_header_in_canvas_template = get_post_meta( get_hfe_header_id(), 'display-on-canvas-template', true );
		}

		if ( $ajax_enabled && $is_elementor_canvas_template && ! $hfe_print_header_in_canvas_template ) {
			$attributes['class'][] = 'hidden';
		}

		return apply_filters( 'arts/page_hfe_header/attributes', $attributes );
	}
}
