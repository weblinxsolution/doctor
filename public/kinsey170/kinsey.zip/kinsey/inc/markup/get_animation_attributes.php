<?php

if ( ! function_exists( 'arts_get_animation_attributes' ) ) {
	function arts_get_animation_attributes( $attributes, $name = '', $params = array() ) {
		if ( is_array( $attributes ) && ! empty( $attributes ) && $name ) {
			$attributes['data-arts-os-animation']      = 'true';
			$attributes['data-arts-os-animation-name'] = $name;

			if ( is_array( $params ) && ! empty( $params ) ) {
				$attributes['data-arts-os-animation-params'] = json_encode( $params );
			}
		}

		return $attributes;
	}
}
