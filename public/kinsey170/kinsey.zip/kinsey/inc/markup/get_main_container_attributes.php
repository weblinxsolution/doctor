<?php

if ( ! function_exists( 'arts_get_main_container_attributes' ) ) {

	function arts_get_main_container_attributes() {
		$ajax_enabled = get_theme_mod( 'ajax_enabled', false );

		$attributes = array(
			'id'    => 'page-wrapper',
			'class' => array( 'js-smooth-scroll' ),
		);

		if ( $ajax_enabled ) {
			$attributes['data-barba'] = 'container';

			// is archive
			if ( is_home() || is_category() || is_archive() || is_search() ) {
				$attributes['data-barba-namespace'] = 'archive';
			}

			// is post
			if ( is_singular( 'post' ) ) {
				$attributes['data-barba-namespace'] = 'post';
			}

			// is Elementor page
			if ( arts_is_built_with_elementor() ) {
				$attributes['data-barba-namespace'] = 'elementor';
			}
		}

		$attributes = apply_filters( 'arts/page_container/attributes', $attributes );

		return $attributes;
	}
}
