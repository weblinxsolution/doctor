<?php


if ( ! function_exists( 'arts_get_footer_attributes' ) ) {

	function arts_get_footer_attributes() {
		$footer_pt                        = get_theme_mod( 'footer_pt', 'pt-medium' );
		$footer_pb                        = get_theme_mod( 'footer_pb', '' );
		$footer_theme                     = arts_get_overridden_document_option( 'footer_theme', 'page_footer_settings_overridden', 'bg-dark-1' );
		$footer_main_theme                = arts_get_overridden_document_option( 'footer_main_theme', 'page_footer_settings_overridden', 'light' );
		$footer_main_logo                 = arts_get_overridden_document_option( 'footer_main_logo', 'page_footer_settings_overridden', 'secondary' );
		$footer_fixed_reveal_enabled      = get_theme_mod( 'footer_fixed_reveal_enabled', true );
		$footer_fixed_reveal_from         = get_theme_mod( 'footer_fixed_reveal_from', -20 );
		$footer_fixed_reveal_from_opacity = get_theme_mod( 'footer_fixed_reveal_from_opacity', 0.0 );

		$attributes = array(
			'id'                    => 'page-footer',
			'class'                 => array( 'footer', $footer_pt, $footer_pb, $footer_theme ),
			'data-arts-theme-text'  => $footer_main_theme,
			'data-arts-footer-logo' => $footer_main_logo,
		);

		if ( $footer_fixed_reveal_enabled === true ) {
			$attributes['data-arts-fixed-reveal']              = 'true';
			$attributes['data-arts-fixed-reveal-from']         = $footer_fixed_reveal_from . 'vh';
			$attributes['data-arts-fixed-reveal-from-opacity'] = $footer_fixed_reveal_from_opacity;
		}

		$attributes = apply_filters( 'arts/page_footer/attributes', $attributes );

		return $attributes;
	}
}
