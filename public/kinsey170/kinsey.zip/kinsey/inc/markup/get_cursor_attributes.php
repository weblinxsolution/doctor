<?php

if ( ! function_exists( 'arts_get_cursor_attributes' ) ) {

	function arts_get_cursor_attributes( $attributes, $args ) {

		// cursor is disabled
		if ( ! array_key_exists( 'data-arts-cursor', $args ) || ! $args['data-arts-cursor'] ) {
			return $attributes;
		}

		$defaults = array(
			'data-arts-cursor'             => 'true',
			'data-arts-cursor-hide-native' => '',
			'data-arts-cursor-label'       => '',
			'data-arts-cursor-icon-class'  => '',
			'data-arts-cursor-scale'       => '',
		);

		if ( array_key_exists( 'data-arts-cursor-label', $args ) || array_key_exists( 'data-arts-cursor-icon-class', $args ) ) {
			if ( ! array_key_exists( 'data-arts-cursor-color', $args ) ) {
				$args['data-arts-cursor-color'] = 'default';
			}

			if ( ! array_key_exists( 'data-arts-cursor-background-color', $args ) ) {
				$args['data-arts-cursor-background-color'] = 'default';
			}
		}

		$args = wp_parse_args( $args, $defaults );

		if ( is_array( $attributes ) && ! empty( $attributes ) ) {

			// remove unused cursor attributes
			$args = array_filter(
				$args,
				function( $value ) {
					return ! empty( $value );
				}
			);

			$attributes = array_merge( $attributes, $args );
		}

		return $attributes;
	}
}
