<?php

if ( ! function_exists( 'arts_get_cursor_attributes_theme_mod' ) ) {

	function arts_get_cursor_attributes_theme_mod( $attributes, $theme_mod_prefix ) {

		if ( ! $theme_mod_prefix || ! class_exists( 'Arts_Mouse_Cursor_Follower' ) ) {
			return $attributes;
		}

		$options = array(
			'enabled'         => get_theme_mod( "{$theme_mod_prefix}_enabled" ),
			'scale_selector'  => get_theme_mod( "{$theme_mod_prefix}_scale_selector" ),
			'scale'           => get_theme_mod( "{$theme_mod_prefix}_scale" ),
			'hide_native'     => get_theme_mod( "{$theme_mod_prefix}_hide_native_enabled" ),
			'magnetic'        => get_theme_mod( "{$theme_mod_prefix}_magnetic_enabled" ),
			'helper_selector' => get_theme_mod( "{$theme_mod_prefix}_helper_selector" ),
			'label'           => get_theme_mod( "{$theme_mod_prefix}_label" ),
			'color'           => get_theme_mod( "{$theme_mod_prefix}_color" ),
			'background'      => get_theme_mod( "{$theme_mod_prefix}_background" ),
		);

		if ( $options['enabled'] ) {
			$attributes['data-arts-cursor'] = 'true';
		} else {
			return $attributes;
		}

		if ( $options['scale_selector'] === 'current' ) {
			$attributes['data-arts-cursor-scale'] = 'current';
		}

		if ( $options['scale_selector'] === 'multiplier' ) {
			$attributes['data-arts-cursor-scale'] = $options['scale'];
		}

		if ( $options['hide_native'] ) {
			$attributes['data-arts-cursor-hide-native'] = 'true';
		}

		if ( $options['magnetic'] ) {
			$attributes['data-arts-cursor-magnetic'] = 'true';
		}

		if ( $options['helper_selector'] && $options['helper_selector'] === 'label' ) {
			if ( $options['label'] && ! empty( $options['label'] ) ) {
				$attributes['data-arts-cursor-label'] = $options['label'];
			}

			if ( ! $options['color'] ) {
				$attributes['data-arts-cursor-color'] = 'default';
			}

			if ( ! $options['background'] ) {
				$attributes['data-arts-cursor-background-color'] = 'default';
			}
		}

		if ( $options['color'] ) {
			$attributes['data-arts-cursor-color'] = $options['color'];
		}

		if ( $options['background'] ) {
			$attributes['data-arts-cursor-background-color'] = $options['background'];
		}

		return $attributes;
	}
}
