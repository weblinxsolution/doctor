<?php

/**
 * Register Widget Areas
 *
 * @return void
 */
add_action( 'widgets_init', 'arts_register_widget_areas' );
function arts_register_widget_areas() {
	$header_widget_area_enabled = get_theme_mod( 'header_widget_area_enabled', false );

	/**
	 * Blog Area
	 */
	register_sidebar(
		array(
			'name'          => esc_html__( 'Blog Sidebar', 'kinsey' ),
			'id'            => 'blog-sidebar',
			'description'   => esc_html__( 'Appears in Blog.', 'kinsey' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
		)
	);

	if ( $header_widget_area_enabled ) {
		/**
		 * Header Area
		 */
		register_sidebar(
			array(
				'name'          => esc_html__( 'Header Area', 'kinsey' ),
				'id'            => 'header-sidebar',
				'description'   => esc_html__( 'Appears in Site Header.', 'kinsey' ),
				'before_widget' => '<section class="widget %2$s">',
				'after_widget'  => '</section>',
			)
		);
	}

	/**
	 * Footer: Top Area
	 */
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer: Top Area', 'kinsey' ),
			'id'            => 'footer-sidebar-top',
			'description'   => esc_html__( 'Appears in Site Footer.', 'kinsey' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
		)
	);

	/**
	 * Footer: Middle Area
	 */
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer: Middle Area', 'kinsey' ),
			'id'            => 'footer-sidebar-middle',
			'description'   => esc_html__( 'Appears in Site Footer.', 'kinsey' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
		)
	);

	/**
	 * Footer: Bottom Area
	 */
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer: Bottom Area', 'kinsey' ),
			'id'            => 'footer-sidebar-bottom',
			'description'   => esc_html__( 'Appears in Site Footer.', 'kinsey' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
		)
	);
}
