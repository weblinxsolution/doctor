<?php

$priority                  = 1;
$bottom_nav_enabled        = array(
	'setting' => 'bottom_nav_enabled',
	'value'   => true,
);
$bottom_nav_is_auto_scroll = array(
	'setting' => 'bottom_nav_style',
	'value'   => 'auto-scroll',
);
$bottom_nav_is_prev_next   = array(
	'setting' => 'bottom_nav_style',
	'value'   => 'prev-next',
);

$button_nav_is_archive_button_enabled = array(
	'setting' => 'bottom_nav_archive_button_enabled',
	'value'   => true,
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'switch',
		'settings'    => 'bottom_nav_enabled',
		'label'       => esc_html__( 'Enable Bottom Navigation', 'kinsey' ),
		'description' => esc_html__( 'Appears at the bottom of the selected posts types.', 'kinsey' ),
		'section'     => 'bottom_nav',
		'default'     => true,
		'priority'    => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'bottom_nav_post_types',
		'label'           => esc_html__( 'Post Types', 'kinsey' ),
		'description'     => esc_html__( 'Choose post types where the bottom navigation will be displayed.', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => array( 'arts_portfolio_item' ),
		'priority'        => $priority++,
		'multiple'        => 999,
		'choices'         => array(
			'arts_portfolio_item' => esc_html__( 'Portfolio Items', 'kinsey' ),
			'arts_service'        => esc_html__( 'Services', 'kinsey' ),
			'page'                => esc_html__( 'Pages', 'kinsey' ),
		),
		'active_callback' => array( $bottom_nav_enabled ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'radio',
		'settings'        => 'botton_nav_include_portfolio_taxonomies',
		'label'           => esc_html__( 'Portfolio Items', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => '',
		'priority'        => $priority++,
		'choices'         => array(
			''                        => esc_html__( 'Loop navigation for all published portfolio items.', 'kinsey' ),
			'arts_portfolio_category' => esc_html__( 'Loop navigation only for portfolio items of the same category.', 'kinsey' ),
			'arts_portfolio_year'     => esc_html__( 'Loop navigation only for portfolio items of the same year.', 'kinsey' ),
		),
		'active_callback' => array(
			$bottom_nav_enabled,
			array(
				'setting'  => 'bottom_nav_post_types',
				'operator' => 'contains',
				'value'    => 'arts_portfolio_item',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'radio-buttonset',
		'settings'        => 'bottom_nav_style',
		'label'           => esc_html__( 'Navigation Style', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => 'auto-scroll',
		'priority'        => $priority++,
		'choices'         => array(
			'auto-scroll' => esc_html__( 'Auto Scroll Next', 'kinsey' ),
			'prev-next'   => esc_html__( 'Prev & Next', 'kinsey' ),
		),
		'active_callback' => array( $bottom_nav_enabled ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'bottom_nav_prefetch_enabled',
		'label'           => esc_html__( 'Prefetch Next Page on Scroll Down', 'kinsey' ),
		'tooltip'         => esc_html__( 'Attempt to load the next page content in background. This may potentially reduce the delay before an AJAX transition start, but will also increase the network traffic consumption.', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => true,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_auto_scroll,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'bottom_nav_seamless_transition_enabled',
		'label'           => esc_html__( 'Enable Seamless AJAX Transition', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => true,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_auto_scroll,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'bottom_nav_archive_button_enabled',
		'label'           => esc_html__( 'Enable Archive Button', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => false,
		'priority'        => $priority++,
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
			$button_nav_is_archive_button_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Archive Button', 'kinsey' ),
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
			$button_nav_is_archive_button_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'dropdown-pages',
		'settings'        => 'bottom_nav_archive_button_page',
		'description'     => esc_html__( 'Page Link', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => '419',
		'priority'        => $priority++,
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
			$button_nav_is_archive_button_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'bottom_nav_archive_button_border',
		'description'     => esc_html__( 'Border', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => 'button_solid',
		'priority'        => $priority++,
		'choices'         => array(
			'button_solid'    => esc_html__( 'Solid', 'kinsey' ),
			'button_bordered' => esc_html__( 'Bordered', 'kinsey' ),
		),
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
			$button_nav_is_archive_button_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'bottom_nav_archive_button_color',
		'description'     => esc_html__( 'Color', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => 'bg-dark-3',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_COLORS_ARRAY,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
			$button_nav_is_archive_button_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'bottom_nav_archive_button_counter_enabled',
		'label'           => esc_html__( 'Enable Total Posts Counter', 'kinsey' ),
		'description'     => esc_html__( 'All Published Posts of Current Post Type', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => false,
		'priority'        => $priority++,
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
			$button_nav_is_archive_button_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'bottom_nav_archive_button_counter_custom_string',
		'description'     => esc_html__( 'Counter Custom Number', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => '',
		'priority'        => $priority++,
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
			$button_nav_is_archive_button_enabled,
			array(
				'setting' => 'bottom_nav_archive_button_counter_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
			$button_nav_is_archive_button_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'radio-buttonset',
		'settings'        => 'bottom_nav_direction',
		'label'           => esc_html__( 'Navigation Direction', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => 'previous',
		'priority'        => $priority++,
		'choices'         => array(
			'next'     => esc_html__( 'Old -> New', 'kinsey' ),
			'previous' => esc_html__( 'New -> Old', 'kinsey' ),
		),
		'active_callback' => array(
			$bottom_nav_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array( $bottom_nav_enabled ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Labels', 'kinsey' ),
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array( $bottom_nav_enabled ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'description'     => esc_html__( 'Next Label', 'kinsey' ),
		'settings'        => 'bottom_nav_next_label',
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'default'         => esc_html__( 'Next Project', 'kinsey' ),
		'transport'       => 'postMessage',
		'active_callback' => array( $bottom_nav_enabled ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'description'     => esc_html__( 'Previous Label', 'kinsey' ),
		'settings'        => 'bottom_nav_prev_label',
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'default'         => esc_html__( 'Previous Project', 'kinsey' ),
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'description'     => esc_html__( 'Scroll Label', 'kinsey' ),
		'settings'        => 'bottom_nav_scroll_label',
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'default'         => esc_html__( 'Keep Scrolling', 'kinsey' ),
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_auto_scroll,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_auto_scroll,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Animation', 'kinsey' ),
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_auto_scroll,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'bottom_nav_spacer',
		'label'           => esc_html__( 'Spacer Height (vh)', 'kinsey' ),
		'description'     => esc_html__( 'The more spacer height is, the more pixels a visitor has to scroll down before an AJAX transition start.', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => 33,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 0,
			'max'  => 100,
			'step' => 1,
		),
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_auto_scroll,
		),
		'transport'       => 'auto',
		'output'          => array(
			array(
				'element'  => '.section-nav-projects .section-nav-projects__spacer',
				'property' => 'height',
				'suffix'   => 'vh',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'bottom_nav_fixed_reveal_from_opacity',
		'description'     => esc_html__( 'Initial Opacity', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => 1.0,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 0.0,
			'max'  => 1.0,
			'step' => 0.01,
		),
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_auto_scroll,
		),
	)
);

/**
 * Typography
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Typography', 'kinsey' ),
		'settings'        => 'bottom_nav_options_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'bottom_nav_headings_preset',
		'description'     => esc_html__( 'Headings', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => 'h1',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_TYPOGRAHY_ARRAY,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'bottom_nav_labels_preset',
		'description'     => esc_html__( 'Labels', 'kinsey' ),
		'section'         => 'bottom_nav',
		'default'         => 'small',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_TYPOGRAHY_ARRAY,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$bottom_nav_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'label'           => esc_html__( 'Items Vertical Space', 'kinsey' ),
		'settings'        => 'bottom_nav_prev_next_vertical_padding',
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'default'         => 'py-medium',
		'transport'       => 'postMessage',
		'choices'         => ARTS_THEME_DISTANCE_ARRAY['padding']['vertical'],
		'active_callback' => array(
			$bottom_nav_enabled,
			$bottom_nav_is_prev_next,
		),
	)
);

/**
 * Interactive Cursor
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'bottom_nav_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Interactive Cursor', 'kinsey' ),
		'settings'        => 'bottom_nav_generic_heading' . $priority,
		'section'         => 'bottom_nav',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			$bottom_nav_enabled,
		),
	)
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Prev Link' => array( 'scale', 'hide_native', 'label' ),
	),
	'bottom_nav',
	$priority,
	array( $bottom_nav_enabled, $bottom_nav_is_prev_next )
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Next Link' => array( 'scale', 'hide_native', 'label' ),
	),
	'bottom_nav',
	$priority,
	array( $bottom_nav_enabled )
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Archive Link' => array( 'scale', 'hide_native', 'label' ),
	),
	'bottom_nav',
	$priority,
	array( $bottom_nav_enabled, $bottom_nav_is_prev_next, $button_nav_is_archive_button_enabled )
);
