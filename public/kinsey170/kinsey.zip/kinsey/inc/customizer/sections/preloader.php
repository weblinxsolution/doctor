<?php

$priority          = 1;
$preloader_enabled = array(
	'setting' => 'preloader_enabled',
	'value'   => true,
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'switch',
		'settings' => 'preloader_enabled',
		'label'    => esc_html__( 'Enable Page Preloader', 'kinsey' ),
		'section'  => 'preloader',
		'default'  => false,
		'priority' => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'checkbox',
		'settings'    => 'preloader_show_once',
		'label'       => esc_html__( 'Show Only Once', 'kinsey' ),
		'description' => esc_html__( 'Let site preloader to appear only once on the initial site load. Further site navigation will continue without preloader until a user will close the current browser tab.', 'kinsey' ),
		'section'     => 'preloader',
		'default'     => false,
		'priority'    => $priority++,
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'preloader_preview_link',
		'section'         => 'preloader',
		'priority'        => $priority++,
		'default'         => esc_html__( 'Preview Preloader', 'kinsey' ),
		'choices'         => array(
			'element' => 'input',
			'type'    => 'button',
			'class'   => 'button button-secondary',
			'onclick' => 'javascript:wp.customize.previewer.preview.iframe[0].contentWindow.dispatchEvent(new CustomEvent("arts/preloader/preview"));',
		),
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'preloader_text',
		'label'           => esc_html__( 'Loading Text', 'kinsey' ),
		'section'         => 'preloader',
		'default'         => esc_html__( 'Loading...', 'kinsey' ),
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'image',
		'settings'        => 'preloader_image_url',
		'label'           => esc_html__( 'Loading Image', 'kinsey' ),
		'section'         => 'preloader',
		'default'         => '',
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'preloader_counter_enabled',
		'label'           => esc_html__( 'Enable Counter', 'kinsey' ),
		'section'         => 'preloader',
		'default'         => true,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'preloader_logo_during_loading_enabled',
		'label'           => esc_html__( 'Show Logo in Loading Screen', 'kinsey' ),
		'section'         => 'preloader',
		'default'         => true,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'preloader_generic_divider' . $priority,
		'section'         => 'preloader',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Color Theme', 'kinsey' ),
		'settings'        => 'preloader_generic_heading' . $priority,
		'section'         => 'preloader',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'preloader_theme',
		'description'     => esc_html__( 'Background Color', 'kinsey' ),
		'section'         => 'preloader',
		'default'         => 'bg-dark-1',
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'choices'         => ARTS_THEME_COLORS_ARRAY,
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'preloader_logo',
		'description'     => esc_html__( 'Logo to Display', 'kinsey' ),
		'section'         => 'preloader',
		'default'         => 'primary',
		'priority'        => $priority++,
		'choices'         => array(
			'none'      => esc_html__( 'None', 'kinsey' ),
			'primary'   => esc_html__( 'Primary', 'kinsey' ),
			'secondary' => esc_html__( 'Secondary', 'kinsey' ),
		),
		'transport'       => 'postMessage',
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'preloader_generic_divider' . $priority,
		'section'         => 'preloader',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array(
			$preloader_enabled,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Typography', 'kinsey' ),
		'settings'        => 'preloader_generic_heading' . $priority,
		'section'         => 'preloader',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			$preloader_enabled,
			array(
				'setting' => 'preloader_counter_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'preloader_counter_preset',
		'description'     => esc_html__( 'Counter Heading Preset', 'kinsey' ),
		'section'         => 'preloader',
		'default'         => 'xxxl',
		'transport'       => 'postMessage',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_TYPOGRAHY_ARRAY,
		'active_callback' => array(
			$preloader_enabled,
			array(
				'setting' => 'preloader_counter_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'preloader_loading_text_preset',
		'description'     => esc_html__( 'Loading Text Preset', 'kinsey' ),
		'section'         => 'preloader',
		'default'         => 'h6',
		'transport'       => 'postMessage',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_TYPOGRAHY_ARRAY,
		'active_callback' => array(
			$preloader_enabled,
			array(
				'setting'  => 'preloader_text',
				'operator' => '!==',
				'value'    => '',
			),
		),
	)
);
