<?php

if ( ! function_exists( 'arts_kirki_add_controls_cursor_interaction' ) ) {
	function arts_kirki_add_controls_cursor_interaction( $args, $section = null, $priority = 1, $active_callback = array() ) {
		if ( ! class_exists( 'Kirki' ) || ! $args || empty( $args ) || ! is_array( $args ) || ! $section ) {
			return $priority;
		}

		foreach ( $args as $key => $value ) {
			$slug           = str_replace( array( '_', '-', '/', '&', ' ' ), '_', strtolower( $key ) );
			$cursor_enabled = array_merge(
				$active_callback,
				array(
					array(
						'setting' => "{$section}_cursor_{$slug}_enabled",
						'value'   => true,
					),
				)
			);

			Kirki::add_field(
				'arts',
				array(
					'type'            => 'switch',
					'settings'        => "{$section}_cursor_{$slug}_enabled",
					'label'           => $key,
					'section'         => $section,
					'default'         => false,
					'priority'        => $priority++,
					'active_callback' => $active_callback,
				)
			);

			if ( in_array( 'scale', $value ) ) {
				Kirki::add_field(
					'arts',
					array(
						'type'            => 'select',
						'settings'        => "{$section}_cursor_{$slug}_scale_selector",
						'description'     => esc_html__( 'Scale', 'kinsey' ),
						'section'         => $section,
						'default'         => '',
						'choices'         => array(
							''           => esc_html__( 'None', 'kinsey' ),
							'current'    => esc_html__( 'By Element\'s Width or Height', 'kinsey' ),
							'multiplier' => esc_html__( 'By Multiplier', 'kinsey' ),
						),
						'priority'        => $priority++,
						'active_callback' => $cursor_enabled,
					)
				);

				Kirki::add_field(
					'arts',
					array(
						'type'            => 'slider',
						'settings'        => "{$section}_cursor_{$slug}_scale",
						'description'     => esc_html__( 'Scale Multiplier', 'kinsey' ),
						'section'         => $section,
						'default'         => 1.0,
						'priority'        => $priority++,
						'choices'         => array(
							'min'  => 0.0,
							'max'  => 4.0,
							'step' => 0.1,
						),
						'active_callback' => array_merge(
							$cursor_enabled,
							array(
								array(
									'setting' => "{$section}_cursor_{$slug}_scale_selector",
									'value'   => 'multiplier',
								),
							)
						),
					)
				);
			}

			if ( in_array( 'hide_native', $value ) ) {
				Kirki::add_field(
					'arts',
					array(
						'type'            => 'checkbox',
						'settings'        => "{$section}_cursor_{$slug}_hide_native_enabled",
						'label'           => esc_html__( 'Hide Native Cursor', 'kinsey' ),
						'section'         => $section,
						'default'         => false,
						'priority'        => $priority++,
						'active_callback' => $cursor_enabled,
					)
				);
			}

			if ( in_array( 'magnetic', $value ) ) {
				Kirki::add_field(
					'arts',
					array(
						'type'            => 'checkbox',
						'settings'        => "{$section}_cursor_{$slug}_magnetic_enabled",
						'label'           => esc_html__( 'Enable Magnetic Effect', 'kinsey' ),
						'section'         => $section,
						'default'         => false,
						'priority'        => $priority++,
						'active_callback' => $cursor_enabled,
					)
				);
			}

			if ( in_array( 'label', $value ) || in_array( 'icon', $value ) ) {

				Kirki::add_field(
					'arts',
					array(
						'type'            => 'select',
						'settings'        => "{$section}_cursor_{$slug}_helper_selector",
						'description'     => esc_html__( 'Cursor Helper', 'kinsey' ),
						'section'         => $section,
						'default'         => '',
						'choices'         => array(
							''      => esc_html__( 'None', 'kinsey' ),
							'label' => esc_html__( 'Label', 'kinsey' ),
						),
						'priority'        => $priority++,
						'active_callback' => $cursor_enabled,
					)
				);

				if ( in_array( 'label', $value ) ) {
					Kirki::add_field(
						'arts',
						array(
							'type'            => 'text',
							'settings'        => "{$section}_cursor_{$slug}_label",
							'description'     => esc_html__( 'Label', 'kinsey' ),
							'section'         => $section,
							'default'         => '',
							'priority'        => $priority++,
							'active_callback' => array_merge(
								$cursor_enabled,
								array(
									array(
										'setting' => "{$section}_cursor_{$slug}_helper_selector",
										'value'   => 'label',
									),
								)
							),
						)
					);
				}
			}
		}

		return $priority;
	}
}
