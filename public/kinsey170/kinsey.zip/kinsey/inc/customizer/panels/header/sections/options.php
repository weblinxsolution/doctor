<?php

$priority = 1;

Kirki::add_field(
	'arts',
	array(
		'type'        => 'radio-buttonset',
		'settings'    => 'menu_style',
		'label'       => esc_html__( 'Desktop Menu Style', 'kinsey' ),
		'description' => esc_html__( 'This option has an effect only on desktop. On mobile there is always a fullscreen overlay menu.', 'kinsey' ),
		'section'     => 'header_options',
		'default'     => 'classic',
		'priority'    => $priority++,
		'choices'     => array(
			'classic'    => esc_html__( 'Classic', 'kinsey' ),
			'fullscreen' => esc_html__( 'Fullscreen', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'radio-image',
		'settings'        => 'header_layout_classic',
		'label'           => esc_html__( 'Header Layout', 'kinsey' ),
		'section'         => 'header_options',
		'default'         => 'classic-logo-left-menu-right',
		'priority'        => $priority++,
		'choices'         => array(
			'classic-logo-left-menu-right'   => ARTS_THEME_URL . '/img/customizer/header-template-classic-logo-left-menu-right.jpg',
			'classic-logo-left-menu-center'  => ARTS_THEME_URL . '/img/customizer/header-template-classic-logo-left-menu-center.jpg',
			'classic-logo-center-menu-split' => ARTS_THEME_URL . '/img/customizer/header-template-classic-logo-center-menu-split.jpg',
		),
		'active_callback' => array(
			array(
				'setting' => 'menu_style',
				'value'   => 'classic',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'radio-image',
		'settings'        => 'header_layout_fullscreen',
		'label'           => esc_html__( 'Header Layout', 'kinsey' ),
		'section'         => 'header_options',
		'default'         => 'fullscreen-logo-left-burger-right',
		'priority'        => $priority++,
		'choices'         => array(
			'fullscreen-logo-left-burger-right'   => ARTS_THEME_URL . '/img/customizer/header-template-fullscreen-logo-left-burger-right.jpg',
			'fullscreen-logo-left-burger-center'  => ARTS_THEME_URL . '/img/customizer/header-template-fullscreen-logo-left-burger-center.jpg',
			'fullscreen-logo-center-burger-right' => ARTS_THEME_URL . '/img/customizer/header-template-fullscreen-logo-center-burger-right.jpg',
			'fullscreen-logo-center-burger-left'  => ARTS_THEME_URL . '/img/customizer/header-template-fullscreen-logo-center-burger-left.jpg',
		),
		'active_callback' => array(
			array(
				'setting' => 'menu_style',
				'value'   => 'fullscreen',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'checkbox',
		'settings' => 'header_widget_area_enabled',
		'label'    => esc_html__( 'Enable Header Widget Area', 'kinsey' ),
		'section'  => 'header_options',
		'default'  => false,
		'priority' => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'custom',
		'settings'        => 'header_options_warning' . $priority,
		'section'         => 'header_options',
		'priority'        => $priority++,
		'default'         => sprintf(
			'<div class="notice notice-large notice-warning">%1$s<br><br>%2$s</div>',
			esc_html( 'Please note that the chosen header layout doesn\'t have room for the widget area on desktop.', 'kinsey' ),
			esc_html( 'The widget area will displayed only on mobiles inside the overlay menu.', 'kinsey' )
		),
		'active_callback' => array(
			array(
				'setting' => 'menu_style',
				'value'   => 'classic',
			),
			array(
				'setting' => 'header_layout_classic',
				'value'   => 'classic-logo-center-menu-split',
			),
			array(
				'setting' => 'header_widget_area_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'      => 'radio-buttonset',
		'settings'  => 'header_container',
		'label'     => esc_html__( 'Container', 'kinsey' ),
		'section'   => 'header_options',
		'default'   => 'container-fluid',
		'priority'  => $priority++,
		'choices'   => array(
			'container-fluid' => esc_html__( 'Fullwidth', 'kinsey' ),
			'container'       => esc_html__( 'Boxed', 'kinsey' ),
		),
		'transport' => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'      => 'radio-buttonset',
		'settings'  => 'header_position',
		'label'     => esc_html__( 'Position', 'kinsey' ),
		'section'   => 'header_options',
		'default'   => 'sticky',
		'priority'  => $priority++,
		'transport' => 'postMessage',
		'choices'   => array(
			'absolute' => esc_html__( 'Absolute', 'kinsey' ),
			'sticky'   => esc_html__( 'Sticky', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'header_options_generic_heading' . $priority,
		'section'  => 'header_options',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Color Theme', 'kinsey' ),
		'settings' => 'header_options_generic_heading' . $priority,
		'section'  => 'header_options',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'header_main_theme',
		'description' => esc_html__( 'Elements Color', 'kinsey' ),
		'section'     => 'header_options',
		'default'     => 'dark',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_COLOR_THEMES_ARRAY,
		'tooltip'     => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'header_main_logo',
		'description' => esc_html__( 'Logo to Display', 'kinsey' ),
		'section'     => 'header_options',
		'default'     => 'primary',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => array(
			'primary'   => esc_html__( 'Primary', 'kinsey' ),
			'secondary' => esc_html__( 'Secondary', 'kinsey' ),
		),
		'tooltip'     => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'custom',
		'settings'        => 'header_options_warning' . $priority,
		'section'         => 'header_options',
		'priority'        => $priority++,
		'default'         => sprintf(
			'<div class="notice notice-large notice-warning">%1$s <strong><a href="javascript:wp.customize.section(\'title_tagline\').focus();">%2$s</a></strong> %3$s</div>',
			esc_html( 'The chosen logo version is missing. Please upload', 'kinsey' ),
			esc_html( 'secondary logo', 'kinsey' ),
			esc_html( 'version or refine your selection.', 'kinsey' )
		),
		'active_callback' => array(
			array(
				'setting' => 'header_main_logo',
				'value'   => 'secondary',
			),
			array(
				'setting' => 'custom_logo_secondary',
				'value'   => false,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'header_options_generic_heading' . $priority,
		'section'         => 'header_options',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => array(
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Sticky Color Theme', 'kinsey' ),
		'settings'        => 'header_options_generic_heading' . $priority,
		'section'         => 'header_options',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'header_sticky_theme',
		'description'     => esc_html__( 'Background Color', 'kinsey' ),
		'section'         => 'header_options',
		'default'         => 'bg-light-1',
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'choices'         => ARTS_THEME_COLORS_ARRAY,
		'tooltip'         => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
		'active_callback' => array(
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'header_sticky_elements_theme',
		'description'     => esc_html__( 'Elements Color', 'kinsey' ),
		'section'         => 'header_options',
		'default'         => 'dark',
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'choices'         => ARTS_THEME_COLOR_THEMES_ARRAY,
		'tooltip'         => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
		'active_callback' => array(
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'header_sticky_logo',
		'description'     => esc_html__( 'Logo to Display', 'kinsey' ),
		'section'         => 'header_options',
		'default'         => 'primary',
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'choices'         => array(
			'primary'   => esc_html__( 'Primary', 'kinsey' ),
			'secondary' => esc_html__( 'Secondary', 'kinsey' ),
		),
		'tooltip'         => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
		'active_callback' => array(
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'custom',
		'settings'        => 'header_options_warning' . $priority,
		'section'         => 'header_options',
		'priority'        => $priority++,
		'default'         => sprintf(
			'<div class="notice notice-large notice-warning">%1$s <strong><a href="javascript:wp.customize.section(\'title_tagline\').focus();">%2$s</a></strong> %3$s</div>',
			esc_html( 'The chosen logo version is missing. Please upload', 'kinsey' ),
			esc_html( 'secondary logo', 'kinsey' ),
			esc_html( 'version or refine your selection.', 'kinsey' )
		),
		'active_callback' => array(
			array(
				'setting' => 'header_sticky_logo',
				'value'   => 'secondary',
			),
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
			array(
				'setting' => 'custom_logo_secondary',
				'value'   => false,
			),
		),
	)
);
