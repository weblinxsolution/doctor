<?php

$priority = 1;

/**
 * Options
 */
Kirki::add_section(
	'header_options',
	array(
		'title'    => esc_html__( 'Options', 'kinsey' ),
		'panel'    => 'header',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/header/sections/options' );

/**
 * Menu
 */
Kirki::add_section(
	'menu',
	array(
		'title'    => esc_html__( 'Menu', 'kinsey' ),
		'panel'    => 'header',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/header/sections/menu' );

/**
 * Fullscreen Sidebar
 */
add_action(
	'init',
	function() {
		Kirki::add_section(
			'fullscreen_sidebar',
			array(
				'title'    => esc_html__( 'Fullscreen Sidebar', 'kinsey' ),
				'panel'    => 'header',
				'priority' => 4,
			)
		);
		get_template_part( '/inc/customizer/panels/header/sections/fullscreen-sidebar' );
	}
);
