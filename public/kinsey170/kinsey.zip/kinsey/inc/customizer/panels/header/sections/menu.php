<?php

$priority = 1;

$is_menu_fullscreen = array(
	array(
		'setting' => 'menu_style',
		'value'   => 'fullscreen',
	),
);
$is_menu_classic    = array(
	array(
		'setting' => 'menu_style',
		'value'   => 'classic',
	),
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Mobile Menu Layout', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_classic,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Layout', 'kinsey' ),
		'settings'        => 'menu_generic_heading_desktop' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'description' => esc_html__( 'Items in a Row', 'kinsey' ),
		'settings'    => 'menu_overlay_item_col',
		'section'     => 'menu',
		'priority'    => $priority++,
		'default'     => '6',
		'transport'   => 'postMessage',
		'choices'     => array(
			'12' => esc_html__( '1 Item (100%)', 'kinsey' ),
			'6'  => esc_html__( '2 Items (50%)', 'kinsey' ),
			'4'  => esc_html__( '3 Items (33%)', 'kinsey' ),
			'3'  => esc_html__( '4 Items (25%)', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'description' => esc_html__( 'Items Vertical Space', 'kinsey' ),
		'settings'    => 'menu_overlay_item_vertical_spacing',
		'section'     => 'menu',
		'priority'    => $priority++,
		'default'     => 'mt-xsmall',
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_DISTANCE_ARRAY['margin']['top'],
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'menu_generic_heading' . $priority,
		'section'  => 'menu',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Mobile Burger Button', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_classic,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Burger Button', 'kinsey' ),
		'settings'        => 'menu_generic_heading_desktop' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'description' => esc_html__( 'Style', 'kinsey' ),
		'settings'    => 'header_overlay_menu_burger_style',
		'section'     => 'menu',
		'priority'    => $priority++,
		'default'     => '2',
		'transport'   => 'postMessage',
		'choices'     => array(
			'2' => esc_html__( '2 Lines', 'kinsey' ),
			'3' => esc_html__( '3 Lines', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'text',
		'settings'    => 'menu_label_burger_closed_open',
		'description' => esc_html__( 'Menu Closed State Label: Normal', 'kinsey' ),
		'section'     => 'menu',
		'default'     => esc_html__( 'Menu', 'kinsey' ),
		'priority'    => $priority++,
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'text',
		'settings'    => 'menu_label_burger_closed_hover',
		'description' => esc_html__( 'Menu Closed State Label: Hover', 'kinsey' ),
		'section'     => 'menu',
		'default'     => esc_html__( 'Open', 'kinsey' ),
		'priority'    => $priority++,
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'text',
		'settings'    => 'menu_label_burger_opened_open',
		'description' => esc_html__( 'Menu Opened State Label: Normal', 'kinsey' ),
		'section'     => 'menu',
		'default'     => esc_html__( 'Close', 'kinsey' ),
		'priority'    => $priority++,
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'text',
		'settings'    => 'menu_label_burger_opened_hover',
		'description' => esc_html__( 'Menu Opened State Label: Hover', 'kinsey' ),
		'section'     => 'menu',
		'default'     => esc_html__( 'Close', 'kinsey' ),
		'priority'    => $priority++,
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'menu_generic_heading' . $priority,
		'section'  => 'menu',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Mobile Submenu Button', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_classic,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Submenu Button', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'description' => esc_html__( 'Submenu Opened State Style', 'kinsey' ),
		'settings'    => 'menu_label_burger_opened_back_style',
		'section'     => 'menu',
		'priority'    => $priority++,
		'default'     => 'current_submenu_item',
		'transport'   => 'postMessage',
		'choices'     => array(
			'current_submenu_item' => esc_html__( 'Current Submenu Item', 'kinsey' ),
			'custom'               => esc_html__( 'Custom', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'menu_label_burger_opened_back_normal',
		'description'     => esc_html__( 'Submenu Opened State Label: Normal', 'kinsey' ),
		'section'         => 'menu',
		'default'         => esc_html__( 'Back', 'kinsey' ),
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array(
			array(
				'setting' => 'menu_label_burger_opened_back_style',
				'value'   => 'custom',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'text',
		'settings'    => 'menu_label_burger_opened_back_hover',
		'description' => esc_html__( 'Submenu Opened State Label: Hover', 'kinsey' ),
		'section'     => 'menu',
		'default'     => esc_html__( 'Back', 'kinsey' ),
		'priority'    => $priority++,
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'menu_generic_heading' . $priority,
		'section'  => 'menu',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * Scrollbar
 */
Kirki::add_field(
	'arts',
	array(
		'label'           => esc_html__( 'Scroll Bar Style', 'kinsey' ),
		'description'     => esc_html__( 'Appears if menu overflows the viewport.', 'kinsey' ),
		'type'            => 'select',
		'settings'        => 'header_overlay_menu_overflow_scroll',
		'section'         => 'menu',
		'default'         => 'virtual',
		'priority'        => $priority++,
		'default'         => '',
		'choices'         => array(
			'native'  => esc_html__( 'Native', 'kinsey' ),
			'virtual' => esc_html__( 'Virtual', 'kinsey' ),
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

/**
 * Color Theme
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Mobile Menu Color Theme', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_classic,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Color Theme', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'header_overlay_menu_background',
		'description' => esc_html__( 'Background Color', 'kinsey' ),
		'section'     => 'menu',
		'default'     => 'bg-dark-2',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_COLORS_ARRAY,
		'tooltip'     => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'header_overlay_menu_elements_theme',
		'description' => esc_html__( 'Elements Color', 'kinsey' ),
		'section'     => 'menu',
		'default'     => 'light',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_COLOR_THEMES_ARRAY,
		'tooltip'     => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'menu_generic_heading' . $priority,
		'section'  => 'menu',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * Typography
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Mobile Menu Typography', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_classic,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Typography', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'menu_overlay_top_heading_preset',
		'description' => esc_html__( 'Top Level Items Preset', 'kinsey' ),
		'section'     => 'menu',
		'default'     => 'h2',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_TYPOGRAHY_ARRAY,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'menu_overlay_additional_label_preset',
		'description' => esc_html__( 'Additional Label Preset', 'kinsey' ),
		'section'     => 'menu',
		'default'     => 'small',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_TYPOGRAHY_ARRAY,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'menu_overlay_sub_heading_preset',
		'description' => esc_html__( 'Sub Menu Items Preset', 'kinsey' ),
		'section'     => 'menu',
		'default'     => 'h3',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_TYPOGRAHY_ARRAY,
	)
);

/**
 * Interactive Cursor
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Interactive Cursor', 'kinsey' ),
		'settings'        => 'menu_generic_heading' . $priority,
		'section'         => 'menu',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $is_menu_fullscreen,
	)
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Burger Button' => array( 'scale', 'hide_native', 'magnetic' ),
	),
	'menu',
	$priority,
	$is_menu_fullscreen
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Submenu Button' => array( 'scale', 'hide_native', 'magnetic' ),
	),
	'menu',
	$priority,
	$is_menu_fullscreen
);
