<?php

$priority = 1;

$thumbnails                  = arts_get_all_image_sizes();
$fullscreen_menu_has_sidebar = array(
	array(
		'setting' => 'menu_style',
		'value'   => 'fullscreen',
	),
	array(
		array(
			'setting' => 'fullscreen_sidebar_style',
			'value'   => 'slider',
		),
		array(
			'setting' => 'fullscreen_sidebar_style',
			'value'   => 'content',
		),
	),
);
$fullscreen_menu_has_slider  = array(
	array(
		'setting' => 'menu_style',
		'value'   => 'fullscreen',
	),
	array(
		'setting' => 'fullscreen_sidebar_style',
		'value'   => 'slider',
	),
);

$args = apply_filters(
	'arts/customizer/slider_projects/query_args',
	array(
		'post_type'      => 'arts_portfolio_item',
		'posts_per_page' => -1,
	)
);

$post_type                = get_post_type_object( $args['post_type'] );
$post_plural              = is_object( $post_type ) ? $post_type->labels->name : '';
$category_taxonomy        = $args['post_type'] === 'arts_portfolio_item' ? 'arts_portfolio_category' : 'category';
$year_taxonomy            = 'arts_portfolio_year';
$category_taxonomy_exists = get_taxonomy( $category_taxonomy );
$year_taxonomy_exists     = get_taxonomy( $category_taxonomy );

// we need to display all posts in the panel
$args['include']   = false;
$args['exclude']   = false;
$args['tax_query'] = false;

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Fullscreen Menu is Disabled', 'kinsey' ),
		'description'     => sprintf(
			'%1$s <a href="javascript:wp.customize.section(\'header_options\').focus();">%2$s</a> %3$s',
			esc_html__( 'Fullscreen sidebar appears only when fullscreen menu style is chosen in', 'kinsey' ),
			esc_html__( 'Header -> Options', 'kinsey' ),
			esc_html__( 'panel.', 'kinsey' )
		),
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			array(
				'setting'  => 'menu_style',
				'operator' => '!==',
				'value'    => 'fullscreen',
			),
		),
	)
);

/**
 * Sidebar Style
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'radio-buttonset',
		'settings'        => 'fullscreen_sidebar_style',
		'label'           => esc_html__( 'Sidebar Style', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'slider',
		'priority'        => $priority++,
		'choices'         => array(
			''       => esc_html__( 'Disabled', 'kinsey' ),
			'slider' => esc_html__( 'Slider', 'kinsey' ),
		),
		'active_callback' => array(
			array(
				'setting' => 'menu_style',
				'value'   => 'fullscreen',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_position',
		'description'     => esc_html__( 'Position', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'left',
		'priority'        => $priority++,
		'choices'         => array(
			'left'  => esc_html__( 'Left Side', 'kinsey' ),
			'right' => esc_html__( 'Right Side', 'kinsey' ),
		),
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'description'     => esc_html__( 'Width', 'kinsey' ),
		'settings'        => 'fullscreen_sidebar_col',
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'default'         => '5',
		'choices'         => array(
			'4' => esc_html__( '4 Columns (33%)', 'kinsey' ),
			'5' => esc_html__( '5 Columns (42%)', 'kinsey' ),
			'6' => esc_html__( '6 Columns (50% Halfscreen)', 'kinsey' ),
			'7' => esc_html__( '7 Columns (58%)', 'kinsey' ),
			'8' => esc_html__( '8 Columns (66%)', 'kinsey' ),
		),
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

/**
 * Sidebar Label
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Sidebar Label', 'kinsey' ),
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'fullscreen_sidebar_label',
		'description'     => esc_html__( 'Text', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => esc_html__( 'Selected Projects', 'kinsey' ),
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_label_position',
		'description'     => esc_html__( 'Position', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'left',
		'priority'        => $priority++,
		'choices'         => array(
			'left'  => esc_html__( 'Left Side', 'kinsey' ),
			'right' => esc_html__( 'Right Side', 'kinsey' ),
		),
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

/**
 * Color Theme
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Color Theme', 'kinsey' ),
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_background',
		'description'     => esc_html__( 'Background Color', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'bg-dark-1',
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'choices'         => ARTS_THEME_COLORS_ARRAY,
		'tooltip'         => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
		'active_callback' => $fullscreen_menu_has_sidebar,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_slider_posts_query',
		'label'           => sprintf( '%1$s %2$s', $post_plural, esc_html__( 'to Display', 'kinsey' ) ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'selected',
		'priority'        => $priority++,
		'choices'         => array(
			'all'      => sprintf( '%1$s %2$s', esc_html__( 'All Published', 'kinsey' ), $post_plural ),
			'selected' => sprintf( '%1$s %2$s', esc_html__( 'Only Selected', 'kinsey' ), $post_plural ),
			'filtered' => sprintf( '%1$s %2$s', esc_html__( 'Filtered ', 'kinsey' ), $post_plural ),
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_slider_include_posts',
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'multiple'        => 999,
		'choices'         => Kirki_Helper::get_posts( $args ),
		'active_callback' => array_merge(
			$fullscreen_menu_has_slider,
			array(
				array(
					'setting' => 'fullscreen_sidebar_slider_posts_query',
					'value'   => 'selected',
				),
			)
		),
	)
);

if ( $category_taxonomy_exists && $args['post_type'] === 'arts_portfolio_item' || $args['post_type'] === 'post' ) {

	Kirki::add_field(
		'arts',
		array(
			'description'     => esc_html__( 'Include Posts from these Categories', 'kinsey' ),
			'type'            => 'select',
			'settings'        => 'fullscreen_sidebar_slider_include_by_categories',
			'section'         => 'fullscreen_sidebar',
			'priority'        => $priority++,
			'multiple'        => 999,
			'choices'         => Kirki_Helper::get_terms( $category_taxonomy ),
			'active_callback' => array_merge(
				$fullscreen_menu_has_slider,
				array(
					array(
						'setting' => 'fullscreen_sidebar_slider_posts_query',
						'value'   => 'filtered',
					),
				)
			),
		)
	);

}

if ( $year_taxonomy_exists && $args['post_type'] === 'arts_portfolio_item' ) {

	Kirki::add_field(
		'arts',
		array(
			'description'     => esc_html__( 'Include Posts from these Years', 'kinsey' ),
			'type'            => 'select',
			'settings'        => 'fullscreen_sidebar_slider_include_by_years',
			'section'         => 'fullscreen_sidebar',
			'priority'        => $priority++,
			'multiple'        => 999,
			'choices'         => Kirki_Helper::get_terms( $year_taxonomy ),
			'active_callback' => array_merge(
				$fullscreen_menu_has_slider,
				array(
					array(
						'setting' => 'fullscreen_sidebar_slider_posts_query',
						'value'   => 'filtered',
					),
				)
			),
		)
	);

}

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

/**
 * Typography
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Typography', 'kinsey' ),
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_slider_heading_tag',
		'description'     => esc_html__( 'Items Heading Tag', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'h3',
		'transport'       => 'postMessage',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_HTML_TAGS_ARRAY,
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_slider_heading_preset',
		'description'     => esc_html__( 'Items Heading Preset', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'h3',
		'transport'       => 'postMessage',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_TYPOGRAHY_ARRAY,
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_slider_categories_years_preset',
		'description'     => esc_html__( 'Items Categories & Years Preset', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'small',
		'transport'       => 'postMessage',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_TYPOGRAHY_ARRAY,
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

/**
 * Interactive Cursor
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Interactive Cursor', 'kinsey' ),
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Clickable Links' => array( 'scale', 'hide_native', 'label' ),
	),
	'fullscreen_sidebar',
	$priority,
	$fullscreen_menu_has_slider
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

/**
 * Featured Images
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'fullscreen_sidebar_slider_thumbnail_size',
		'label'           => esc_html__( 'Featured Images Thumbnail', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'full',
		'priority'        => $priority++,
		'choices'         => $thumbnails,
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

/**
 * Slider Settings
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Slider Settings', 'kinsey' ),
		'settings'        => 'fullscreen_sidebar_generic_heading' . $priority,
		'section'         => 'fullscreen_sidebar',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'fullscreen_sidebar_slider_speed',
		'description'     => esc_html__( 'Transition Speed', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 1200,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 400,
			'max'  => 15000,
			'step' => 100,
		),
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'fullscreen_sidebar_slider_autoplay_enabled',
		'label'           => esc_html__( 'Enable Autoplay', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => false,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'fullscreen_sidebar_slider_autoplay_delay',
		'description'     => esc_html__( 'Autoplay Delay (ms)', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 6000,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 400,
			'max'  => 15000,
			'step' => 100,
		),
		'transport'       => 'postMessage',
		'active_callback' => array_merge(
			$fullscreen_menu_has_slider,
			array(
				array(
					'setting' => 'fullscreen_sidebar_slider_autoplay_enabled',
					'value'   => true,
				),
			)
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'fullscreen_sidebar_slider_mousewheel_enabled',
		'label'           => esc_html__( 'Enable Mousewheel Control', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => true,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'fullscreen_sidebar_slider_keyboard_enabled',
		'label'           => esc_html__( 'Enable Keyboard Control', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => true,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'fullscreen_sidebar_slider_mouse_drag_enabled',
		'label'           => esc_html__( 'Enable Mouse Dragging', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => true,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'fullscreen_sidebar_slider_mouse_drag_label',
		'description'     => esc_html__( 'Cursor Drag Label', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => esc_html__( 'Drag', 'kinsey' ),
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array_merge(
			$fullscreen_menu_has_slider,
			array(
				array(
					'setting' => 'fullscreen_sidebar_slider_mouse_drag_enabled',
					'value'   => true,
				),
			)
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'fullscreen_sidebar_slider_mouse_on_drag_cursor_class',
		'description'     => esc_html__( 'On Mouse Drag Class', 'kinsey' ),
		'tooltip'         => sprintf(
			'%1s: <strong>slider-projects-fullscreen__images_scale-up</strong><br>%2s',
			esc_html__( 'Default', 'kinsey' ),
			esc_html__( 'CSS class WITHOUT the dot that will be temporarily applied to the images slider during the dragging.', 'kinsey' )
		),
		'section'         => 'fullscreen_sidebar',
		'default'         => 'slider-projects-fullscreen__images_scale-up',
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array_merge(
			$fullscreen_menu_has_slider,
			array(
				array(
					'setting' => 'fullscreen_sidebar_slider_mouse_drag_enabled',
					'value'   => true,
				),
			)
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'fullscreen_sidebar_slider_parallax_opacity_enabled',
		'label'           => esc_html__( 'Enable Parallax Opacity', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => true,
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => $fullscreen_menu_has_slider,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'fullscreen_sidebar_slider_parallax_opacity_factor',
		'description'     => esc_html__( 'Parallax Opacity', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 0.3,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 0.0,
			'max'  => 1.0,
			'step' => 0.01,
		),
		'transport'       => 'postMessage',
		'active_callback' => array_merge(
			$fullscreen_menu_has_slider,
			array(
				array(
					'setting' => 'fullscreen_sidebar_slider_parallax_opacity_enabled',
					'value'   => true,
				),
			)
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'fullscreen_sidebar_slider_parallax_images_enabled',
		'label'           => esc_html__( 'Enable Parallax Images', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => true,
		'priority'        => $priority++,
		'active_callback' => $fullscreen_menu_has_slider,
		'transport'       => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'fullscreen_sidebar_slider_parallax_images_factor',
		'description'     => esc_html__( 'Parallax Images (%)', 'kinsey' ),
		'section'         => 'fullscreen_sidebar',
		'default'         => 25,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 0,
			'max'  => 100,
			'step' => 5,
		),
		'transport'       => 'postMessage',
		'active_callback' => array_merge(
			$fullscreen_menu_has_slider,
			array(
				array(
					'setting' => 'fullscreen_sidebar_slider_parallax_images_enabled',
					'value'   => true,
				),
			)
		),
	)
);
