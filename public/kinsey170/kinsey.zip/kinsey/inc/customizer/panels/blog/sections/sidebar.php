<?php

$priority = 1;

/**
 * Sidebar Position
 */
Kirki::add_field(
	'arts',
	array(
		'type'        => 'radio-buttonset',
		'settings'    => 'sidebar_position',
		'label'       => esc_html__( 'Sidebar Position', 'kinsey' ),
		'description' => esc_html__( ' This option has an effect only on desktop. On mobile the sidebar is always below the content.', 'kinsey' ),
		'section'     => 'blog_sidebar',
		'default'     => 'right_side',
		'priority'    => $priority++,
		'choices'     => array(
			'left_side'  => esc_html__( 'Left Side', 'kinsey' ),
			'right_side' => esc_html__( 'Right Side', 'kinsey' ),
		),
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'generic',
		'description' => sprintf(
			'<strong>%1$s:</strong> %2$s <a href="javascript:wp.customize.section(\'sidebar-widgets-blog-sidebar\').focus();">%3$s</a> %4$s',
			esc_html__( 'Tip', 'kinsey' ),
			esc_html__( 'To remove sidebar from blog pages, please remove all the widgets placed in', 'kinsey' ),
			esc_html__( 'Widgets -> Blog Sidebar', 'kinsey' ),
			esc_html__( 'area', 'kinsey' )
		),
		'settings'    => 'blog_sidebar_generic_heading' . $priority,
		'section'     => 'blog_sidebar',
		'priority'    => $priority++,
		'choices'     => array(
			'element' => 'span',
		),
	)
);
