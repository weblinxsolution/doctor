<?php

$priority = 1;

Kirki::add_field(
	'arts',
	array(
		'type'     => 'switch',
		'settings' => 'blog_ajax_comments_enabled',
		'label'    => esc_html__( 'Enable AJAX Comments Posting', 'kinsey' ),
		'section'  => 'blog_comments',
		'default'  => false,
		'priority' => $priority++,
	)
);
