<?php

$priority = 1;

$prev_next_enabled = array(
	array(
		'setting' => 'post_prev_next_nav_enabled',
		'value'   => true,
	),
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'select',
		'settings' => 'blog_single_post_layout',
		'label'    => esc_html__( 'Layout', 'kinsey' ),
		'section'  => 'blog_single_post',
		'default'  => 'guttered',
		'priority' => $priority++,
		'choices'  => array(
			'fullwidth' => esc_html__( 'Fullwidth', 'kinsey' ),
			'guttered'  => esc_html__( 'Guttered', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'select',
		'settings' => 'blog_single_post_container',
		'label'    => esc_html__( 'Container', 'kinsey' ),
		'section'  => 'blog_single_post',
		'default'  => 'container',
		'priority' => $priority++,
		'choices'  => array(
			'w-100'           => esc_html__( 'Fullwidth', 'kinsey' ),
			'container-fluid' => esc_html__( 'Fullwidth with Gutters', 'kinsey' ),
			'container'       => esc_html__( 'Boxed', 'kinsey' ),
		),
	)
);

/**
 * Featured Image Layout
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'select',
		'settings' => 'post_image_layout',
		'label'    => esc_html__( 'Featured Image Layout', 'kinsey' ),
		'section'  => 'blog_single_post',
		'default'  => 'responsive',
		'priority' => $priority++,
		'choices'  => array(
			'responsive' => esc_html__( 'Responsive', 'kinsey' ),
			'fullwidth'  => esc_html__( 'Full Width', 'kinsey' ),
			'fullscreen' => esc_html__( 'Fullscreen', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'post_image_height',
		'description'     => esc_html__( 'Image Height (vh)', 'kinsey' ),
		'section'         => 'blog_single_post',
		'default'         => 70,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 0,
			'max'  => 100,
			'step' => 1,
		),
		'transport'       => 'auto',
		'active_callback' => array(
			array(
				'setting' => 'post_image_layout',
				'value'   => 'fullwidth',
			),
		),
		'output'          => array(
			array(
				'element'  => '.section-masthead__single-post-background',
				'property' => 'height',
				'units'    => 'vh',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'color',
		'settings'        => 'post_image_overlay_color',
		'description'     => esc_html__( 'Image Overlay', 'kinsey' ),
		'section'         => 'blog_single_post',
		'default'         => 'rgba(0,0,0,0.6)',
		'priority'        => $priority++,
		'choices'         => array(
			'alpha' => true,
		),
		'output'          => array(
			array(
				'element'  => '.section-masthead__overlay_fullscreen',
				'property' => 'background-color',
			),
		),
		'transport'       => 'auto',
		'active_callback' => array(
			array(
				'setting' => 'post_image_layout',
				'value'   => 'fullscreen',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'post_image_masthead_fixed_enabled',
		'label'           => esc_html__( 'Enable Fixed Masthead', 'kinsey' ),
		'section'         => 'blog_single_post',
		'default'         => true,
		'priority'        => $priority++,
		'active_callback' => array(
			array(
				'setting' => 'post_image_layout',
				'value'   => 'fullscreen',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'post_image_masthead_force_light_theme_enabled',
		'label'           => esc_html__( 'Force Light Color Theme for Masthead & Header if There is a Featured Image Set', 'kinsey' ),
		'section'         => 'blog_single_post',
		'default'         => true,
		'priority'        => $priority++,
		'active_callback' => array(
			array(
				'setting' => 'post_image_layout',
				'value'   => 'fullscreen',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'checkbox',
		'settings' => 'post_image_parallax_enabled',
		'label'    => esc_html__( 'Enable Parallax', 'kinsey' ),
		'section'  => 'blog_single_post',
		'default'  => false,
		'priority' => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'post_image_parallax_speed',
		'description' => esc_html__( 'Parallax Speed', 'kinsey' ),
		'section'     => 'blog_single_post',
		'default'     => 0.15,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => -0.5,
			'max'  => 0.5,
			'step' => 0.01,
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'blog_single_post_generic_heading' . $priority,
		'section'  => 'blog_single_post',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * Post Show All Info
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'switch',
		'settings' => 'post_show_info',
		'label'    => esc_html__( 'Enable Meta Information', 'kinsey' ),
		'section'  => 'blog_single_post',
		'default'  => 'on',
		'priority' => $priority++,
		'choices'  => array(
			true  => esc_html__( 'On', 'kinsey' ),
			false => esc_html__( 'Off', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'multicheck',
		'settings'        => 'post_meta_set',
		'section'         => 'blog_single_post',
		'default'         => array( 'date', 'categories', 'comments', 'author' ),
		'priority'        => $priority++,
		'choices'         => array(
			'date'       => esc_html__( 'Date', 'kinsey' ),
			'categories' => esc_html__( 'Categories', 'kinsey' ),
			'comments'   => esc_html__( 'Comments Counter', 'kinsey' ),
			'author'     => esc_html__( 'Author', 'kinsey' ),
		),
		'active_callback' => array(
			array(
				'setting' => 'post_show_info',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'blog_single_post_generic_heading' . $priority,
		'section'  => 'blog_single_post',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * Post Show Prev & Next Navigation
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'switch',
		'settings' => 'post_prev_next_nav_enabled',
		'label'    => esc_html__( 'Enable Prev/Next Navigation', 'kinsey' ),
		'section'  => 'blog_single_post',
		'default'  => false,
		'priority' => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'post_prev_next_nav_prev_title',
		'label'           => esc_html__( '"Previous" label', 'kinsey' ),
		'section'         => 'blog_single_post',
		'default'         => esc_html__( 'Previous Post', 'kinsey' ),
		'priority'        => $priority++,
		'active_callback' => $prev_next_enabled,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'post_prev_next_nav_next_title',
		'label'           => esc_html__( '"Next" label', 'kinsey' ),
		'section'         => 'blog_single_post',
		'default'         => esc_html__( 'Next Post', 'kinsey' ),
		'priority'        => $priority++,
		'active_callback' => $prev_next_enabled,
	)
);

/**
 * Interactive Cursor
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'blog_single_post_generic_heading' . $priority,
		'section'  => 'blog_single_post',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Interactive Cursor', 'kinsey' ),
		'settings' => 'blog_single_post_generic_heading' . $priority,
		'section'  => 'blog_single_post',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Prev Link' => array( 'scale', 'hide_native', 'label' ),
	),
	'blog_single_post',
	$priority,
	$prev_next_enabled
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Next Link' => array( 'scale', 'hide_native', 'label' ),
	),
	'blog_single_post',
	$priority,
	$prev_next_enabled
);
