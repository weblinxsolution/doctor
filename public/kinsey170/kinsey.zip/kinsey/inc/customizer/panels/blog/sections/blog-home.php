<?php

$priority = 1;

$is_grid_layout = array(
	array(
		'setting'  => 'blog_grid_columns',
		'operator' => '>',
		'value'    => 1,
	),
	array(
		'setting'  => 'blog_posts_preview_style',
		'operator' => '!==',
		'value'    => 'background',
	),
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'switch',
		'settings' => 'blog_os_animation_enabled',
		'label'    => esc_html__( 'Enable on-scroll animation', 'kinsey' ),
		'section'  => 'blog_home',
		'default'  => false,
		'priority' => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'select',
		'settings' => 'blog_layout',
		'label'    => esc_html__( 'Layout', 'kinsey' ),
		'section'  => 'blog_home',
		'default'  => 'guttered',
		'priority' => $priority++,
		'choices'  => array(
			'fullwidth' => esc_html__( 'Fullwidth', 'kinsey' ),
			'guttered'  => esc_html__( 'Guttered', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'select',
		'settings' => 'blog_container',
		'label'    => esc_html__( 'Container', 'kinsey' ),
		'section'  => 'blog_home',
		'default'  => 'container',
		'priority' => $priority++,
		'choices'  => array(
			'w-100'           => esc_html__( 'Fullwidth', 'kinsey' ),
			'container-fluid' => esc_html__( 'Fullwidth with Gutters', 'kinsey' ),
			'container'       => esc_html__( 'Boxed', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'blog_filter_container',
		'label'           => esc_html__( 'Filter Container', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => 'container-fluid',
		'priority'        => $priority++,
		'choices'         => array(
			'w-100'           => esc_html__( 'Fullwidth', 'kinsey' ),
			'container-fluid' => esc_html__( 'Fullwidth with Gutters', 'kinsey' ),
			'container'       => esc_html__( 'Boxed', 'kinsey' ),
		),
		'active_callback' => array(
			array(
				'setting' => 'blog_grid_filter_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'select',
		'settings' => 'blog_posts_preview_style',
		'label'    => esc_html__( 'Posts Style', 'kinsey' ),
		'section'  => 'blog_home',
		'default'  => 'info',
		'priority' => $priority++,
		'choices'  => array(
			''           => esc_html__( 'Default View', 'kinsey' ),
			'meta-left'  => esc_html__( 'Meta Left Column', 'kinsey' ),
			'card-hover' => esc_html__( 'Cards Hover', 'kinsey' ),
			'background' => esc_html__( 'Fullwidth Backgrounds', 'kinsey' ),
		),
	)
);

/**
 * Columns
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'blog_grid_columns',
		'label'           => esc_html__( 'Columns', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => 1,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 1,
			'max'  => 6,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'blog_posts_preview_style',
				'operator' => '!==',
				'value'    => 'background',
			),
		),
	)
);

/**
 * Space Between
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'blog_grid_space_between',
		'label'           => esc_html__( 'Space Between', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => 4,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 0,
			'max'  => 6,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'blog_posts_preview_style',
				'operator' => '!==',
				'value'    => 'background',
			),
		),
	)
);

/**
 * Grid Fancy
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'blog_grid_fancy_enabled',
		'label'           => esc_html__( 'Enable Fancy Grid', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => false,
		'priority'        => $priority++,
		'active_callback' => $is_grid_layout,
	)
);

/**
 * Grid Equal Columns
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'blog_grid_equal_columns_enabled',
		'label'           => esc_html__( 'Enable Equal Height Columns per Row', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => false,
		'priority'        => $priority++,
		'active_callback' => $is_grid_layout,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'blog_home_generic_divider' . $priority,
		'section'  => 'blog_home',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'switch',
		'settings' => 'blog_grid_filter_enabled',
		'label'    => esc_html__( 'Enable Filter by Posts Categories', 'kinsey' ),
		'section'  => 'blog_home',
		'default'  => true,
		'priority' => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'radio-buttonset',
		'settings'        => 'blog_grid_filter_mode',
		'description'     => esc_html__( 'Filter Mode', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => '',
		'priority'        => $priority++,
		'choices'         => array(
			''     => esc_html__( 'Current Page', 'kinsey' ),
			'ajax' => esc_html__( 'All Categories', 'kinsey' ),
		),
		'active_callback' => array(
			array(
				'setting' => 'blog_grid_filter_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'description'     => esc_html__( 'The filter applies for the posts displayed on the current page in paginated blog. Navigating the blog pages updates the categories set depending on the currently displayed posts.', 'kinsey' ),
		'settings'        => 'blog_home_generic_heading' . $priority,
		'section'         => 'blog_home',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			array(
				'setting' => 'blog_grid_filter_enabled',
				'value'   => true,
			),
			array(
				'setting' => 'blog_grid_filter_mode',
				'value'   => '',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'description'     => esc_html__( 'The filter applies for all the published posts. All the categories assigned to the posts are displayed and remain unchanged. The posts pagination works for the currently active category.', 'kinsey' ),
		'settings'        => 'blog_home_generic_heading' . $priority,
		'section'         => 'blog_home',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => array(
			array(
				'setting' => 'blog_grid_filter_enabled',
				'value'   => true,
			),
			array(
				'setting' => 'blog_grid_filter_mode',
				'value'   => 'ajax',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'blog_filter_mobile_style',
		'section'         => 'blog_home',
		'priority'        => $priority++,
		'description'     => esc_html__( 'Filter Mobile Style', 'kinsey' ),
		'choices'         => array(
			''         => esc_html__( 'Auto', 'kinsey' ),
			'dropdown' => esc_html__( 'Dropdown', 'kinsey' ),
		),
		'default'         => 'dropdown',
		'active_callback' => array(
			array(
				'setting' => 'blog_grid_filter_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'blog_grid_hide_page_subheading',
		'label'           => esc_html__( 'Hide Page Subheading', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => true,
		'priority'        => $priority++,
		'active_callback' => array(
			array(
				'setting' => 'blog_grid_filter_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'blog_home_generic_divider' . $priority,
		'section'  => 'blog_home',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'blog_home_generic_divider' . $priority,
		'section'  => 'blog_home',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'switch',
		'settings'        => 'blog_read_more_enabled',
		'label'           => esc_html__( 'Enable "Read More" Button', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => true,
		'priority'        => $priority++,
		'active_callback' => array(
			array(
				'setting'  => 'blog_posts_preview_style',
				'operator' => '!==',
				'value'    => 'background',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => 'blog_read_more_label',
		'description'     => esc_html__( 'Label', 'kinsey' ),
		'section'         => 'blog_home',
		'default'         => esc_html__( 'Read More', 'kinsey' ),
		'priority'        => $priority++,
		'active_callback' => array(
			array(
				'setting' => 'blog_read_more_enabled',
				'value'   => true,
			),
			array(
				'setting'  => 'blog_posts_preview_style',
				'operator' => '!==',
				'value'    => 'background',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'slider',
		'settings' => 'blog_posts_excerpt_words_number',
		'label'    => esc_html__( 'Excerpt length (words)', 'kinsey' ),
		'section'  => 'blog_home',
		'default'  => 55,
		'choices'  => array(
			'min'  => 1,
			'max'  => 200,
			'step' => 1,
		),
		'priority' => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'radio-buttonset',
		'settings' => 'blog_posts_date_style',
		'label'    => esc_html__( 'Date Style', 'kinsey' ),
		'section'  => 'blog_home',
		'default'  => 'info',
		'priority' => $priority++,
		'choices'  => array(
			'info'       => esc_html__( 'In Post Meta', 'kinsey' ),
			'square_box' => esc_html__( 'Square Box', 'kinsey' ),
		),
	)
);

/**
 * Interactive Cursor
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'blog_home_generic_heading' . $priority,
		'section'  => 'blog_home',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Interactive Cursor', 'kinsey' ),
		'settings' => 'blog_home_generic_heading' . $priority,
		'section'  => 'blog_home',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Clickable Links' => array( 'scale', 'hide_native', 'label' ),
	),
	'blog_home',
	$priority
);
