<?php

$priority = 1;

/**
 * Blog Home
 */
Kirki::add_section(
	'blog_home',
	array(
		'title'    => esc_html__( 'Blog Home', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'blog',
	)
);
get_template_part( '/inc/customizer/panels/blog/sections/blog-home' );

/**
 * Single Post
 */
Kirki::add_section(
	'blog_single_post',
	array(
		'title'    => esc_html__( 'Single Post', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'blog',
	)
);
get_template_part( '/inc/customizer/panels/blog/sections/single-post' );

/**
 * Comments
 */
Kirki::add_section(
	'blog_comments',
	array(
		'title'    => esc_html__( 'Comments', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'blog',
	)
);
get_template_part( '/inc/customizer/panels/blog/sections/comments' );

/**
 * Sidebar
 */
Kirki::add_section(
	'blog_sidebar',
	array(
		'title'    => esc_html__( 'Sidebar', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'blog',
	)
);
get_template_part( '/inc/customizer/panels/blog/sections/sidebar' );
