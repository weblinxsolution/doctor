<?php

$priority = 1;
$choices  = array(
	'fonts' => apply_filters( 'arts/custom_fonts/font_choices', array() ),
);

/**
 * Blockquote
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Blockquote', 'kinsey' ),
		'settings' => 'blockquote_generic_heading' . $priority,
		'section'  => 'blockquote',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'      => 'typography',
		'settings'  => 'blockquote_font',
		'section'   => 'blockquote',
		'default'   => array(
			'font-family'    => 'Inter',
			'variant'        => 'italic',
			'line-height'    => 1.6,
			'letter-spacing' => 0,
			'text-transform' => 'none',
		),
		'priority'  => $priority++,
		'choices'   => $choices,
		'transport' => 'auto',
		'output'    => array(
			array(
				'element' => 'blockquote, .blockquote, blockquote p, .blockquote p',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'blockquote_max_font_size',
		'description' => esc_html__( 'Desktop font size (px)', 'kinsey' ),
		'section'     => 'blockquote',
		'default'     => 24,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--blockquote-max-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'blockquote_min_font_size',
		'description' => esc_html__( 'Mobile font size (px)', 'kinsey' ),
		'section'     => 'blockquote',
		'default'     => 16,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--blockquote-min-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'blockquote',
		'type'        => 'color',
		'description' => esc_html__( 'Dark Color Preset', 'kinsey' ),
		'default'     => '#555555',
		'settings'    => 'blockquote_color_dark',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--blockquote-color-dark',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'blockquote',
		'type'        => 'color',
		'description' => esc_html__( 'Light Color Preset', 'kinsey' ),
		'default'     => '#ffffff',
		'settings'    => 'blockquote_color_light',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--blockquote-color-light',
			),
		),
	)
);
