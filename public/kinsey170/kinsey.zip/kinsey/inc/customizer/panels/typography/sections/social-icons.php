<?php

$priority = 1;

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'social_icons_width',
		'description' => esc_html__( 'Icons Width (px)', 'kinsey' ),
		'section'     => 'social_icons',
		'default'     => 40,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => '.soc1al .soc1al__item a',
				'property' => 'width',
				'suffix'   => 'px',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'social_icons_height',
		'description' => esc_html__( 'Icons Height (px)', 'kinsey' ),
		'section'     => 'social_icons',
		'default'     => 40,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => '.soc1al .soc1al__item a',
				'property' => 'height',
				'suffix'   => 'px',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'social_icons_font_size',
		'description' => esc_html__( 'Icons Font Size (px)', 'kinsey' ),
		'section'     => 'social_icons',
		'default'     => 16,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => '.soc1al .soc1al__item a',
				'property' => 'font-size',
				'suffix'   => 'px',
			),
			array(
				'element'  => '.soc1al .soc1al__item svg',
				'property' => 'max-width',
				'suffix'   => 'px',
			),
			array(
				'element'  => '.soc1al .soc1al__item svg',
				'property' => 'max-height',
				'suffix'   => 'px',
			),
		),
	)
);
