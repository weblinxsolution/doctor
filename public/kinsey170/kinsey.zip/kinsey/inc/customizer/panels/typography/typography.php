<?php

$priority = 1;

/**
* Body Text & Paragraph
*/
Kirki::add_section(
	'paragraph',
	array(
		'title'    => esc_html__( 'Body Text & Paragraph', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/paragraph' );

/**
* XL Headings
*/
Kirki::add_section(
	'xl_headings',
	array(
		'title'    => esc_html__( 'XL+ Headings', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/xl-headings' );

/**
 * h1-h6 Headings
 */
Kirki::add_section(
	'h1_h6_headings',
	array(
		'title'    => esc_html__( 'H1 - H6 Headings', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/h1-h6-headings' );

/**
* Subheading
*/
Kirki::add_section(
	'subheading',
	array(
		'title'    => esc_html__( 'Subheading', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/subheading' );

/**
* Blockquote
*/
Kirki::add_section(
	'blockquote',
	array(
		'title'    => esc_html__( 'Blockquote', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/blockquote' );

/**
* Dropcap
*/
Kirki::add_section(
	'drop_cap',
	array(
		'title'    => esc_html__( 'Drop Cap', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/drop-cap' );

/**
* Small
*/
Kirki::add_section(
	'small',
	array(
		'title'    => esc_html__( 'Small', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/small' );

/**
* Text Logo
*/
Kirki::add_section(
	'text_logo',
	array(
		'title'    => esc_html__( 'Text Logo', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/text-logo' );

/**
* Social Icons
*/
Kirki::add_section(
	'social_icons',
	array(
		'title'    => esc_html__( 'Social Icons', 'kinsey' ),
		'panel'    => 'typography',
		'priority' => $priority ++,
	)
);
get_template_part( '/inc/customizer/panels/typography/sections/social-icons' );
