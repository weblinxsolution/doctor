<?php

$priority = 1;
$choices  = array(
	'fonts' => apply_filters( 'arts/custom_fonts/font_choices', array() ),
);

/**
 * Small
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Small', 'kinsey' ),
		'settings' => 'small_generic_heading' . $priority,
		'section'  => 'small',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'      => 'typography',
		'settings'  => 'small_font',
		'section'   => 'small',
		'default'   => array(
			'font-family'    => 'Inter',
			'variant'        => '500',
			'line-height'    => 1.0,
			'letter-spacing' => 0,
			'text-transform' => 'none',
		),
		'priority'  => $priority++,
		'choices'   => $choices,
		'transport' => 'auto',
		'output'    => array(
			array(
				'element' => 'small, .small',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'small_max_font_size',
		'description' => esc_html__( 'Desktop font size (px)', 'kinsey' ),
		'section'     => 'small',
		'default'     => 13,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--small-max-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'small_min_font_size',
		'description' => esc_html__( 'Mobile font size (px)', 'kinsey' ),
		'section'     => 'small',
		'default'     => 12,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--small-min-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'small',
		'type'        => 'color',
		'description' => esc_html__( 'Dark Color Preset', 'kinsey' ),
		'default'     => '#333333',
		'settings'    => 'small_color_dark',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--small-color-dark',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'small',
		'type'        => 'color',
		'description' => esc_html__( 'Light Color Preset', 'kinsey' ),
		'default'     => '#ffffff',
		'settings'    => 'small_color_light',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--small-color-light',
			),
		),
	)
);
