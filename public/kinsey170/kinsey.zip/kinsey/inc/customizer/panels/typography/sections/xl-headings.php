<?php

$priority = 1;
$choices  = array(
	'fonts' => apply_filters( 'arts/custom_fonts/font_choices', array() ),
);

/**
 * XXXL
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Heading XXXL', 'kinsey' ),
		'settings' => 'xl_generic_heading' . $priority,
		'section'  => 'xl_headings',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'      => 'typography',
		'settings'  => 'xxxl_font',
		'section'   => 'xl_headings',
		'default'   => array(
			'font-family'    => 'Inter',
			'variant'        => '100',
			'line-height'    => 1.00,
			'letter-spacing' => -10,
			'text-transform' => 'none',
		),
		'priority'  => $priority++,
		'choices'   => $choices,
		'transport' => 'auto',
		'output'    => array(
			array(
				'element' => '.xxxl',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'xxxl_max_font_size',
		'description' => esc_html__( 'Desktop font size (px)', 'kinsey' ),
		'section'     => 'xl_headings',
		'default'     => 212,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 300,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xxxl-max-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'xxxl_min_font_size',
		'description' => esc_html__( 'Mobile font size (px)', 'kinsey' ),
		'section'     => 'xl_headings',
		'default'     => 96,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 300,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xxxl-min-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'xl_headings',
		'type'        => 'color',
		'description' => esc_html__( 'Dark Color Preset', 'kinsey' ),
		'default'     => '#555555',
		'settings'    => 'xxxl_color_dark',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xxxl-color-dark',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'xl_headings',
		'type'        => 'color',
		'description' => esc_html__( 'Light Color Preset', 'kinsey' ),
		'default'     => '#ffffff',
		'settings'    => 'xxxl_color_light',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xxxl-color-light',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'xl_generic_divider' . $priority,
		'section'  => 'xl_headings',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * XXL
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Heading XXL', 'kinsey' ),
		'settings' => 'xl_generic_heading' . $priority,
		'section'  => 'xl_headings',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'      => 'typography',
		'settings'  => 'xxl_font',
		'section'   => 'xl_headings',
		'default'   => array(
			'font-family'    => 'Inter',
			'variant'        => '100',
			'line-height'    => 1.00,
			'letter-spacing' => -4,
			'text-transform' => 'none',
		),
		'priority'  => $priority++,
		'choices'   => $choices,
		'transport' => 'auto',
		'output'    => array(
			array(
				'element' => '.xxl',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'xxl_max_font_size',
		'description' => esc_html__( 'Desktop font size (px)', 'kinsey' ),
		'section'     => 'xl_headings',
		'default'     => 126,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 300,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xxl-max-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'xxl_min_font_size',
		'description' => esc_html__( 'Mobile font size (px)', 'kinsey' ),
		'section'     => 'xl_headings',
		'default'     => 54,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 300,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xxl-min-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'xl_headings',
		'type'        => 'color',
		'description' => esc_html__( 'Dark Color Preset', 'kinsey' ),
		'default'     => '#555555',
		'settings'    => 'xxl_color_dark',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xxl-color-dark',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'xl_headings',
		'type'        => 'color',
		'description' => esc_html__( 'Light Color Preset', 'kinsey' ),
		'default'     => '#ffffff',
		'settings'    => 'xxl_color_light',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xxl-color-light',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'xl_generic_divider' . $priority,
		'section'  => 'xl_headings',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * XL
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Heading XL', 'kinsey' ),
		'settings' => 'xl_generic_heading' . $priority,
		'section'  => 'xl_headings',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'      => 'typography',
		'settings'  => 'xl_font',
		'section'   => 'xl_headings',
		'default'   => array(
			'font-family'    => 'Inter',
			'variant'        => '100',
			'line-height'    => 1.18,
			'letter-spacing' => -2,
			'text-transform' => 'none',
		),
		'priority'  => $priority++,
		'choices'   => $choices,
		'transport' => 'auto',
		'output'    => array(
			array(
				'element' => '.xl',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'xl_max_font_size',
		'description' => esc_html__( 'Desktop font size (px)', 'kinsey' ),
		'section'     => 'xl_headings',
		'default'     => 102,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 300,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xl-max-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'xl_min_font_size',
		'description' => esc_html__( 'Mobile font size (px)', 'kinsey' ),
		'section'     => 'xl_headings',
		'default'     => 46,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 300,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xl-min-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'xl_headings',
		'type'        => 'color',
		'description' => esc_html__( 'Dark Color Preset', 'kinsey' ),
		'default'     => '#555555',
		'settings'    => 'xl_color_dark',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xl-color-dark',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'xl_headings',
		'type'        => 'color',
		'description' => esc_html__( 'Light Color Preset', 'kinsey' ),
		'default'     => '#ffffff',
		'settings'    => 'xl_color_light',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--xl-color-light',
			),
		),
	)
);
