<?php

$priority = 1;
$choices  = array(
	'fonts' => apply_filters( 'arts/custom_fonts/font_choices', array() ),
);

/**
 * Paragraph
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Body Text & Paragraph', 'kinsey' ),
		'settings' => 'par_generic_heading' . $priority,
		'section'  => 'paragraph',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'      => 'typography',
		'settings'  => 'par_font',
		'section'   => 'paragraph',
		'default'   => array(
			'font-family'    => 'Inter',
			'variant'        => 'regular',
			'line-height'    => 1.8,
			'letter-spacing' => 0,
			'text-transform' => 'none',
		),
		'priority'  => $priority++,
		'choices'   => $choices,
		'transport' => 'auto',
		'output'    => array(
			array(
				'element' => 'body, p, .paragraph, .small, .widget small',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'par_max_font_size',
		'description' => esc_html__( 'Desktop font size (px)', 'kinsey' ),
		'section'     => 'paragraph',
		'default'     => 16,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--paragraph-max-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'slider',
		'settings'    => 'par_min_font_size',
		'description' => esc_html__( 'Mobile font size (px)', 'kinsey' ),
		'section'     => 'paragraph',
		'default'     => 15,
		'priority'    => $priority++,
		'choices'     => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--paragraph-min-font-size',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'paragraph',
		'type'        => 'color',
		'description' => esc_html__( 'Dark Color Preset', 'kinsey' ),
		'default'     => '#333333',
		'settings'    => 'par_color_dark',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--paragraph-color-dark',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'paragraph',
		'type'        => 'color',
		'description' => esc_html__( 'Light Color Preset', 'kinsey' ),
		'default'     => '#f8f8f8',
		'settings'    => 'par_color_light',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--paragraph-color-light',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'par_generic_divider' . $priority,
		'section'  => 'paragraph',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * Links: Normal
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Links: Normal', 'kinsey' ),
		'settings' => 'par_generic_heading' . $priority,
		'section'  => 'paragraph',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'paragraph',
		'type'        => 'color',
		'description' => esc_html__( 'Dark Color Preset', 'kinsey' ),
		'default'     => '#666666',
		'settings'    => 'link_color_dark',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--link-color-dark',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'paragraph',
		'type'        => 'color',
		'description' => esc_html__( 'Light Color Preset', 'kinsey' ),
		'default'     => '#cfcfcf',
		'settings'    => 'link_color_light',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--link-color-light',
			),
		),
	)
);

/**
 * Links: Hover
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Links: Hover', 'kinsey' ),
		'settings' => 'par_generic_heading' . $priority,
		'section'  => 'paragraph',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'paragraph',
		'type'        => 'color',
		'description' => esc_html__( 'Dark Color Preset', 'kinsey' ),
		'default'     => '#000000',
		'settings'    => 'link_hover_color_dark',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--link-hover-color-dark',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'section'     => 'paragraph',
		'type'        => 'color',
		'description' => esc_html__( 'Light Color Preset', 'kinsey' ),
		'default'     => '#ffffff',
		'settings'    => 'link_hover_color_light',
		'priority'    => $priority ++,
		'transport'   => 'auto',
		'output'      => array(
			array(
				'element'  => ':root',
				'property' => '--link-hover-color-light',
			),
		),
	)
);
