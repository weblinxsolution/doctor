<?php
$priority = 1;
$choices  = array(
	'fonts' => apply_filters( 'arts/custom_fonts/font_choices', array() ),
);

$text_logo_display_enabled = array(
	array(
		'setting'  => 'header_text',
		'operator' => '!=',
		'value'    => false,
	),
	array(
		'setting'  => 'blogname',
		'operator' => '!=',
		'value'    => '',
	),
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'custom',
		'settings'        => 'text_logo_warning' . $priority,
		'section'         => 'text_logo',
		'priority'        => $priority++,
		'default'         => sprintf(
			'<div class="notice notice-large notice-warning"><span class="customize-control-title">%1$s</span><p>%2$s <strong>%3$s</strong> %4$s <a href="javascript:wp.customize.section(\'title_tagline\').focus();">%5$s</a> %6$s</p></div>',
			esc_html( 'Text logo is currently disabled', 'kinsey' ),
			esc_html__( 'To activate the logo typography options please enable', 'kinsey' ),
			esc_html__( 'Display Site Title and Tagline', 'kinsey' ),
			esc_html__( 'checkbox in', 'kinsey' ),
			esc_html__( 'Site Identity', 'kinsey' ),
			esc_html__( 'section.', 'kinsey' )
		),
		'active_callback' => array(
			array(
				'setting' => 'header_text',
				'value'   => false,
			),
		),
	)
);

/**
 * Text Logo: Title
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Text Logo: Title', 'kinsey' ),
		'settings'        => 'text_logo_generic_heading' . $priority,
		'section'         => 'text_logo',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $text_logo_display_enabled,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'typography',
		'settings'        => 'text_logo_title_font',
		'section'         => 'text_logo',
		'default'         => array(
			'font-family'    => 'Inter',
			'variant'        => '700',
			'line-height'    => 1.3,
			'letter-spacing' => 0,
			'text-transform' => 'none',
		),
		'priority'        => $priority++,
		'choices'         => $choices,
		'transport'       => 'auto',
		'output'          => array(
			array(
				'element' => '.logo__text-title',
			),
		),
		'active_callback' => $text_logo_display_enabled,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'text_logo_title_max_font_size',
		'description'     => esc_html__( 'Desktop font size (px)', 'kinsey' ),
		'section'         => 'text_logo',
		'default'         => 20,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'       => 'auto',
		'output'          => array(
			array(
				'element'  => ':root',
				'property' => '--logo-title-max-font-size',
			),
		),
		'active_callback' => $text_logo_display_enabled,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'text_logo_title_min_font_size',
		'description'     => esc_html__( 'Mobile font size (px)', 'kinsey' ),
		'section'         => 'text_logo',
		'default'         => 16,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 8,
			'max'  => 100,
			'step' => 1,
		),
		'transport'       => 'auto',
		'output'          => array(
			array(
				'element'  => ':root',
				'property' => '--logo-title-min-font-size',
			),
		),
		'active_callback' => $text_logo_display_enabled,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'settings'        => 'text_logo_generic_divider' . $priority,
		'section'         => 'text_logo',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'hr',
		),
		'active_callback' => $text_logo_display_enabled,
	)
);

/**
 * Text Logo: Tagline
 */
Kirki::add_field(
	'arts',
	array(
		'type'            => 'generic',
		'label'           => esc_html__( 'Text Logo: Tagline', 'kinsey' ),
		'settings'        => 'text_logo_generic_heading' . $priority,
		'section'         => 'text_logo',
		'priority'        => $priority++,
		'choices'         => array(
			'element' => 'span',
		),
		'active_callback' => $text_logo_display_enabled,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'typography',
		'settings'        => 'text_logo_tagline_font',
		'section'         => 'text_logo',
		'default'         => array(
			'font-family'    => 'Inter',
			'variant'        => '500',
			'line-height'    => 1.3,
			'letter-spacing' => 0,
			'text-transform' => 'none',
		),
		'priority'        => $priority++,
		'choices'         => $choices,
		'transport'       => 'auto',
		'output'          => array(
			array(
				'element' => '.logo__text-tagline',
			),
		),
		'active_callback' => $text_logo_display_enabled,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'text_logo_tagline_max_font_size',
		'description'     => esc_html__( 'Desktop font size (px)', 'kinsey' ),
		'section'         => 'text_logo',
		'default'         => 13,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 8,
			'max'  => 300,
			'step' => 1,
		),
		'transport'       => 'auto',
		'output'          => array(
			array(
				'element'  => ':root',
				'property' => '--logo-tagline-max-font-size',
			),
		),
		'active_callback' => $text_logo_display_enabled,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'text_logo_tagline_min_font_size',
		'description'     => esc_html__( 'Mobile font size (px)', 'kinsey' ),
		'section'         => 'text_logo',
		'default'         => 13,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 8,
			'max'  => 300,
			'step' => 1,
		),
		'transport'       => 'auto',
		'output'          => array(
			array(
				'element'  => ':root',
				'property' => '--logo-tagline-min-font-size',
			),
		),
		'active_callback' => $text_logo_display_enabled,
	)
);
