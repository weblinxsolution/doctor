<?php

$priority = 1;

Kirki::add_field(
	'arts',
	array(
		'type'      => 'radio-buttonset',
		'settings'  => 'footer_container',
		'label'     => esc_html__( 'Container', 'kinsey' ),
		'section'   => 'footer_options',
		'default'   => 'container',
		'priority'  => $priority++,
		'choices'   => array(
			'container-fluid' => esc_html__( 'Fullwidth', 'kinsey' ),
			'container'       => esc_html__( 'Boxed', 'kinsey' ),
		),
		'transport' => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'footer_options_generic_heading' . $priority,
		'section'  => 'footer_options',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Spacing', 'kinsey' ),
		'settings' => 'footer_options_generic_heading' . $priority,
		'section'  => 'footer_options',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'footer_pt',
		'description' => esc_html__( 'Padding Top', 'kinsey' ),
		'section'     => 'footer_options',
		'default'     => 'pt-medium',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_DISTANCE_ARRAY['padding']['top'],
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'footer_pb',
		'description' => esc_html__( 'Padding Bottom', 'kinsey' ),
		'section'     => 'footer_options',
		'default'     => '',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_DISTANCE_ARRAY['padding']['bottom'],
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'footer_options_generic_heading' . $priority,
		'section'  => 'footer_options',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Color Theme', 'kinsey' ),
		'settings' => 'footer_options_generic_heading' . $priority,
		'section'  => 'footer_options',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'footer_theme',
		'description' => esc_html__( 'Background Color', 'kinsey' ),
		'section'     => 'footer_options',
		'default'     => 'bg-dark-1',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_COLORS_ARRAY,
		'tooltip'     => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'footer_main_theme',
		'description' => esc_html__( 'Elements Color', 'kinsey' ),
		'section'     => 'footer_options',
		'default'     => 'light',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_COLOR_THEMES_ARRAY,
		'tooltip'     => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => 'footer_main_logo',
		'description' => esc_html__( 'Logo to Display', 'kinsey' ),
		'section'     => 'footer_options',
		'default'     => 'primary',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => array(
			'primary'   => esc_html__( 'Primary', 'kinsey' ),
			'secondary' => esc_html__( 'Secondary', 'kinsey' ),
		),
		'tooltip'     => esc_html__( 'This option may be overriden for the current page from Elementor document settings.', 'kinsey' ),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'footer_options_generic_heading' . $priority,
		'section'  => 'footer_options',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Animation', 'kinsey' ),
		'settings' => 'footer_options_generic_heading' . $priority,
		'section'  => 'footer_options',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'checkbox',
		'settings' => 'footer_fixed_reveal_enabled',
		'label'    => esc_html__( 'Enable Fixed Reveal Effect', 'kinsey' ),
		'section'  => 'footer_options',
		'default'  => false,
		'priority' => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'footer_fixed_reveal_from',
		'description'     => esc_html__( 'Initial Offset (vh)', 'kinsey' ),
		'section'         => 'footer_options',
		'default'         => -20,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => -100,
			'max'  => 100,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting' => 'footer_fixed_reveal_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'slider',
		'settings'        => 'footer_fixed_reveal_from_opacity',
		'description'     => esc_html__( 'Initial Opacity', 'kinsey' ),
		'section'         => 'footer_options',
		'default'         => 0.0,
		'priority'        => $priority++,
		'choices'         => array(
			'min'  => 0.0,
			'max'  => 1.0,
			'step' => 0.01,
		),
		'active_callback' => array(
			array(
				'setting' => 'footer_fixed_reveal_enabled',
				'value'   => true,
			),
		),
	)
);
