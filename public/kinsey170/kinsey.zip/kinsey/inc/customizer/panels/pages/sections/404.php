<?php

$priority = 1;

/**
 * 404 Preview Link
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => '404_preview_link',
		'section'  => '404',
		'priority' => $priority++,
		'default'  => esc_html__( 'Preview 404 Page', 'kinsey' ),
		'choices'  => array(
			'element' => 'input',
			'type'    => 'button',
			'class'   => 'button button-secondary',
			'onclick' => 'javascript:wp.customize.previewer.previewUrl.set( "../not-found-" + String( Math.random() ) + "/" );',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => '404_generic_divider' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * Content
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Content', 'kinsey' ),
		'settings' => '404_generic_heading' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'text',
		'settings'    => '404_title',
		'description' => esc_html__( 'Title', 'kinsey' ),
		'section'     => '404',
		'default'     => esc_html__( 'Error 404', 'kinsey' ),
		'priority'    => $priority++,
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'textarea',
		'settings'    => '404_message',
		'description' => esc_html__( 'Message', 'kinsey' ),
		'section'     => '404',
		'default'     => esc_html__( 'It looks like nothing found here. Try to navigate the menu or return to the home page.', 'kinsey' ),
		'priority'    => $priority++,
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'text',
		'settings'    => '404_button_normal',
		'description' => esc_html__( 'Button: Normal', 'kinsey' ),
		'section'     => '404',
		'default'     => esc_html__( 'Take Me Home', 'kinsey' ),
		'priority'    => $priority++,
		'transport'   => 'postMessage',
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'text',
		'settings'        => '404_button_hover',
		'description'     => esc_html__( 'Button: Hover', 'kinsey' ),
		'section'         => '404',
		'default'         => esc_html__( 'Take Me Home', 'kinsey' ),
		'priority'        => $priority++,
		'transport'       => 'postMessage',
		'active_callback' => array(
			array(
				'setting'  => '404_button_normal',
				'operator' => '!==',
				'value'    => '',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => '404_generic_divider' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * Color Theme
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Color Theme', 'kinsey' ),
		'settings' => 'menu_generic_heading' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => '404_background',
		'description' => esc_html__( 'Background Color', 'kinsey' ),
		'section'     => '404',
		'default'     => 'bg-dark-1',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_COLORS_ARRAY,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => '404_text_theme',
		'description' => esc_html__( 'Elements Color', 'kinsey' ),
		'section'     => '404',
		'default'     => 'light',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_COLOR_THEMES_ARRAY,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => '404_generic_divider' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

/**
 * Typography
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Typography', 'kinsey' ),
		'settings' => 'menu_generic_heading' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => '404_title_preset',
		'description' => esc_html__( 'Title Preset', 'kinsey' ),
		'section'     => '404',
		'default'     => 'xxl',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_TYPOGRAHY_ARRAY,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'select',
		'settings'    => '404_message_preset',
		'description' => esc_html__( 'Message Preset', 'kinsey' ),
		'section'     => '404',
		'default'     => 'h3',
		'priority'    => $priority++,
		'transport'   => 'postMessage',
		'choices'     => ARTS_THEME_TYPOGRAHY_ARRAY,
	)
);

/**
 * Interactive Cursor
 */
Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => '404_generic_heading' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Interactive Cursor', 'kinsey' ),
		'settings' => '404_generic_heading' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

$priority = arts_kirki_add_controls_cursor_interaction(
	array(
		'Button' => array( 'scale', 'hide_native', 'magnetic' ),
	),
	'404',
	$priority
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => '404_generic_heading' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => sprintf( '*** %1$s ***', esc_html__( 'Overrides', 'kinsey' ) ),
		'settings' => '404_generic_heading' . $priority,
		'section'  => '404',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'switch',
		'settings'    => 'page_404_header_overrides_enabled',
		'description' => esc_html__( 'Enable Header Style Override', 'kinsey' ),
		'section'     => '404',
		'default'     => true,
		'priority'    => $priority++,
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'page_404_header_main_theme',
		'description'     => esc_html__( '404 Page Header: Elements Color', 'kinsey' ),
		'section'         => '404',
		'default'         => 'light',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_COLOR_THEMES_ARRAY,
		'active_callback' => array(
			array(
				'setting' => 'page_404_header_overrides_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'page_404_header_main_logo',
		'description'     => esc_html__( '404 Page Header: Logo to Display', 'kinsey' ),
		'section'         => '404',
		'default'         => 'secondary',
		'priority'        => $priority++,
		'choices'         => array(
			'primary'   => esc_html__( 'Primary', 'kinsey' ),
			'secondary' => esc_html__( 'Secondary', 'kinsey' ),
		),
		'active_callback' => array(
			array(
				'setting' => 'page_404_header_overrides_enabled',
				'value'   => true,
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'page_404_header_sticky_theme',
		'description'     => esc_html__( '404 Page Header: Sticky Background Color', 'kinsey' ),
		'section'         => '404',
		'default'         => 'bg-light-1',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_COLORS_ARRAY,
		'active_callback' => array(
			array(
				'setting' => 'page_404_header_overrides_enabled',
				'value'   => true,
			),
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'page_404_header_sticky_elements_theme',
		'description'     => esc_html__( '404 Page Header: Sticky Elements Color', 'kinsey' ),
		'section'         => '404',
		'default'         => 'dark',
		'priority'        => $priority++,
		'choices'         => ARTS_THEME_COLOR_THEMES_ARRAY,
		'active_callback' => array(
			array(
				'setting' => 'page_404_header_overrides_enabled',
				'value'   => true,
			),
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'select',
		'settings'        => 'page_404_header_sticky_logo',
		'description'     => esc_html__( '404 Page Header: Sticky Logo to Display', 'kinsey' ),
		'section'         => '404',
		'default'         => 'primary',
		'priority'        => $priority++,
		'choices'         => array(
			'primary'   => esc_html__( 'Primary', 'kinsey' ),
			'secondary' => esc_html__( 'Secondary', 'kinsey' ),
		),
		'active_callback' => array(
			array(
				'setting' => 'page_404_header_overrides_enabled',
				'value'   => true,
			),
			array(
				'setting' => 'header_position',
				'value'   => 'sticky',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'switch',
		'settings'    => 'page_404_footer_removed',
		'description' => esc_html__( 'Remove Footer from 404 Page', 'kinsey' ),
		'section'     => '404',
		'default'     => true,
		'priority'    => $priority++,
	)
);
