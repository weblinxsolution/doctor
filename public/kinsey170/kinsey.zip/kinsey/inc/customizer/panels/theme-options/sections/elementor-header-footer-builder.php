<?php

$priority = 1;

if ( ! class_exists( 'Header_Footer_Elementor' ) ) {
	return;
}

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Header Rendering', 'kinsey' ),
		'settings' => 'elementor_header_footer_builder_generic_heading' . $priority,
		'section'  => 'elementor_header_footer_builder',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'radio',
		'settings' => 'elementor_header_footer_builder_header_render_place',
		'section'  => 'elementor_header_footer_builder',
		'default'  => 'outside',
		'priority' => $priority++,
		'choices'  => array(
			'outside' => esc_html__( 'Replace the original theme header', 'kinsey' ),
			'inside'  => esc_html__( 'Remove the original theme header. Add custom header to the main scrolling container', 'kinsey' ),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'            => 'checkbox',
		'settings'        => 'elementor_header_footer_builder_header_wrapper_enabled',
		'label'           => esc_html__( 'Wrap Custom Header with Theme Header Container', 'kinsey' ),
		'description'     => sprintf(
			'%1s %2s',
			esc_html__( 'Enable to handle the absolute/fixed positioning set from theme header options and AJAX transitions. This will wrap your custom header with the following element:', 'kinsey' ),
			'<pre>&lt;div id=&quot;page-header&quot;&gt;...&lt;/div&gt;</pre>'
		),
		'section'         => 'elementor_header_footer_builder',
		'default'         => true,
		'priority'        => $priority++,
		'active_callback' => array(
			array(
				'setting' => 'elementor_header_footer_builder_header_render_place',
				'value'   => 'outside',
			),
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'settings' => 'elementor_header_footer_builder_generic_heading' . $priority,
		'section'  => 'elementor_header_footer_builder',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'hr',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'     => 'generic',
		'label'    => esc_html__( 'Footer Rendering', 'kinsey' ),
		'settings' => 'elementor_header_footer_builder_generic_heading' . $priority,
		'section'  => 'elementor_header_footer_builder',
		'priority' => $priority++,
		'choices'  => array(
			'element' => 'span',
		),
	)
);

Kirki::add_field(
	'arts',
	array(
		'type'        => 'checkbox',
		'settings'    => 'elementor_header_footer_builder_footer_wrapper_enabled',
		'label'       => esc_html__( 'Wrap Custom Footer with Theme Footer Container', 'kinsey' ),
		'description' => sprintf(
			'%1s %2s',
			esc_html__( 'Enable to handle fixed reveal effect set from theme footer options. This will wrap your custom header with the following element:', 'kinsey' ),
			'<pre>&lt;div id=&quot;page-footer&quot;&gt;...&lt;/div&gt;</pre>'
		),
		'section'     => 'elementor_header_footer_builder',
		'default'     => true,
		'priority'    => $priority++,
	)
);
