<?php

$priority = 1;

Kirki::add_section(
	'ajax_transitions',
	array(
		'title'    => esc_html__( 'AJAX Transitions', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'theme_options',
	)
);
get_template_part( '/inc/customizer/panels/theme-options/sections/ajax-transitions' );

Kirki::add_section(
	'contact_form_7',
	array(
		'title'    => esc_html__( 'Contact Form 7', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'theme_options',
	)
);
get_template_part( '/inc/customizer/panels/theme-options/sections/contact-form-7' );

Kirki::add_section(
	'elementor_header_footer_builder',
	array(
		'title'    => esc_html__( 'Elementor Header & Footer Builder', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'theme_options',
	)
);
get_template_part( '/inc/customizer/panels/theme-options/sections/elementor-header-footer-builder' );

Kirki::add_section(
	'galleries',
	array(
		'title'    => esc_html__( 'Galleries', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'theme_options',
	)
);
get_template_part( '/inc/customizer/panels/theme-options/sections/galleries' );

Kirki::add_section(
	'outdated_browsers',
	array(
		'title'    => esc_html__( 'Outdated Browsers', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'theme_options',
	)
);
get_template_part( '/inc/customizer/panels/theme-options/sections/outdated-browsers' );

Kirki::add_section(
	'performance',
	array(
		'title'    => esc_html__( 'Performance & Lazy Images', 'kinsey' ),
		'priority' => $priority ++,
		'panel'    => 'theme_options',
	)
);
get_template_part( '/inc/customizer/panels/theme-options/sections/performance' );

