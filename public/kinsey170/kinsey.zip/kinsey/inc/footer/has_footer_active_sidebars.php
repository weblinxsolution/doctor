<?php

/**
 * Check if there is at least 1 active
 * sidebar in footer
 *
 * @return bool
 */
if ( ! function_exists( 'arts_has_footer_active_sidebars' ) ) {
	function arts_has_footer_active_sidebars() {
		$sidebars = array( 'footer-sidebar-top', 'footer-sidebar-middle', 'footer-sidebar-bottom' );

		foreach ( $sidebars as $sidebar ) {
			if ( is_active_sidebar( $sidebar ) ) {
				return true;
			}
		}

		return false;
	}
}
