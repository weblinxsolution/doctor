<?php

/**
 * Setup Posts Query
 *
 * @return void
 */

if ( ! function_exists( 'arts_query_posts' ) ) {
	function arts_query_posts() {
		global $wp_query;
		$current_page = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; // get current page number

		query_posts(
			array(
				'posts_per_page' => get_option( 'posts_per_page' ), // the value from Settings > Reading by default
				'paged'          => $current_page, // current page
			)
		);

		$wp_query->is_home    = true;
		$wp_query->is_archive = true;
	}
}
