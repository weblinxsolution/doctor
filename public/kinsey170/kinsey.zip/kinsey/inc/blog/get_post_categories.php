<?php

/**
 * Collect all the posts categories
 *
 * @param string $mode
 * @return array $current_categories
 */
function arts_get_posts_categories( $mode = 'all' ) {
	$current_categories = array();
	$current_page       = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; // get current page number

	$args = array(
		'post_type'     => 'post',
		'paged'         => $current_page, // current page
		'no_found_rows' => true,
	);

	$loop = new WP_Query( $args );

	if ( $loop->have_posts() ) {
		// collect categories based on the posts
		// displayed on the current page
		if ( $mode === 'current_page' ) {
			while ( $loop->have_posts() ) {
				$loop->the_post();

				$categories = get_the_category();

				if ( ! empty( $categories ) ) {
					foreach ( $categories as $category ) {

						// don't add duplicate category, but increase the total counter
						if ( array_key_exists( $category->term_id, $current_categories ) ) {
							$current_categories[ $category->term_id ]['total'] += 1;
						} else {
							$current_categories[ $category->term_id ] = array(
								'id'      => $category->term_id,
								'name'    => $category->name,
								'slug'    => $category->slug,
								'total'   => 1,
								'current' => is_category( $category->term_id ),
							);
						}
					}
				}
			}
		} else {
			// collect all posts categories
			$posts_terms = get_terms(
				array(
					'taxonomy' => 'category',
				)
			);

			if ( ! empty( $posts_terms ) ) {
				foreach ( $posts_terms as $category ) {
					array_push(
						$current_categories,
						array(
							'id'      => $category->term_id,
							'slug'    => $category->slug,
							'name'    => $category->name,
							'url'     => get_category_link( $category->term_id ),
							'total'   => $category->count,
							'current' => is_category( $category->term_id ),
						)
					);
				}
			}
		}
	}

	wp_reset_postdata();

	return $current_categories;
}
