<?php

if ( ! function_exists( 'arts_blog_filter_is_active' ) ) {

	function arts_blog_filter_is_active() {
		$blog_grid_filter_enabled = get_theme_mod( 'blog_grid_filter_enabled', false ) && ! is_singular( 'post' );
		$blog_grid_filter_mode    = get_theme_mod( 'blog_grid_filter_mode', '' );

		if ( ! $blog_grid_filter_enabled ) {
			return false;
		}

		if ( $blog_grid_filter_mode === 'ajax' ) {
			$blog_grid_filter_enabled = is_archive() && ! is_category() ? false : true;
		} else {
			// Filter is not needed on a single category or archive pages
			// with only one category itself in "Current Page" mode
			$blog_grid_filter_enabled = is_category() ? false : true;
		}

		return $blog_grid_filter_enabled;
	}
}
