<?php

/**
 * Retrive current post author.
 * Can be used outside of WordPress loop
 */
function arts_get_post_author( $post_id = null ) {
	if ( ! $post_id ) {
		global $post;
		$post_id = $post->ID;
	}

	$author_id     = get_post_field( 'post_author', $post_id );
	$author_url    = get_author_posts_url( $author_id );
	$author_name   = get_the_author_meta( 'display_name', $author_id );
	$author_avatar = get_avatar_url( $author_id );
	$result        = array(
		'id' => $author_id,
	);

	if ( ! empty( $author_url ) ) {
		$result['url'] = $author_url;
	}

	if ( ! empty( $author_name ) ) {
		$result['name'] = $author_name;
	}

	if ( ! empty( $author_avatar ) ) {
		$result['avatar'] = $author_avatar;
	}

	return $result;
}
