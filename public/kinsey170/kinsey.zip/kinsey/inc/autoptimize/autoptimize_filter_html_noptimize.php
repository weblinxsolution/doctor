<?php

/**
 * Force disable HTML minification for Autoptimize plugin
 * if AJAX transitions are enabled to avoid incorrect
 * page rendering.
 */
add_filter( 'autoptimize_filter_html_noptimize', 'arts_ao_disable_html_minification_ajax', 10, 1 );
function arts_ao_disable_html_minification_ajax( $value ) {
	$ajax_enabled = get_theme_mod( 'ajax_enabled', false );

	if ( $ajax_enabled ) {
		$value = true;
	}

	return $value;
}
