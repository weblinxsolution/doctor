<?php

/**
 * Exclude certain JS from the aggregation
 * function of Autoptimize plugin
 */
add_filter( 'autoptimize_filter_js_exclude', 'arts_ao_override_jsexclude', 10, 1 );
function arts_ao_override_jsexclude( $exclude ) {
	return $exclude . ', outdated-browser-rework, elementor-gallery, lottie';
}
