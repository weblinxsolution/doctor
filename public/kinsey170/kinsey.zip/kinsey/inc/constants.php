<?php

/**
 * Background Color Classes
 */
if ( ! defined( 'ARTS_THEME_COLORS_ARRAY' ) ) {
	define(
		'ARTS_THEME_COLORS_ARRAY',
		array(
			''            => esc_html__( 'Auto', 'kinsey' ),
			'bg-dark-1'   => esc_html__( 'Dark 1', 'kinsey' ),
			'bg-dark-2'   => esc_html__( 'Dark 2', 'kinsey' ),
			'bg-dark-3'   => esc_html__( 'Dark 3', 'kinsey' ),
			'bg-dark-4'   => esc_html__( 'Dark 4', 'kinsey' ),
			'bg-light-1'  => esc_html__( 'Light 1', 'kinsey' ),
			'bg-light-2'  => esc_html__( 'Light 2', 'kinsey' ),
			'bg-light-3'  => esc_html__( 'Light 3', 'kinsey' ),
			'bg-light-4'  => esc_html__( 'Light 4', 'kinsey' ),
			'bg-white'    => esc_html__( 'White', 'kinsey' ),
			'bg-gray-1'   => esc_html__( 'Gray 1', 'kinsey' ),
			'bg-gray-2'   => esc_html__( 'Gray 2', 'kinsey' ),
			'bg-gray-3'   => esc_html__( 'Gray 3', 'kinsey' ),
			'bg-gray-4'   => esc_html__( 'Gray 4', 'kinsey' ),
			'bg-custom-1' => esc_html__( 'Custom 1', 'kinsey' ),
			'bg-custom-2' => esc_html__( 'Custom 2', 'kinsey' ),
		)
	);
}

/**
 * Color Themes
 */
if ( ! defined( 'ARTS_THEME_COLOR_THEMES_ARRAY' ) ) {
	define(
		'ARTS_THEME_COLOR_THEMES_ARRAY',
		array(
			''      => esc_html__( 'Auto', 'kinsey' ),
			'dark'  => esc_html__( 'Dark', 'kinsey' ),
			'light' => esc_html__( 'Light', 'kinsey' ),
		)
	);
}

/**
 * Fluid Distance Presets
 */
if ( ! defined( 'ARTS_THEME_DISTANCE_ARRAY' ) ) {
	define(
		'ARTS_THEME_DISTANCE_ARRAY',
		array(
			'padding' => array(
				'top'        => array(
					''          => esc_html__( 'Auto', 'kinsey' ),
					'pt-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'pt-small'  => esc_html__( '+ Small', 'kinsey' ),
					'pt-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'pt-large'  => esc_html__( '+ Large', 'kinsey' ),
					'pt-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
				'bottom'     => array(
					''          => esc_html__( 'Auto', 'kinsey' ),
					'pb-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'pb-small'  => esc_html__( '+ Small', 'kinsey' ),
					'pb-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'pb-large'  => esc_html__( '+ Large', 'kinsey' ),
					'pb-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
				'vertical'   => array(
					''          => esc_html__( 'Auto', 'kinsey' ),
					'py-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'py-small'  => esc_html__( '+ Small', 'kinsey' ),
					'py-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'py-large'  => esc_html__( '+ Large', 'kinsey' ),
					'py-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
				'horizontal' => array(
					''          => esc_html__( 'Auto', 'kinsey' ),
					'px-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'px-small'  => esc_html__( '+ Small', 'kinsey' ),
					'px-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'px-large'  => esc_html__( '+ Large', 'kinsey' ),
					'px-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
				'all'        => array(
					''         => esc_html__( 'Auto', 'kinsey' ),
					'p-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'p-small'  => esc_html__( '+ Small', 'kinsey' ),
					'p-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'p-large'  => esc_html__( '+ Large', 'kinsey' ),
					'p-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
			),
			'margin'  => array(
				'top'          => array(
					''          => esc_html__( 'Auto', 'kinsey' ),
					'mt-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'mt-small'  => esc_html__( '+ Small', 'kinsey' ),
					'mt-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'mt-large'  => esc_html__( '+ Large', 'kinsey' ),
					'mt-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
				'minus_top'    => array(
					'mt-minus-xsmall' => esc_html__( '- XSmall', 'kinsey' ),
					'mt-minus-small'  => esc_html__( '- Small', 'kinsey' ),
					'mt-minus-medium' => esc_html__( '- Medium', 'kinsey' ),
					'mt-minus-large'  => esc_html__( '- Large', 'kinsey' ),
					'mt-minus-xlarge' => esc_html__( '- XLarge', 'kinsey' ),
				),
				'bottom'       => array(
					''          => esc_html__( 'Auto', 'kinsey' ),
					'mb-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'mb-small'  => esc_html__( '+ Small', 'kinsey' ),
					'mb-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'mb-large'  => esc_html__( '+ Large', 'kinsey' ),
					'mb-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
				'minus_bottom' => array(
					'mb-minus-xsmall' => esc_html__( '- XSmall', 'kinsey' ),
					'mb-minus-small'  => esc_html__( '- Small', 'kinsey' ),
					'mb-minus-medium' => esc_html__( '- Medium', 'kinsey' ),
					'mb-minus-large'  => esc_html__( '- Large', 'kinsey' ),
					'mb-minus-xlarge' => esc_html__( '- XLarge', 'kinsey' ),
				),
				'vertical'     => array(
					''          => esc_html__( 'Auto', 'kinsey' ),
					'my-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'my-small'  => esc_html__( '+ Small', 'kinsey' ),
					'my-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'my-large'  => esc_html__( '+ Large', 'kinsey' ),
					'my-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
				'horizontal'   => array(
					''          => esc_html__( 'Auto', 'kinsey' ),
					'mx-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'mx-small'  => esc_html__( '+ Small', 'kinsey' ),
					'mx-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'mx-large'  => esc_html__( '+ Large', 'kinsey' ),
					'mx-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
				'all'          => array(
					''         => esc_html__( 'Auto', 'kinsey' ),
					'm-xsmall' => esc_html__( '+ XSmall', 'kinsey' ),
					'm-small'  => esc_html__( '+ Small', 'kinsey' ),
					'm-medium' => esc_html__( '+ Medium', 'kinsey' ),
					'm-large'  => esc_html__( '+ Large', 'kinsey' ),
					'm-xlarge' => esc_html__( '+ XLarge', 'kinsey' ),
				),
			),
		)
	);
}

/**
 * Typography Presets
 */
if ( ! defined( 'ARTS_THEME_TYPOGRAHY_ARRAY' ) ) {
	define(
		'ARTS_THEME_TYPOGRAHY_ARRAY',
		array(
			'xxxl'       => esc_html__( 'Heading XXXL', 'kinsey' ),
			'xxl'        => esc_html__( 'Heading XXL', 'kinsey' ),
			'xl'         => esc_html__( 'Heading XL', 'kinsey' ),
			'h1'         => esc_html__( 'Heading 1', 'kinsey' ),
			'h2'         => esc_html__( 'Heading 2', 'kinsey' ),
			'h3'         => esc_html__( 'Heading 3', 'kinsey' ),
			'h4'         => esc_html__( 'Heading 4', 'kinsey' ),
			'h5'         => esc_html__( 'Heading 5', 'kinsey' ),
			'h6'         => esc_html__( 'Heading 6', 'kinsey' ),
			'paragraph'  => esc_html__( 'Paragraph', 'kinsey' ),
			'blockquote' => esc_html__( 'Blockquote', 'kinsey' ),
			'subheading' => esc_html__( 'Subheading', 'kinsey' ),
			'small'      => esc_html__( 'Small', 'kinsey' ),
		)
	);
}

/**
 * HTML Tags
 */
if ( ! defined( 'ARTS_THEME_HTML_TAGS_ARRAY' ) ) {
	define(
		'ARTS_THEME_HTML_TAGS_ARRAY',
		array(
			'div'        => 'div',
			'span'       => 'span',
			'h1'         => 'h1',
			'h2'         => 'h2',
			'h3'         => 'h3',
			'h4'         => 'h4',
			'h5'         => 'h5',
			'h6'         => 'h6',
			'p'          => 'p',
			'blockquote' => 'blockquote',
		)
	);
}
