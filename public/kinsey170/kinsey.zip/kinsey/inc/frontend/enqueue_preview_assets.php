<?php

/**
 * Enqueue Elementor Editor Assets
 */
add_action( 'elementor/editor/after_enqueue_scripts', 'arts_enqueue_elementor_preview_scripts', 99 );
function arts_enqueue_elementor_preview_scripts() {
	wp_enqueue_script( 'kinsey-elementor-preview', ARTS_THEME_URL . '/js/elementor-preview.min.js', array(), ARTS_THEME_VERSION, true );
}

/**
 * Enqueue Customizer Live Preview Assets
 */
add_action( 'customize_preview_init', 'arts_customize_preview_script' );
function arts_customize_preview_script() {
	wp_enqueue_script( 'kinsey-customizer-preview', ARTS_THEME_URL . '/js/customizer.min.js', array(), ARTS_THEME_VERSION, true );
}
