<?php

/**
 * Enqueue Theme CSS Files
 */
add_action( 'wp_enqueue_scripts', 'arts_enqueue_styles', 20 );
function arts_enqueue_styles() {
	$ajax_enabled        = get_theme_mod( 'ajax_enabled', false );
	$cf_7_modals_enabled = get_theme_mod( 'cf_7_modals_enabled', true );
	/**
	 * Force load Elementor assets
	 * on non-Elementor pages with AJAX turned on
   */
	if ( class_exists( '\Elementor\Frontend' ) && ! arts_is_built_with_elementor() && $ajax_enabled ) {
		/**
		 * @var \Elementor\Core\Base\Module::instance
		 */
		$instance = \Elementor\Frontend::instance();
		$instance->enqueue_styles();
	}

	/**
	 * Fallback font if fonts are not set
	 */
	if ( ! class_exists( 'Kirki' ) ) {
		wp_enqueue_style( 'kinsey-fonts', '//fonts.googleapis.com/css?family=Inter:ital,wght@0,100;0,200;0,300;0,400;0,500;0,700;1,300;1,400;1,500&amp;display=swap', array(), ARTS_THEME_VERSION );
	}

	// hide default Contact Form 7 response boxes if custom modals are enabled
	if ( $cf_7_modals_enabled ) {
		wp_add_inline_style( 'contact-form-7', wp_strip_all_tags( '.wpcf7-mail-sent-ok, .wpcf7 form.sent .wpcf7-response-output, .wpcf7-mail-sent-ng, .wpcf7 form.failed .wpcf7-response-output, .wpcf7 form.invalid .wpcf7-response-output { display: none !important; }' ) );
	}

	wp_enqueue_style( 'bootstrap-grid', ARTS_THEME_URL . '/css/bootstrap-grid.min.css', array(), '5.0.1' );
	wp_enqueue_style( 'bootstrap-reboot', ARTS_THEME_URL . '/css/bootstrap-reboot.min.css', array(), '5.0.1' );
	wp_enqueue_style( 'bootstrap-utilities', ARTS_THEME_URL . '/css/bootstrap-utilities.min.css', array(), '5.0.1' );
	wp_enqueue_style( 'elementor-icons-fa-brands' ); // FontAwesome 5 Brands from Elementor
	wp_enqueue_style( 'material-icons', ARTS_THEME_URL . '/css/material-icons.min.css', array(), '3.0.1' );
	wp_enqueue_style( 'jquery-arts-split-text', ARTS_THEME_URL . '/css/jquery-arts-split-text.min.css', array(), ARTS_THEME_VERSION );
	wp_enqueue_style( 'kinsey-icons', ARTS_THEME_URL . '/css/kinsey-icons.min.css', array(), ARTS_THEME_VERSION );
	wp_enqueue_style( 'kinsey-main-style', ARTS_THEME_URL . '/css/main.css', array(), ARTS_THEME_VERSION );
	wp_enqueue_style( 'kinsey-theme-style', ARTS_THEME_URL . '/style.css', array(), ARTS_THEME_VERSION );
}

/**
 * Enqueue Scripts & Styles in <head>
 */
add_action( 'wp_enqueue_scripts', 'arts_enqueue_polyfills', 20 );
function arts_enqueue_polyfills() {
	$outdated_browsers_enabled = get_theme_mod( 'outdated_browsers_enabled', false );

	if ( $outdated_browsers_enabled ) {
		wp_enqueue_script( 'outdated-browser-rework', ARTS_THEME_URL . '/js/outdated-browser-rework.min.js', array(), '1.1.0', false );
	}

	wp_enqueue_script( 'modernizr', ARTS_THEME_URL . '/js/modernizr.custom.min.js', array(), '3.6.0', false );
}

/**
 * Enqueue Theme JS Files
 */
add_action( 'wp_enqueue_scripts', 'arts_enqueue_scripts', 50 );
function arts_enqueue_scripts() {
	$ajax_enabled = get_theme_mod( 'ajax_enabled', false );

	/**
	 * Force load Elementor assets
	 * on non-Elementor pages with AJAX turned on
	 */
	if ( class_exists( '\Elementor\Frontend' ) && ! arts_is_built_with_elementor() && $ajax_enabled ) {
		/**
		 * @var \Elementor\Core\Base\Module::instance
		 */
		$instance = \Elementor\Frontend::instance();
		$instance->enqueue_scripts();
	}

	if ( is_singular() && comments_open() ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_enqueue_script( 'gsap', ARTS_THEME_URL . '/js/gsap.min.js', array(), '3.9.1', true );
	wp_enqueue_script( 'drawsvg-plugin', ARTS_THEME_URL . '/js/DrawSVGPlugin.min.js', array( 'gsap' ), '3.9.1', true );
	wp_enqueue_script( 'split-text', ARTS_THEME_URL . '/js/SplitText.min.js', array( 'gsap' ), '3.9.1', true );
	wp_enqueue_script( 'scrolltrigger', ARTS_THEME_URL . '/js/ScrollTrigger.min.js', array( 'gsap' ), '3.9.1', true );

	wp_enqueue_script( 'jquery-lazy', ARTS_THEME_URL . '/js/jquery.lazy.min.js', array( 'jquery' ), '1.7.10', true );
	wp_enqueue_script( 'jquery-lazy-plugins', ARTS_THEME_URL . '/js/jquery.lazy.plugins.min.js', array( 'jquery', 'jquery-lazy' ), '1.7.10', true );
	wp_enqueue_script( 'jquery-arts-split-text', ARTS_THEME_URL . '/js/jquery-arts-split-text.min.js', array( 'jquery', 'gsap', 'split-text' ), '1.0.0', true );
	wp_enqueue_script( 'jquery-arts-parallax', ARTS_THEME_URL . '/js/jquery-arts-parallax.min.js', array( 'jquery', 'gsap' ), '1.0.0', true );

	wp_enqueue_script( 'kinsey-base-components', ARTS_THEME_URL . '/modules/base/base.min.js', array( 'jquery', 'gsap', 'scrolltrigger' ), ARTS_THEME_VERSION, true );
	wp_enqueue_script( 'kinsey-components', ARTS_THEME_URL . '/js/components.js', array( 'kinsey-base-components' ), ARTS_THEME_VERSION, true );
}

/**
 * SEO-friendly page
 */
add_action( 'wp_head', 'arts_add_noscript_styles' );
function arts_add_noscript_styles() {
	?>
	<noscript><style>[data-arts-os-animation]:not([data-arts-os-animation=animated])>*,[data-arts-os-animation][data-arts-os-animation-name]:not([data-arts-os-animation=animated]){opacity:inherit;visibility:inherit;pointer-events:inherit!important}[data-arts-os-animation]:not([data-arts-os-animation=animated])>* *,[data-arts-os-animation][data-arts-os-animation-name]:not([data-arts-os-animation=animated]) *{pointer-events:inherit!important}.section-masthead[data-arts-os-animation=true] .section-masthead__wrapper-scroll-down{opacity:inherit;visibility:inherit}img[data-src],video[data-src]{display:none!important}</style></noscript>
	<?php
}
