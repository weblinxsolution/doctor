<?php

/**
 * Generate Styles for the Portfolio Bottom Navigation
 */
add_action( 'wp_enqueue_scripts', 'arts_enqueue_bottom_navigation_styles', 30 );
function arts_enqueue_bottom_navigation_styles() {
	$is_elementor_page         = arts_is_built_with_elementor();
	$bottom_navigation_enabled = get_theme_mod( 'bottom_nav_enabled', true );
	$post_type                 = get_post_type();
	$bottom_nav_post_types     = get_theme_mod( 'bottom_nav_post_types', array( 'arts_portfolio_item' ) );
	$has_bottom_navigation     = $is_elementor_page && $bottom_navigation_enabled && in_array( $post_type, $bottom_nav_post_types );

	if ( $has_bottom_navigation ) {

		$bottom_nav_style                        = get_theme_mod( 'bottom_nav_style', 'auto-scroll' );
		$bottom_nav_direction                    = get_theme_mod( 'bottom_nav_direction', 'previous' );
		$botton_nav_include_portfolio_taxonomies = get_theme_mod( 'botton_nav_include_portfolio_taxonomies', '' );

		if ( $bottom_nav_style === 'auto-scroll' ) {
			$prev_next_args = array( 'direction' => $bottom_nav_direction );

			if ( ! empty( $botton_nav_include_portfolio_taxonomies ) ) {
				$prev_next_args['in_same_term'] = true;
				$prev_next_args['taxonomy']     = $botton_nav_include_portfolio_taxonomies;
			}

			$next_post = arts_get_post_looped_overridden( 'next', $prev_next_args );

			if ( $next_post ) {
				$post_id = get_the_ID();

				$next_page_masthead_header_background_color = arts_get_document_option( 'page_masthead_header_background_color', '#ffffff', $next_post->ID );
				$elementor_css                              = "
				body.elementor-page-{$post_id} .section-nav-projects_post-{$post_id}.section-nav-projects_auto-scroll {
					background-color: {$next_page_masthead_header_background_color};
				}
				";

				wp_add_inline_style( 'kinsey-main-style', trim( $elementor_css ) );
			}
		}

		if ( $bottom_nav_style === 'prev-next' ) {
			$prev_args = array(
				'direction' => $bottom_nav_direction === 'previous' ? 'next' : 'previous',
			);
			$next_args = array(
				'direction' => $bottom_nav_direction === 'previous' ? 'previous' : 'next',
			);

			if ( ! empty( $botton_nav_include_portfolio_taxonomies ) ) {
				$prev_args['in_same_term'] = true;
				$prev_args['taxonomy']     = $botton_nav_include_portfolio_taxonomies;

				$next_args['in_same_term'] = true;
				$next_args['taxonomy']     = $botton_nav_include_portfolio_taxonomies;
			}

			$next_post = arts_get_post_looped_overridden( 'next', $next_args );
			$prev_post = arts_get_post_looped_overridden( 'prev', $prev_args );
			$post_id   = get_the_ID();

			if ( $next_post ) {
				$next_page_masthead_header_background_color = arts_get_document_option( 'page_masthead_header_background_color', '#ffffff', $next_post->ID );
				$css_string                                 = "
				body.elementor-page-{$post_id} .section-nav-projects_post-{$post_id}.section-nav-projects_prev-next .section-nav-projects__item-next {
					background-color: {$next_page_masthead_header_background_color};
				}
				";

				wp_add_inline_style( 'kinsey-main-style', trim( $css_string ) );
			}

			if ( $prev_post ) {
				$prev_page_masthead_header_background_color = arts_get_document_option( 'page_masthead_header_background_color', '#ffffff', $prev_post->ID );
				$css_string                                 = "
				body.elementor-page-{$post_id} .section-nav-projects_post-{$post_id}.section-nav-projects_prev-next .section-nav-projects__item-prev {
					background-color: {$prev_page_masthead_header_background_color};
				}
				";

				wp_add_inline_style( 'kinsey-main-style', trim( $css_string ) );
			}
		}
	}
}
