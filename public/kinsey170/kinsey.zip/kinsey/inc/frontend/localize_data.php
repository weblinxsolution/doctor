<?php

/**
 * Localize Theme Options
 */
add_action( 'wp_enqueue_scripts', 'arts_localize_data', 60 );
function arts_localize_data() {

	$animations_trigger_hook = get_theme_mod( 'animations_trigger_hook', 0.15 );

	$animations_on_scroll_reveal_timescale        = get_theme_mod( 'animations_on_scroll_reveal_timescale', 1 );
	$animations_overlay_menu_open_timescale       = get_theme_mod( 'animations_overlay_menu_open_timescale', 1 );
	$animations_overlay_menu_close_timescale      = get_theme_mod( 'animations_overlay_menu_close_timescale', 1 );
	$animations_preloader_timescale               = get_theme_mod( 'animations_preloader_timescale', 0.9 );
	$animations_ajax_transition_curtain_timescale = get_theme_mod( 'animations_ajax_transition_curtain_timescale', 1.0 );
	$animations_ajax_transition_image_timescale   = get_theme_mod( 'animations_ajax_transition_image_timescale', 1.0 );
	$animations_scroll_down_enabled               = get_theme_mod( 'animations_scroll_down_enabled', true );

	$ajax_enabled                         = get_theme_mod( 'ajax_enabled', false );
	$ajax_prevent_rules                   = rtrim( get_theme_mod( 'ajax_prevent_rules' ), ',' ); // remove all commas off the string
	$ajax_prevent_woocommerce_pages       = get_theme_mod( 'ajax_prevent_woocommerce_pages', false );
	$ajax_eval_inline_container_scripts   = get_theme_mod( 'ajax_eval_inline_container_scripts', true );
	$ajax_load_missing_scripts            = get_theme_mod( 'ajax_load_missing_scripts', true );
	$ajax_load_missing_styles             = get_theme_mod( 'ajax_load_missing_styles', true );
	$ajax_update_script_nodes             = get_theme_mod( 'ajax_update_script_nodes' );
	$ajax_update_content_nodes            = rtrim( get_theme_mod( 'ajax_update_content_nodes', '' ), ',' );
	$ajax_update_widget_contents          = get_theme_mod( 'ajax_update_widget_contents', false );
	$ajax_update_content_elementor_header = get_theme_mod( 'ajax_update_content_elementor_header', true );

	$ajax_custom_js         = get_theme_mod( 'ajax_custom_js' );
	$ajax_update_head_nodes = get_theme_mod( 'ajax_update_head_nodes' );

	$cf_7_modals_enabled = get_theme_mod( 'cf_7_modals_enabled', true );

	$mobile_bar_fix_enabled = get_theme_mod( 'mobile_bar_fix_enabled', true );
	$mobile_bar_fix_update  = get_theme_mod( 'mobile_bar_fix_update', true );

	$high_performance_gpu_enabled = get_theme_mod( 'high_performance_gpu_enabled', true );

	if ( $ajax_enabled &&
			 $ajax_prevent_woocommerce_pages &&
			 class_exists( 'woocommerce' ) &&
			 function_exists( 'arts_get_woocommerce_urls' ) ) {

			// add AJAX rules that prevents all "TO" WooCommerce pages
			$woocommerce_urls        = arts_get_woocommerce_urls();
			$woocommerce_urls_string = '';

		foreach ( $woocommerce_urls as $url ) {
			if ( ! empty( $url ) ) {
				$woocommerce_urls_string .= 'a[href*="' . $url . '"],';
			}
		}

			$ajax_prevent_rules .= $woocommerce_urls_string;

			// add AJAX rule that prevents all the links "FROM" WooCommerce pages to other website pages
			$ajax_prevent_rules .= '.woocommerce-page a';

	}

	wp_localize_script(
		'kinsey-components',
		'theme',
		array(
			'isFirstLoad'         => true,
			'isSliderMenuLoaded'  => false,
			'isCustomizerPreview' => is_customize_preview(),
			'themeURL'            => esc_js( ARTS_THEME_URL ),
			'ajaxURL'             => admin_url( 'admin-ajax.php' ),
			'ajax'                => array(
				'isRunning'                     => false,
				'enabled'                       => esc_js( $ajax_enabled ),
				'customJS'                      => trim( $ajax_custom_js ),
				'preventRules'                  => $ajax_prevent_rules,
				'evalInlineContainerScripts'    => esc_js( $ajax_eval_inline_container_scripts ),
				'loadMissingScripts'            => esc_js( $ajax_load_missing_scripts ),
				'loadMissingStyles'             => esc_js( $ajax_load_missing_styles ),
				'updateContentNodes'            => $ajax_update_content_nodes,
				'updateWidgetContents'          => esc_js( $ajax_update_widget_contents ),
				'updateElementorHeaderContents' => esc_js( $ajax_update_content_elementor_header ),
				'updateScriptNodes'             => $ajax_update_script_nodes,
				'updateHeadNodes'               => esc_js( $ajax_update_head_nodes ),
			),
			'animations'          => array(
				'triggerHook' => esc_js( $animations_trigger_hook ),
				'timeScale'   => array(
					'onScrollReveal'            => esc_js( $animations_on_scroll_reveal_timescale ),
					'overlayMenuOpen'           => esc_js( $animations_overlay_menu_open_timescale ),
					'overlayMenuClose'          => esc_js( $animations_overlay_menu_close_timescale ),
					'preloader'                 => esc_js( $animations_preloader_timescale ),
					'ajaxCurtainTransition'     => esc_js( $animations_ajax_transition_curtain_timescale ),
					'ajaxFlyingImageTransition' => esc_js( $animations_ajax_transition_image_timescale ),
				),
				'scrollDown'  => array(
					'enabled' => esc_js( $animations_scroll_down_enabled ),
				),
			),
			'contactForm7'        => array(
				'customModals' => esc_js( $cf_7_modals_enabled ),
			),
			'mobileBarFix'        => array(
				'enabled' => esc_js( $mobile_bar_fix_enabled ),
				'update'  => esc_js( $mobile_bar_fix_update ),
			),
			'elementor'           => array(
				'isEditor' => esc_js( arts_is_elementor_editor_active() ),
				'features' => array(
					'optimizedAssetsLoading' => esc_js( arts_is_elementor_feature_active( 'e_optimized_assets_loading' ) ),
				),
			),
			'promises'            => array(),
			'highPerformance'     => esc_js( $high_performance_gpu_enabled ),
			'assets'              => array(
				'section-fixed-reveal-js' => array(
					'id'      => 'section-fixed-reveal-js',
					'type'    => 'script',
					'src'     => ARTS_THEME_URL . '/modules/sectionFixedReveal/sectionFixedReveal.min.js',
					'cache'   => true,
					'version' => ARTS_THEME_VERSION,
				),
				'section-grid-js'         => array(
					'id'      => 'section-grid-js',
					'type'    => 'script',
					'src'     => ARTS_THEME_URL . '/modules/sectionGrid/sectionGrid.min.js',
					'cache'   => true,
					'version' => ARTS_THEME_VERSION,
				),
				'section-grid-css'        => array(
					'id'      => 'section-grid-css',
					'type'    => 'style',
					'src'     => ARTS_THEME_URL . '/modules/sectionGrid/sectionGrid.min.css',
					'cache'   => true,
					'version' => ARTS_THEME_VERSION,
				),
				'comments-js'             => array(
					'id'      => 'comments-js',
					'type'    => 'script',
					'src'     => ARTS_THEME_URL . '/modules/comments/comments.min.js',
					'cache'   => true,
					'version' => ARTS_THEME_VERSION,
				),
				'bootstrap-modal-js'      => array(
					'id'      => 'bootstrap-modal-js',
					'type'    => 'script',
					'src'     => ARTS_THEME_URL . '/js/bootstrap-modal.min.js',
					'cache'   => true,
					'version' => '4.3.1',
				),
				'bootstrap-util-js'       => array(
					'id'      => 'bootstrap-util-js',
					'type'    => 'script',
					'src'     => ARTS_THEME_URL . '/js/bootstrap-util.min.js',
					'cache'   => true,
					'version' => '4.3.1',
				),
				'pjax-js'                 => array(
					'id'      => 'pjax-js',
					'type'    => 'script',
					'src'     => ARTS_THEME_URL . '/modules/PJAX/PJAX.min.js',
					'cache'   => true,
					'version' => ARTS_THEME_VERSION,
				),
				'swiper-js'               => array(
					'id'      => 'swiper-js',
					'type'    => 'script',
					'src'     => ARTS_THEME_URL . '/js/swiper-bundle.min.js',
					'cache'   => true,
					'version' => '6.8.0',
				),
				'slider-menu-js'          => array(
					'id'      => 'slider-menu-js',
					'type'    => 'script',
					'src'     => ARTS_THEME_URL . '/modules/sliderMenu/sliderMenu.min.js',
					'cache'   => true,
					'version' => ARTS_THEME_VERSION,
				),
				'slider-menu-css'         => array(
					'id'      => 'slider-menu-css',
					'type'    => 'style',
					'src'     => ARTS_THEME_URL . '/modules/sliderMenu/sliderMenu.min.css',
					'cache'   => true,
					'version' => ARTS_THEME_VERSION,
				),
			),
		)
	);
}
