<?php

/**
 * Enqueue assets for admin widgets editor
 */
add_action( 'wp_enqueue_scripts', 'arts_enqueue_block_widgets_styles' );
function arts_enqueue_block_widgets_styles() {
	if ( is_admin() && ! wp_style_is( 'elementor-icons-fa-brands' ) && defined( 'ELEMENTOR_ASSETS_URL' ) ) {
		wp_register_style( 'elementor-icons-shared-0', ELEMENTOR_ASSETS_URL . 'lib/font-awesome/css/fontawesome.min.css', array(), '5.15.3' );
		wp_register_style( 'elementor-icons-fa-brands', ELEMENTOR_ASSETS_URL . 'lib/font-awesome/css/brands.min.css', array( 'elementor-icons-shared-0' ), '5.15.3' );
	}
}
