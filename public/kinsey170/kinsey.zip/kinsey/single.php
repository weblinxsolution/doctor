<?php

$is_elementor_page         = arts_is_built_with_elementor();
$masthead_template         = $is_elementor_page ? arts_get_document_option( 'page_masthead_layout', '' ) : '';
$post_type                 = get_post_type();
$bottom_navigation_enabled = get_theme_mod( 'bottom_nav_enabled', true );
$bottom_nav_style          = get_theme_mod( 'bottom_nav_style', 'auto-scroll' );
$bottom_nav_post_types     = get_theme_mod( 'bottom_nav_post_types', array( 'arts_portfolio_item' ) );
$has_bottom_navigation     = $is_elementor_page && $bottom_navigation_enabled && in_array( $post_type, $bottom_nav_post_types );

get_header();

/**
 * Page Masthead
 */
get_template_part( 'template-parts/masthead/masthead', esc_attr( $masthead_template ) );
the_post();
?>

<?php if ( ! $is_elementor_page ) : ?>
	<section class="section py-medium section-blog">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col">
					<div class="post">
						<div class="post__content clearfix">
							<?php the_content(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php else : ?>
	<?php the_content(); ?>
<?php endif; ?>

<?php

/**
 * Page Bottom Navigation
 */
if ( $has_bottom_navigation ) {
	get_template_part( 'template-parts/bottom-navigation/bottom-navigation', esc_attr( $bottom_nav_style ) );
}

get_footer();
