<?php

$preloader_enabled                                   = arts_is_preloader_enabled();
$ajax_enabled                                        = get_theme_mod( 'ajax_enabled', false );
$header_container                                    = get_theme_mod( 'header_container', 'container-fluid' );
$header_layout                                       = arts_get_header_layout();
$header_attributes                                   = arts_get_header_attributes();
$main_container_attributes                           = arts_get_main_container_attributes();
$has_hfe_header                                      = arts_hfe_header_enabled();
$elementor_header_footer_builder_header_render_place = get_theme_mod( 'elementor_header_footer_builder_header_render_place', 'outside' );

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>"/>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<?php
	if ( function_exists( 'wp_body_open' ) ) {
		wp_body_open();
	}
	?>

	<?php if ( $ajax_enabled ) : ?>
		<div data-barba="wrapper">
	<?php endif; ?>

	<?php if ( $preloader_enabled ) : ?>
		<!-- PAGE PRELOADER -->
		<?php get_template_part( 'template-parts/preloader/preloader' ); ?>
		<!-- - PAGE PRELOADER -->
	<?php endif; ?>

	<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'header' ) ) : ?>
		<?php if ( $has_hfe_header ) : ?>
			<?php if ( $elementor_header_footer_builder_header_render_place === 'outside' ) : ?>
				<?php arts_hfe_render_header(); ?>
			<?php endif; ?>
		<?php else : ?>
			<!-- PAGE HEADER -->
			<header <?php arts_print_attributes( $header_attributes ); ?>>
				<!-- top bar -->
				<div class="header__container header__controls <?php echo esc_attr( $header_container ); ?>">
					<?php get_template_part( 'template-parts/header/header', $header_layout ); ?>
				</div>
				<!-- - top bar -->
				<!-- fullscreen overlay container -->
				<?php get_template_part( 'template-parts/header/partials/fullscreen-overlay-container' ); ?>
				<!-- - fullscreen overlay container -->
			</header>
			<!-- - PAGE HEADER -->
		<?php endif; ?>
	<?php endif; ?>

	<!-- PAGE MAIN CONTAINER -->
	<div <?php arts_print_attributes( $main_container_attributes ); ?>>
		<?php if ( function_exists( 'elementor_theme_do_location' ) ) : ?>
			<?php elementor_theme_do_location( 'popup' ); ?>
		<?php endif; ?>
		<!-- PAGE CONTENT -->
		<main class="page-wrapper__content">
			<?php if ( $has_hfe_header && $elementor_header_footer_builder_header_render_place === 'inside' ) : ?>
				<?php arts_hfe_render_header(); ?>
			<?php endif; ?>
