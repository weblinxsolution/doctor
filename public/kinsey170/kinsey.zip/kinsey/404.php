<?php

$page_404_title             = get_theme_mod( '404_title', __( 'Error 404', 'kinsey' ) );
$page_404_message           = get_theme_mod( '404_message', __( 'It looks like nothing found here. Try to navigate the menu or return to the home page.', 'kinsey' ) );
$page_404_background        = get_theme_mod( '404_background', 'bg-dark-1' );
$page_404_text_theme        = get_theme_mod( '404_text_theme', 'light' );
$page_404_title_preset      = get_theme_mod( '404_title_preset', 'xxl' );
$page_404_message_preset    = get_theme_mod( '404_message_preset', 'h3' );
$page_404_button_normal     = get_theme_mod( '404_button_normal', __( 'Take Me Home', 'kinsey' ) );
$page_404_button_hover      = get_theme_mod( '404_button_hover', __( 'Take Me Home', 'kinsey' ) );
$page_404_animation_enabled = true;

$section_attributes = array(
	'class'                => array( 'section', 'section-content', 'section-fullheight', 'section-404', $page_404_background ),
	'data-arts-theme-text' => $page_404_text_theme,
);

$wrapper_content_attributes = array(
	'class' => array( 'section-content__content', 'content' ),
);

$wrapper_button_attributes = array(
	'class' => array( 'section-content__wrapper-button', 'mt-md-5', 'mt-4' ),
);

$button_args = array(
	'title'       => $page_404_button_normal,
	'title_hover' => $page_404_button_hover,
	'attributes'  => array(
		'href'  => home_url( '/' ),
		'class' => array( 'button', 'button-circle', 'button-circle_big', 'button_bordered', 'bg-light-1', 'js-arts-cursor-no-highlight' ),
	),
);

$button_args['attributes'] = arts_get_cursor_attributes_theme_mod( $button_args['attributes'], '404_cursor_button' );

if ( $page_404_animation_enabled ) {
	$wrapper_content_attributes = arts_get_split_text_attributes( $wrapper_content_attributes );
	$wrapper_button_attributes  = arts_get_animation_attributes( $wrapper_button_attributes, 'animateJump' );
}

?>

<?php get_header(); ?>

<!-- section 404 -->
<section <?php arts_print_attributes( $section_attributes ); ?>>
	<div class="section-fullheight__inner section-fullheight__inner_mobile section__content container pt-xlarge pb-large">
		<div class="row justify-content-center text-center">
			<div class="col-lg-8">
				<div <?php arts_print_attributes( $wrapper_content_attributes ); ?>>
					<?php if ( ! empty( $page_404_title ) ) : ?>
						<h1 class="section-404__heading mb-0 <?php echo esc_attr( $page_404_title_preset ); ?>"><?php echo esc_html( $page_404_title ); ?></h1>
					<?php endif; ?>
					<?php if ( ! empty( $page_404_message ) ) : ?>
						<p class="section-404__text <?php echo esc_attr( $page_404_message_preset ); ?>"><?php echo esc_html( $page_404_message ); ?></p>
					<?php endif; ?>
				</div>
				<div <?php arts_print_attributes( $wrapper_button_attributes ); ?>>
					<?php get_template_part( 'template-parts/button/button', 'normal', $button_args ); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- - section 404 -->

<?php get_footer(); ?>
