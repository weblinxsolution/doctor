<?php

$ajax_enabled                 = get_theme_mod( 'ajax_enabled', false );
$ajax_spinner_desktop_enabled = get_theme_mod( 'ajax_spinner_desktop_enabled', false );
$ajax_spinner_mobile_enabled  = get_theme_mod( 'ajax_spinner_mobile_enabled', true );
$outdated_browsers_enabled    = get_theme_mod( 'outdated_browsers_enabled', false );
$has_footer_active_sidebars   = arts_has_footer_active_sidebars();
$is_404_footer_removed        = is_404() && get_theme_mod( 'page_404_footer_removed', true );

$footer_hidden     = arts_get_overridden_document_option( 'footer_hide', 'page_footer_settings_overridden', '' );
$footer_attributes = arts_get_footer_attributes();

?>
		<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) : ?>
			<?php if ( function_exists( 'hfe_render_footer' ) && arts_hfe_footer_enabled() ) : ?>
				<?php arts_hfe_render_footer(); ?>
			<?php else : ?>
				<?php if ( $has_footer_active_sidebars && ! $is_404_footer_removed && ! $footer_hidden ) : ?>
					<!-- PAGE FOOTER -->
					<footer <?php arts_print_attributes( $footer_attributes ); ?>>
						<?php get_template_part( 'template-parts/footer/footer' ); ?>
					</footer>
					<!-- - PAGE FOOTER -->
				<?php endif; ?>
			<?php endif; ?>
		<?php endif; ?>
	</main>
	<!-- - PAGE CONTENT -->
	</div>
	<!-- - PAGE MAIN CONTAINER -->
	<?php if ( $ajax_enabled ) : ?>
			<!-- Curtain Cursor Blocking -->
			<div class="blocking-curtain" id="js-page-blocking-curtain"></div>
			<!-- - Curtain Cursor Blocking -->
		</div>
		<?php if ( $ajax_spinner_desktop_enabled || $ajax_spinner_mobile_enabled ) : ?>
			<!-- Loading Spinner -->
			<?php get_template_part( 'template-parts/spinner/spinner' ); ?>
			<!-- - Loading Spinner -->
		<?php endif; ?>
		<!-- Curtain AJAX Transition -->
		<div class="transition-curtain" id="js-page-transition-curtain"></div>
		<!-- - Curtain AJAX Transition -->
	<?php endif; ?>
	<?php if ( $outdated_browsers_enabled ) : ?>
		<div id="outdated"></div>
	<?php endif; ?>
	<canvas id="js-webgl"></canvas>
	<?php wp_footer(); ?>
</body>
</html>
