<?php

global $post;

$is_elementor_page         = arts_is_built_with_elementor();
$masthead_template         = $is_elementor_page ? arts_get_document_option( 'page_masthead_layout', '' ) : '';
$post_type                 = get_post_type();
$bottom_navigation_enabled = get_theme_mod( 'bottom_nav_enabled', true );
$bottom_nav_style          = get_theme_mod( 'bottom_nav_style', 'auto-scroll' );
$bottom_nav_post_types     = get_theme_mod( 'bottom_nav_post_types', array( 'arts_portfolio_item' ) );
$has_bottom_navigation     = $is_elementor_page && $bottom_navigation_enabled && in_array( $post_type, $bottom_nav_post_types );

$container_attributes = array(
	'class' => array( 'container' ),
);

get_header();

/**
 * Page Masthead
 */
get_template_part( 'template-parts/masthead/masthead', esc_attr( $masthead_template ) );
the_post();

if ( trim( $post->post_content ) !== '' ) {
	$container_attributes['class'][] = 'py-medium';
}

?>

<?php if ( ! $is_elementor_page ) : ?>
	<section class="section section-blog container-fluid container-fluid_paddings container_p-md-0 pt-0">
		<div class="section-blog__inner bg-white-1">
			<div <?php arts_print_attributes( $container_attributes ); ?>>
				<div class="row justify-content-center">
					<div class="col-lg-10 section-blog__post">
						<div class="post">
							<!-- post content -->
							<div class="post__content clearfix">
								<?php the_content(); ?>
							</div>
							<?php
								wp_link_pages(
									array(
										'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'kinsey' ),
										'after'       => '</div>',
										'link_before' => '<span class="page-number">',
										'link_after'  => '</span>',
									)
								);
							?>
							<!-- - post content -->
							<?php if ( comments_open() || get_comments_number() ) : ?>
								<!-- post comments -->
								<div class="post__comments mt-small" data-barba-prevent="all">
									<?php comments_template(); ?>
								</div>
								<!-- - post comments -->
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php else : ?>
	<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single-page' ) ) : // Elementor "page" location ?>
		<?php the_content(); ?>
	<?php endif; ?>
<?php endif; ?>

<?php

/**
 * Page Bottom Navigation
 */
if ( $has_bottom_navigation ) {
	get_template_part( 'template-parts/bottom-navigation/bottom-navigation', esc_attr( $bottom_nav_style ) );
}

get_footer();
