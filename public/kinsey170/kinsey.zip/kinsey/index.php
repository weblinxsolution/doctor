<?php

get_header();
get_template_part( 'template-parts/masthead/masthead', 'blog' );
get_template_part( 'template-parts/blog/blog' );
get_footer();
