<?php

if ( post_password_required() ) {
	return;
}

require_once ARTS_THEME_PATH . '/inc/classes/class-arts-walker-comment.php';

$blog_ajax_comments_enabled = get_theme_mod( 'blog_ajax_comments_enabled', false );

$comments_attributes = array(
	'id'    => 'comments',
	'class' => array( 'comments-area' ),
);

if ( $blog_ajax_comments_enabled ) {
	$comments_attributes['class'][] = 'js-ajax-comments-area';
}

?>

<div <?php arts_print_attributes( $comments_attributes ); ?>>
	<?php if ( have_comments() ) : ?>
		<h4 class="comments-title">
			<?php
			$comments_number = get_comments_number();
			if ( $comments_number === '1' ) {
				$output = sprintf( '%1$s %2$s', $comments_number, esc_html__( 'Comment', 'kinsey' ) );
				echo esc_html( $output );
			} else {
				$output = sprintf( '%1$s %2$s', $comments_number, esc_html__( 'Comments', 'kinsey' ) );
				echo esc_html( $output );
			}
			?>
		</h4>

		<ol class="comment-list">
			<?php
				wp_list_comments(
					array(
						'avatar_size' => 80,
						'style'       => 'ol',
						'short_ping'  => true,
						'walker'      => new Arts_Walker_Comment(),
					)
				);
			?>
		</ol>

		<?php the_comments_pagination(); ?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'kinsey' ); ?></p>
	<?php endif; ?>

	<?php
		comment_form(
			array(
				'title_reply_before' => '<h4 id="reply-title" class="comment-reply-title">',
				'title_reply_after'  => '</h4>',
			)
		);
		?>
</div>
