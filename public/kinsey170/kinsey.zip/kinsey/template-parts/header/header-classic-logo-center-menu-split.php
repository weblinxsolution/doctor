<?php

/* Logo Center + Menu Split */

$has_menu              = has_nav_menu( 'main_menu' );
$has_additional_menu   = has_nav_menu( 'additional_menu' );
$burger_col_attributes = array(
	'class' => array(
		'header__col',
		'd-flex',
		'd-lg-none',
		'align-items-center',
		'col-auto',
	),
);

?>

<div class="row justify-content-between align-items-center">
	<!-- logo -->
	<div class="col-auto col-lg-2 order-lg-2 header__col header__col-left text-lg-center">
		<?php get_template_part( 'template-parts/logo/logo' ); ?>
	</div>
	<!-- - logo -->
	<!-- LEFT desktop only menu -->
	<div class="col-auto col-lg-5 order-lg-1 header__col header__col-left d-none d-lg-block text-lg-start">
		<?php get_template_part( 'template-parts/menu/menu', 'classic', array( 'location' => 'main_menu' ) ); ?>
	</div>
	<!-- - LEFT desktop only menu -->
	<!-- RIGHT desktop only menu -->
	<div class="col-auto col-lg-5 order-lg-3 header__col header__col-right d-none d-lg-block text-lg-end">
		<?php get_template_part( 'template-parts/menu/menu', 'classic', array( 'location' => 'additional_menu' ) ); ?>
	</div>
	<!-- - RIGHT desktop only menu -->
	<?php if ( $has_menu || $has_additional_menu ) : ?>
		<!-- burger icon -->
		<div <?php arts_print_attributes( $burger_col_attributes ); ?>>
			<?php get_template_part( 'template-parts/header/partials/button', 'burger' ); ?>
		</div>
		<!-- - burger icon -->
		<!-- "back" button for submenu nav -->
		<?php get_template_part( 'template-parts/header/partials/button', 'back' ); ?>
		<!-- - "back" button for submenu nav -->
		<!-- sidebar label -->
		<?php get_template_part( 'template-parts/header/partials/sidebar-label' ); ?>
		<!-- - sidebar label -->
	<?php endif; ?>
</div>
