<?php

/* Logo Left + Burger Center */

$widget_area_id                   = 'header-sidebar';
$ajax_prevent_header_widgets_area = get_theme_mod( 'ajax_prevent_header_widgets_area', true );
$header_widget_area_enabled       = get_theme_mod( 'header_widget_area_enabled', false );
$has_widgets                      = $header_widget_area_enabled && is_active_sidebar( $widget_area_id );
$has_menu                         = has_nav_menu( 'main_menu' );

$burger_col_attributes = array(
	'class' => array(
		'col-4',
		'header__col',
		'text-md-center',
		'text-end',
		'd-flex',
		'align-items-center',
		'justify-content-md-center',
		'justify-content-end',
	),
);

$wrapper_widgets_attributes = array(
	'class' => array( 'header__wrapper-widgets' ),
);

if ( $ajax_prevent_header_widgets_area ) {
	$wrapper_widgets_attributes['data-barba-prevent'] = 'all';
}

?>

<div class="row justify-content-between align-items-center">
	<!-- logo -->
	<div class="col-4 header__col header__col-left text-start">
		<?php get_template_part( 'template-parts/logo/logo' ); ?>
	</div>
	<!-- - logo -->
	<?php if ( $has_menu ) : ?>
		<!-- burger icon -->
		<div <?php arts_print_attributes( $burger_col_attributes ); ?>>
			<?php get_template_part( 'template-parts/header/partials/button', 'burger' ); ?>
		</div>
		<!-- - burger icon -->
		<div class="col-4 header__col header__col-right text-end d-md-block d-none">
			<?php if ( $has_widgets ) : ?>
				<!-- widget area -->
				<div <?php arts_print_attributes( $wrapper_widgets_attributes ); ?>>
					<?php dynamic_sidebar( $widget_area_id ); ?>
				</div>
				<!-- - widget area -->
			<?php endif; ?>
		</div>
		<!-- "back" button for submenu nav -->
		<?php get_template_part( 'template-parts/header/partials/button', 'back' ); ?>
		<!-- - "back" button for submenu nav -->
		<!-- sidebar label -->
		<?php get_template_part( 'template-parts/header/partials/sidebar-label' ); ?>
		<!-- - sidebar label -->
	<?php endif; ?>
</div>
