<?php

$burger_attributes = array(
	'id'    => 'js-burger',
	'class' => array( 'header__burger' ),
);

$burger_attributes = arts_get_cursor_attributes_theme_mod( $burger_attributes, 'menu_cursor_burger_button' );

$header_overlay_menu_burger_style = get_theme_mod( 'header_overlay_menu_burger_style', 2 );
$menu_label_burger_closed_open    = get_theme_mod( 'menu_label_burger_closed_open', __( 'Menu', 'kinsey' ) );
$menu_label_burger_closed_hover   = get_theme_mod( 'menu_label_burger_closed_hover', __( 'Open', 'kinsey' ) );
$menu_label_burger_opened_open    = get_theme_mod( 'menu_label_burger_opened_open', __( 'Close', 'kinsey' ) );
$menu_label_burger_opened_hover   = get_theme_mod( 'menu_label_burger_opened_hover', __( 'Close', 'kinsey' ) );

?>

<div <?php arts_print_attributes( $burger_attributes ); ?>>
	<?php for ( $i = 0; $i < $header_overlay_menu_burger_style; $i++ ) : ?>
		<div class="header__burger-line"></div>
	<?php endfor; ?>
	<?php
	if (
		! empty( $menu_label_burger_closed_open ) ||
		! empty( $menu_label_burger_closed_hover ) ||
		! empty( $menu_label_burger_opened_open ) ||
		! empty( $menu_label_burger_opened_hover )
		) :
		?>
		<!-- burger labels -->
		<div class="header__label header__burger-label">
			<div class="header__label-burger header__label-burger_inner header__label-burger_closed-open"><?php echo esc_html( $menu_label_burger_closed_open ); ?></div>
			<div class="header__label-burger header__label-burger_inner header__label-burger_closed-hover"><?php echo esc_html( $menu_label_burger_closed_hover ); ?></div>
			<div class="header__label-burger header__label-burger_inner header__label-burger_opened-open"><?php echo esc_html( $menu_label_burger_opened_open ); ?></div>
			<div class="header__label-burger header__label-burger_inner header__label-burger_opened-hover"><?php echo esc_html( $menu_label_burger_opened_hover ); ?></div>
		</div>
		<!-- - burger labels -->
	<?php endif; ?>
</div>
