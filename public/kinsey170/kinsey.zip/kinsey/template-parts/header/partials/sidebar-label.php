<?php

$sidebar_label_attributes = array(
	'class' => array(
		'header__overlay-menu-info',
		'header__label',
		'header__label_side',
	),
);

$fullscreen_sidebar_label          = get_theme_mod( 'fullscreen_sidebar_label', __( 'Selected Projects', 'kinsey' ) );
$fullscreen_sidebar_label_position = get_theme_mod( 'fullscreen_sidebar_label_position', 'left' );
$fullscreen_sidebar_position       = get_theme_mod( 'fullscreen_sidebar_position', 'left' );
$fullscreen_sidebar_style          = get_theme_mod( 'fullscreen_sidebar_style', 'slider' );
$fullscreen_sidebar_col            = get_theme_mod( 'fullscreen_sidebar_col', 5 );

if ( $fullscreen_sidebar_position === 'right' ) {

	if ( $fullscreen_sidebar_label_position === 'right' ) {
		$sidebar_label_attributes['class'][] = 'right-lg-0';
	} else {
		$sidebar_label_attributes['class'][] = 'left-lg-' . intval( 12 - $fullscreen_sidebar_col );
	}
} else {
	if ( $fullscreen_sidebar_label_position === 'right' ) {
		$sidebar_label_attributes['class'][] = 'right-lg-' . intval( 12 - $fullscreen_sidebar_col );
	}
}

?>

<?php if ( ! empty( $fullscreen_sidebar_style ) && ! empty( $fullscreen_sidebar_label ) ) : ?>
	<div <?php arts_print_attributes( $sidebar_label_attributes ); ?>><?php echo esc_html( $fullscreen_sidebar_label ); ?></div>
<?php endif; ?>
