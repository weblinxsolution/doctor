<?php

$back_attributes                      = array(
	'id'    => 'js-submenu-back',
	'class' => array( 'header__overlay-menu-back' ),
);
$menu_label_burger_opened_back_hover  = get_theme_mod( 'menu_label_burger_opened_back_hover', __( 'Back', 'kinsey' ) );
$menu_label_burger_opened_back_normal = get_theme_mod( 'menu_label_burger_opened_back_normal', __( 'Back', 'kinsey' ) );
$menu_label_burger_opened_back_style  = get_theme_mod( 'menu_label_burger_opened_back_style', 'current_submenu_item' );

$header_layout_fullscreen    = get_theme_mod( 'header_layout_fullscreen', 'fullscreen-logo-left-burger-right' );
$fullscreen_sidebar_style    = get_theme_mod( 'fullscreen_sidebar_style', 'slider' );
$fullscreen_sidebar_position = get_theme_mod( 'fullscreen_sidebar_position', 'left' );
$fullscreen_sidebar_col      = get_theme_mod( 'fullscreen_sidebar_col', 5 );

$back_attributes = arts_get_cursor_attributes_theme_mod( $back_attributes, 'menu_cursor_submenu_button' );

if ( ! empty( $menu_label_burger_opened_back_hover ) ) {
	$back_attributes['class'][] = 'header__overlay-menu-back_hover';
}

if ( $fullscreen_sidebar_style && $fullscreen_sidebar_position === 'left' ) {
	$back_attributes['class'][] = 'left-lg-' . intval( $fullscreen_sidebar_col );
}

if ( $header_layout_fullscreen === 'fullscreen-logo-center-burger-left' ) {
	if ( ( $fullscreen_sidebar_style && $fullscreen_sidebar_position === 'right' ) || ! $fullscreen_sidebar_style ) {
		$back_attributes['class'][] = 'offset-sm-top';
	}
}

if ( $header_layout_fullscreen === 'fullscreen-logo-left-burger-center' ) {
	if ( ( $fullscreen_sidebar_style && $fullscreen_sidebar_position === 'left' ) ) {
		$back_attributes['class'][] = 'offset-sm-top';
	}
}

?>

<div <?php arts_print_attributes( $back_attributes ); ?>>
	<div class="header__arrow-back">
		<div class="header__arrow-back-line"></div>
		<div class="header__arrow-back-line"></div>
		<div class="header__arrow-back-line"></div>
	</div>
	<!-- submenu title holder -->
	<div class="header__label header__label_status">
		<?php if ( $menu_label_burger_opened_back_style === 'current_submenu_item' ) : ?>
			<div class="js-header-label-submenu"></div>
		<?php else : ?>
			<?php echo esc_html( $menu_label_burger_opened_back_normal ); ?>
		<?php endif; ?>
	</div>
	<!-- - submenu title holder -->
	<?php if ( ! empty( $menu_label_burger_opened_back_hover ) ) : ?>
		<div class="header__label header__label_opened-back"><?php echo esc_html( $menu_label_burger_opened_back_hover ); ?></div>
	<?php endif; ?>
</div>
