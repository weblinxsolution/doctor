<?php

$category_taxonomy                               = 'arts_portfolio_category';
$year_taxonomy                                   = 'arts_portfolio_year';
$fullscreen_sidebar_slider_posts_query           = get_theme_mod( 'fullscreen_sidebar_slider_posts_query', 'all' );
$fullscreen_sidebar_slider_include_posts         = get_theme_mod( 'fullscreen_sidebar_slider_include_posts', array() );
$fullscreen_sidebar_slider_include_by_categories = get_theme_mod( 'fullscreen_sidebar_slider_include_by_categories', '' );
$fullscreen_sidebar_slider_include_by_years      = get_theme_mod( 'fullscreen_sidebar_slider_include_by_years', '' );
$has_included_posts                              = ! empty( $fullscreen_sidebar_slider_include_posts ) && $fullscreen_sidebar_slider_posts_query === 'selected';
$has_filtered_categories                         = ! empty( $fullscreen_sidebar_slider_include_by_categories ) && $fullscreen_sidebar_slider_include_by_categories[0] !== '';
$has_filtered_years                              = ! empty( $fullscreen_sidebar_slider_include_by_years ) && $fullscreen_sidebar_slider_include_by_years[0] !== '';

$args = array(
	'post_type'      => 'arts_portfolio_item',
	'posts_per_page' => -1,
	'no_found_rows'  => true,
);

if ( $has_included_posts ) {
	$args['post__in'] = $fullscreen_sidebar_slider_include_posts;
}

$args = apply_filters( 'arts/customizer/slider_projects/query_args', $args );

if ( $args['post_type'] === 'post' ) {
	$category_taxonomy = 'category';
}

if ( $fullscreen_sidebar_slider_posts_query === 'filtered' ) {
	if ( $has_filtered_categories || $has_filtered_years ) {
		$args['tax_query'] = array();
	}

	if ( $has_filtered_categories ) {
		$args['tax_query'][] = array(
			'taxonomy' => $category_taxonomy,
			'terms'    => $fullscreen_sidebar_slider_include_by_categories,
		);
	}

	if ( $has_filtered_years ) {
		$args['tax_query'][] = array(
			'taxonomy' => $year_taxonomy,
			'terms'    => $fullscreen_sidebar_slider_include_by_years,
		);
	}
}

$loop = new WP_Query( $args );

$fullscreen_sidebar_slider_parallax_opacity_enabled   = get_theme_mod( 'fullscreen_sidebar_slider_parallax_opacity_enabled', true );
$fullscreen_sidebar_slider_parallax_opacity_factor    = get_theme_mod( 'fullscreen_sidebar_slider_parallax_opacity_factor', 0.3 );
$fullscreen_sidebar_slider_parallax_images_enabled    = get_theme_mod( 'fullscreen_sidebar_slider_parallax_images_enabled', true );
$fullscreen_sidebar_slider_parallax_images_factor     = get_theme_mod( 'fullscreen_sidebar_slider_parallax_images_factor', 25 );
$fullscreen_sidebar_slider_thumbnail_size             = get_theme_mod( 'fullscreen_sidebar_slider_thumbnail_size', 'full' );
$fullscreen_sidebar_slider_heading_tag                = get_theme_mod( 'fullscreen_sidebar_slider_heading_tag', 'h3' );
$fullscreen_sidebar_slider_heading_preset             = get_theme_mod( 'fullscreen_sidebar_slider_heading_preset', 'h3' );
$fullscreen_sidebar_slider_categories_years_preset    = get_theme_mod( 'fullscreen_sidebar_slider_categories_years_preset', 'small' );
$fullscreen_sidebar_slider_mouse_drag_enabled         = get_theme_mod( 'fullscreen_sidebar_slider_mouse_drag_enabled', true );
$fullscreen_sidebar_slider_mouse_drag_label           = get_theme_mod( 'fullscreen_sidebar_slider_mouse_drag_label', __( 'Drag', 'kinsey' ) );
$fullscreen_sidebar_slider_mouse_on_drag_cursor_class = get_theme_mod( 'fullscreen_sidebar_slider_mouse_on_drag_cursor_class', 'slider-projects-fullscreen__images_scale-up' );

$slider_attributes = array(
	'class'                   => array( 'slider-menu', 'swiper', 'swiper-container', 'js-slider-menu' ),
	'data-centered-slides'    => 'true',
	'data-speed'              => get_theme_mod( 'fullscreen_sidebar_slider_speed', 1200 ),
	'data-autoplay-enabled'   => get_theme_mod( 'fullscreen_sidebar_slider_autoplay_enabled', false ),
	'data-autoplay-delay'     => get_theme_mod( 'fullscreen_sidebar_slider_autoplay_delay', 6000 ),
	'data-mousewheel-enabled' => get_theme_mod( 'fullscreen_sidebar_slider_mousewheel_enabled', true ),
	'data-keyboard-enabled'   => get_theme_mod( 'fullscreen_sidebar_slider_keyboard_enabled', true ),
);

$wrapper_outer_attributes = array(
	'class' => array( 'slider-menu__wrapper-outer', 'overflow' ),
);

$wrapper_inner_attributes = array(
	'class' => array( 'slider-menu__wrapper-inner', 'w-100', 'h-100' ),
);

$wrapper_opacity_attributes = array(
	'class' => array( 'slider-menu__wrapper-slide' ),
);

$header_attributes = array(
	'class' => 'slider-menu__header',
);

$heading_attributes = array(
	'class' => array( 'slider__heading', 'underline-hover__target', $fullscreen_sidebar_slider_heading_preset, 'mt-0', 'mb-2' ),
);

$subheading_attributes = array(
	'class' => array( 'd-inline-block', 'slider__subheading', $fullscreen_sidebar_slider_categories_years_preset ),
);

if ( $fullscreen_sidebar_slider_mouse_drag_enabled ) {
	$slider_attributes['data-drag-mouse'] = 'true';

	if ( ! empty( $fullscreen_sidebar_slider_mouse_drag_label ) ) {
		$slider_attributes['data-drag-cursor']      = 'true';
		$slider_attributes['data-drag-label']       = $fullscreen_sidebar_slider_mouse_drag_label;
		$slider_attributes['data-drag-hide-cursor'] = 'true';
	}

	if ( ! empty( $fullscreen_sidebar_slider_mouse_on_drag_cursor_class ) ) {
		$slider_attributes['data-drag-class'] = $fullscreen_sidebar_slider_mouse_on_drag_cursor_class;
	}
}

if ( $fullscreen_sidebar_slider_parallax_images_enabled ) {
	$wrapper_outer_attributes['data-swiper-parallax']   = 'true';
	$wrapper_outer_attributes['data-swiper-parallax-y'] = "-{$fullscreen_sidebar_slider_parallax_images_factor}%";

	$wrapper_inner_attributes['data-swiper-parallax']   = 'true';
	$wrapper_inner_attributes['data-swiper-parallax-y'] = "{$fullscreen_sidebar_slider_parallax_images_factor}%";

	$header_attributes['data-swiper-parallax']   = 'true';
	$header_attributes['data-swiper-parallax-y'] = "-{$fullscreen_sidebar_slider_parallax_images_factor}%";
}

if ( $fullscreen_sidebar_slider_parallax_opacity_enabled ) {
	$wrapper_opacity_attributes['data-swiper-parallax']         = 'true';
	$wrapper_opacity_attributes['data-swiper-parallax-opacity'] = $fullscreen_sidebar_slider_parallax_opacity_factor;
}

?>

<?php if ( $loop->have_posts() ) : ?>
	<div <?php arts_print_attributes( $slider_attributes ); ?>>
		<div class="swiper-wrapper">
			<?php while ( $loop->have_posts() ) : ?>
				<?php
					$loop->the_post();

					$id       = get_the_ID();
					$title    = get_the_title();
					$link     = get_the_permalink();
					$image_id = get_post_thumbnail_id();

				$image_link_attributes = array(
					'class'           => 'slider-menu__wrapper-image',
					'href'            => $link,
					'data-arts-hover' => 'trigger',
				);

				$heading_link_attributes = array(
					'class'           => 'd-inline-block',
					'href'            => $link,
					'data-arts-hover' => 'trigger',
				);

				$thumbnail_args = array(
					'id'    => $image_id,
					'size'  => $fullscreen_sidebar_slider_thumbnail_size,
					'type'  => 'background',
					'image' => array(
						'class' => array( 'swiper-lazy', 'of-cover', 'hover-zoom__zoom' ),
					),
				);

				$image_link_attributes   = arts_get_cursor_attributes_theme_mod( $image_link_attributes, 'fullscreen_sidebar_cursor_clickable_links' );
				$heading_link_attributes = arts_get_cursor_attributes_theme_mod( $heading_link_attributes, 'fullscreen_sidebar_cursor_clickable_links' );

				$categories = arts_get_taxonomy_term_names( $id, $category_taxonomy );
				$years      = arts_get_taxonomy_term_names( $id, $year_taxonomy );
				?>
				<!-- item -->
				<div class="swiper-slide slider-menu__slide" data-arts-hover-class="hover-zoom-underline">
					<div <?php arts_print_attributes( $wrapper_opacity_attributes ); ?>>
						<?php if ( ! empty( $image_id ) ) : ?>
							<a <?php arts_print_attributes( $image_link_attributes ); ?>>
								<div <?php arts_print_attributes( $wrapper_outer_attributes ); ?>>
									<div <?php arts_print_attributes( $wrapper_inner_attributes ); ?>>
										<?php get_template_part( 'template-parts/lazy/lazy', 'image', $thumbnail_args ); ?>
									</div>
								</div>
							</a>
						<?php endif; ?>
						<!-- item header -->
						<div <?php arts_print_attributes( $header_attributes ); ?>>
							<?php if ( ! empty( $title ) ) : ?>
								<a <?php arts_print_attributes( $heading_link_attributes ); ?>>
									<<?php echo esc_attr( $fullscreen_sidebar_slider_heading_tag ); ?> <?php arts_print_attributes( $heading_attributes ); ?>><?php echo esc_html( $title ); ?></<?php echo esc_attr( $fullscreen_sidebar_slider_heading_tag ); ?>>
								</a>
							<?php endif; ?>
							<?php if ( ! empty( $categories ) || ! empty( $years ) ) : ?>
								<div class="w-100"></div>
								<div <?php arts_print_attributes( $subheading_attributes ); ?>>
									<?php
										get_template_part(
											'template-parts/list/list',
											'categories',
											array(
												'categories' => $categories,
												'years' => $years,
											)
										);
									?>
								</div>
							<?php endif; ?>
						</div>
						<!-- - item header -->
					</div>
				</div>
			<?php endwhile; ?>
		</div>
		<div class="arts-is-dragging__blocker"></div>
	</div>
	<?php wp_reset_postdata(); ?>
<?php endif; ?>
