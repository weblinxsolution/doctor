<?php

$menu_style                          = get_theme_mod( 'menu_style', 'classic' );
$header_overlay_menu_background      = arts_get_overridden_document_option( 'header_overlay_menu_background', 'page_header_settings_overridden', 'bg-dark-2' );
$header_overlay_menu_elements_theme  = arts_get_overridden_document_option( 'header_overlay_menu_elements_theme', 'page_header_settings_overridden', 'light' );
$header_overlay_menu_overflow_scroll = get_theme_mod( 'header_overlay_menu_overflow_scroll', 'virtual' );
$fullscreen_sidebar_style            = get_theme_mod( 'fullscreen_sidebar_style', 'slider' );
$fullscreen_sidebar_position         = get_theme_mod( 'fullscreen_sidebar_position', 'left' );
$fullscreen_sidebar_col              = get_theme_mod( 'fullscreen_sidebar_col', 5 );
$fullscreen_sidebar_background       = arts_get_overridden_document_option( 'fullscreen_sidebar_background', 'page_header_settings_overridden', 'bg-dark-1' );
$slider_col                          = 'col-lg-' . intval( $fullscreen_sidebar_col );
$menu_col                            = $fullscreen_sidebar_style ? 'col-lg-' . intval( 12 - $fullscreen_sidebar_col ) : 'col-12';
$widget_area_id                      = 'header-sidebar';
$ajax_prevent_header_widgets_area    = get_theme_mod( 'ajax_prevent_header_widgets_area', true );
$header_widget_area_enabled          = get_theme_mod( 'header_widget_area_enabled', false );
$has_widgets                         = $header_widget_area_enabled && is_active_sidebar( $widget_area_id );
$widgets_area_class                  = get_theme_mod( 'menu_overlay_item_vertical_spacing', 'mt-xsmall' );

$overlay_attributes = array(
	'class'                => array( 'header__wrapper-overlay-menu' ),
	'data-arts-theme-text' => $header_overlay_menu_elements_theme,
);

$scroll_container_attributes = array(
	'class' => array( 'header__scroll-container', 'overflow', 'pointer-events-auto' ),
);

$slider_column_attributes = array(
	'class' => array( 'header__slider-column', 'position-relative', 'h-100', 'd-none', 'd-lg-flex', 'flex-column', $fullscreen_sidebar_background, $slider_col ),
);

$menu_column_attributes = array(
	'class' => array( 'header__menu-column', 'position-relative', 'h-100', 'd-flex', 'flex-column', $menu_col, $header_overlay_menu_background ),
);

$wrapper_overlay_widgets_attributes = array(
	'class' => array( 'header__wrapper-overlay-widgets', $widgets_area_class ),
);

if ( $ajax_prevent_header_widgets_area ) {
	$wrapper_overlay_widgets_attributes['data-barba-prevent'] = 'all';
}

if ( $fullscreen_sidebar_style ) {

	if ( $fullscreen_sidebar_position === 'left' ) {
		$slider_column_attributes['class'][] = 'order-lg-1';
		$menu_column_attributes['class'][]   = 'order-lg-2';
	} else {
		$slider_column_attributes['class'][] = 'order-lg-2';
		$menu_column_attributes['class'][]   = 'order-lg-1';
	}
}

if ( $header_overlay_menu_overflow_scroll === 'virtual' ) {
	$scroll_container_attributes['class'][] = 'js-header-smooth-scroll-container';
}

if ( $menu_style === 'classic' ) {
	$overlay_attributes['class'][] = 'd-lg-none';
}

?>

<div <?php arts_print_attributes( $overlay_attributes ); ?>>
	<div class="mask-reveal w-100 h-100">
		<div class="mask-reveal__layer mask-reveal__layer-1 <?php echo esc_attr( $header_overlay_menu_background ); ?>">
			<div class="mask-reveal__layer mask-reveal__layer-2">
				<div class="row align-items-center h-100 g-0">
					<!-- menu -->
					<div <?php arts_print_attributes( $menu_column_attributes ); ?>>
						<!-- top gradient-->
						<div class="header__menu-gradient header__menu-gradient_top"></div>
						<!-- - top gradient-->
						<!-- virtual scrolling container -->
						<div <?php arts_print_attributes( $scroll_container_attributes ); ?>>
							<div class="header__wrapper-menu">
								<?php get_template_part( 'template-parts/menu/menu', 'fullscreen' ); ?>
								<?php if ( $has_widgets ) : ?>
									<!-- fullscreen widget area -->
									<div <?php arts_print_attributes( $wrapper_overlay_widgets_attributes ); ?>>
										<?php dynamic_sidebar( $widget_area_id ); ?>
									</div>
									<!-- - fullscreen widget area -->
								<?php endif; ?>
							</div>
						</div>
						<!-- - virtual scrolling container -->
						<!-- bottom gradient-->
						<div class="header__menu-gradient header__menu-gradient_bottom"></div>
						<!-- - bottom gradient-->
					</div>
					<!-- - menu -->
					<?php if ( $fullscreen_sidebar_style && $menu_style === 'fullscreen' ) : ?>
						<!-- sidebar -->
						<div <?php arts_print_attributes( $slider_column_attributes ); ?>>
							<div class="header__wrapper-slider">
							<?php if ( $fullscreen_sidebar_style === 'slider' ) : ?>
								<!-- featured projects slider -->
								<?php get_template_part( 'template-parts/header/partials/slider-projects' ); ?>
								<!-- - featured projects slider -->
							<?php endif; ?>
							</div>
						</div>
						<!-- - sidebar -->
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
