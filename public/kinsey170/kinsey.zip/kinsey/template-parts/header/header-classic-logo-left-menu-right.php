<?php

/* Logo Left + Menu Right */

$widget_area_id                   = 'header-sidebar';
$ajax_prevent_header_widgets_area = get_theme_mod( 'ajax_prevent_header_widgets_area', true );
$header_widget_area_enabled       = get_theme_mod( 'header_widget_area_enabled', false );
$has_widgets                      = $header_widget_area_enabled && is_active_sidebar( $widget_area_id );
$has_menu                         = has_nav_menu( 'main_menu' );

$burger_col_attributes = array(
	'class' => array(
		'col-auto',
		'header__col',
		'd-flex',
		'd-lg-none',
		'align-items-center',
	),
);

$wrapper_widgets_attributes = array(
	'class' => array( 'header__wrapper-widgets' ),
);

if ( $ajax_prevent_header_widgets_area ) {
	$wrapper_widgets_attributes['data-barba-prevent'] = 'all';
}

?>

<div class="row justify-content-between align-items-center">
	<!-- logo -->
	<div class="col-auto header__col header__col-left">
		<?php get_template_part( 'template-parts/logo/logo' ); ?>
	</div>
	<!-- - logo -->
	<!-- desktop menu only -->
	<div class="col-auto header__col d-none d-lg-block ms-auto">
		<?php get_template_part( 'template-parts/menu/menu', 'classic', array( 'location' => 'main_menu' ) ); ?>
	</div>
	<!-- - desktop menu only -->
	<?php if ( $has_widgets ) : ?>
		<!-- widget area -->
		<div class="col-auto header__col d-lg-block d-none ms-3">
			<div <?php arts_print_attributes( $wrapper_widgets_attributes ); ?>>
				<?php dynamic_sidebar( $widget_area_id ); ?>
			</div>
		</div>
		<!-- - widget area -->
	<?php endif; ?>
		<?php if ( $has_menu ) : ?>
		<!-- burger icon -->
		<div <?php arts_print_attributes( $burger_col_attributes ); ?>>
			<?php get_template_part( 'template-parts/header/partials/button', 'burger' ); ?>
		</div>
		<!-- - burger icon -->
		<!-- "back" button for submenu nav -->
			<?php get_template_part( 'template-parts/header/partials/button', 'back' ); ?>
		<!-- - "back" button for submenu nav -->
		<!-- sidebar label -->
			<?php get_template_part( 'template-parts/header/partials/sidebar-label' ); ?>
		<!-- - sidebar label -->
	<?php endif; ?>
</div>
