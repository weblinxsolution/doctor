<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true" data-arts-theme-text="light">
	<!-- background -->
	<div class="pswp__bg"></div>
	<!-- - background -->
	<!-- slider wrapper -->
	<div class="pswp__scroll-wrap">
		<!-- slides holder (don't modify)-->
		<div class="pswp__container">
			<div class="pswp__item">
				<div class="pswp__img pswp__img--placeholder"></div>
			</div>
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
		</div>
		<!-- - slides holder (don't modify)-->
		<!-- UI -->
		<div class="pswp__ui pswp__ui--hidden">
			<!-- top bar -->
			<div class="pswp__top-bar">
				<div class="pswp__counter"></div>
				<button class="pswp__button pswp__button--close" title="<?php echo esc_html__( 'Close (Esc)', 'kinsey' ); ?>" data-arts-cursor="data-arts-cursor" data-arts-cursor-scale="1.4" data-arts-cursor-magnetic="data-arts-cursor-magnetic" data-arts-cursor-hide-native="true"></button>
				<button class="pswp__button pswp__button--fs" title="Toggle fullscreen" data-arts-cursor="data-arts-cursor" data-arts-cursor-scale="1.4" data-arts-cursor-magnetic="data-arts-cursor-magnetic" data-arts-cursor-hide-native="true"></button>
				<div class="pswp__preloader">
					<div class="pswp__preloader__icn">
						<div class="pswp__preloader__cut">
							<div class="pswp__preloader__donut"></div>
						</div>
					</div>
				</div>
			</div>
			<!-- - top bar -->
			<!-- left arrow -->
			<div class="pswp__button pswp__button--arrow--left material-icons" data-arts-cursor="data-arts-cursor" data-arts-cursor-scale="1.7" data-arts-cursor-magnetic="data-arts-cursor-magnetic" data-arts-cursor-hide-native="true">keyboard_arrow_left</div>
			<!-- - left arrow -->
			<!-- right arrow -->
			<div class="pswp__button pswp__button--arrow--right material-icons" data-arts-cursor="data-arts-cursor" data-arts-cursor-scale="1.7" data-arts-cursor-magnetic="data-arts-cursor-magnetic" data-arts-cursor-hide-native="true">keyboard_arrow_right</div>
			<!-- - right arrow -->
			<!-- slide caption holder (don't modify) -->
			<div class="pswp__caption">
				<div class="pswp__caption__center text-center"></div>
			</div>
			<!-- - slide caption holder (don't modify) -->
		</div>
		<!-- - UI -->
	</div>
	<!-- slider wrapper -->
</div>
