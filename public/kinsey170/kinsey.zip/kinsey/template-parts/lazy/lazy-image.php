<?php

$defaults = array(
	'id'               => null,
	'type'             => 'image',
	'video'            => array(
		'class'      => array(),
		'src'        => null,
		'poster'     => true,
		'attributes' => array(
			'loop'        => true,
			'muted'       => true,
			'playsinline' => true,
		),
	),
	'size'             => 'full',
	'image'            => array(),
	'lazy_wrapper'     => true,
	'outer'            => array(),
	'inner'            => array(),
	'inner_additional' => array(),
	'overlay'          => array(),
	'parallax'         => array(
		'enabled'    => false,
		'outer'      => array(
			'class' => array(),
		),
		'inner'      => array(
			'class' => array(),
		),
		'target'     => 'innerElement',
		'scrub'      => 'true',
		'resistance' => 2,
		'factor'     => array(
			'x' => 0,
			'y' => 0,
		),
		'translate'  => array(
			'from' => array(
				'x' => 0,
				'y' => 0,
			),
			'to'   => array(
				'x' => 0,
				'y' => 0,
			),
		),
		'scale'      => array(
			'from' => 0,
			'to'   => 0,
		),
		'rotate'     => array(
			'from' => 0,
			'to'   => 0,
		),
		'velocity'   => array(
			'effect' => 'false',
			'value'  => 0,
			'unit'   => 'deg',
		),
	),
	'animations'       => array(),
);

$args = arts_parse_args_recursive( $args, $defaults );

if ( ! $args['id'] && ! $args['video']['src'] ) {
	return;
}

$image_attributes            = arts_get_lazy_image_attributes( $args );
$video_attributes            = $args['video']['attributes'];
$wrapper_attributes          = array(
	'outer'            => $args['outer'],
	'inner'            => $args['inner'],
	'inner_additional' => $args['inner_additional'],
);
$seo_noscript_images_enabled = get_theme_mod( 'seo_noscript_images_enabled', false );
$noscript_image_attributes   = array();

if ( $seo_noscript_images_enabled && array_key_exists( 'image', $image_attributes ) ) {
	$map_attributes            = array(
		'data-src'    => 'src',
		'data-srcset' => 'srcset',
		'data-sizes'  => 'sizes',
	);
	$noscript_image_attributes = $image_attributes['image'];

	foreach ( $map_attributes as $key => $value ) {
		if ( array_key_exists( $key, $image_attributes['image'] ) ) {
			$noscript_image_attributes[ $value ] = $image_attributes['image'][ $key ];
			unset( $noscript_image_attributes[ $key ] );
		}
	}
}

if ( $args['parallax']['enabled'] ) {
	$wrapper_attributes = arts_parse_args_recursive( $wrapper_attributes, arts_get_parallax_attributes( $args['parallax'] ) );
}

if ( ! empty( $args['animations'] ) ) {
	foreach ( $args['animations'] as $name => $params ) {
		$wrapper_attributes = arts_parse_args_recursive( $wrapper_attributes, arts_get_animation_inner_outer_attributes( $name, $params ) );
	}
}

if ( $args['type'] === 'image_limited' && array_key_exists( 'width', $image_attributes['image'] ) ) {
	$wrapper_attributes['outer']['class'][] = 'lazy-wrapper';
	$wrapper_attributes['outer']['style']   = 'max-width: ' . $image_attributes['image']['width'] . 'px;';
}

if ( $args['video']['src'] ) {
	$video_attributes['src'] = $args['video']['src'];

	if ( $args['video']['poster'] && array_key_exists( 'data-src', $image_attributes['image'] ) ) {
		$video_attributes['poster'] = $image_attributes['image']['data-src'];
	}

	if ( array_key_exists( 'class', $args['image'] ) && $args['image']['class'] ) {
		$video_attributes['class'] = $args['image']['class'];
	}

	if ( array_key_exists( 'class', $image_attributes['image'] ) ) {
		$video_attributes['class'] = $image_attributes['image']['class'];
	}

	if ( $args['type'] === 'image' ) {
		$video_attributes['class'][] = 'w-100';
		$video_attributes['class'][] = 'va-middle';
	}
}

?>

<?php if ( ! empty( $wrapper_attributes['outer'] ) ) : ?>
	<div <?php arts_print_attributes( $wrapper_attributes['outer'] ); ?>>
<?php endif; ?>

	<?php if ( array_key_exists( 'animateMask', $args['animations'] ) ) : ?>
		<div class="mask-reveal__layer mask-reveal__layer-1">
			<div class="mask-reveal__layer mask-reveal__layer-2">
	<?php endif; ?>

		<?php if ( ! empty( $wrapper_attributes['inner_additional'] ) ) : ?>
			<div <?php arts_print_attributes( $wrapper_attributes['inner_additional'] ); ?>>
		<?php endif; ?>

			<?php if ( ! empty( $wrapper_attributes['inner'] ) ) : ?>
				<div <?php arts_print_attributes( $wrapper_attributes['inner'] ); ?>>
			<?php endif; ?>

		<?php if ( $args['video']['src'] ) : ?>
			<video <?php arts_print_attributes( $video_attributes ); ?>></video>
		<?php else : ?>
			<?php if ( $args['type'] === 'image' || $args['type'] === 'image_limited' ) : ?>
				<?php if ( $args['lazy_wrapper'] ) : ?>
					<div <?php arts_print_attributes( $image_attributes['lazy'] ); ?>>
				<?php endif; ?>
						<img <?php arts_print_attributes( $image_attributes['image'] ); ?>>
						<?php if ( $seo_noscript_images_enabled && ! empty( $noscript_image_attributes ) ) : ?>
							<noscript><img <?php arts_print_attributes( $noscript_image_attributes ); ?>></noscript>
						<?php endif; ?>
				<?php if ( $args['lazy_wrapper'] ) : ?>
					</div>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( $args['type'] === 'background' ) : ?>
				<img <?php arts_print_attributes( $image_attributes['image'] ); ?>>
				<?php if ( $seo_noscript_images_enabled && ! empty( $noscript_image_attributes ) ) : ?>
					<noscript><img <?php arts_print_attributes( $noscript_image_attributes ); ?>></noscript>
				<?php endif; ?>
			<?php endif; ?>

		<?php endif; ?>

			<?php if ( ! empty( $wrapper_attributes['inner'] ) ) : ?>
				</div>
			<?php endif; ?>

		<?php if ( ! empty( $wrapper_attributes['inner_additional'] ) ) : ?>
			</div>
		<?php endif; ?>

	<?php if ( array_key_exists( 'animateMask', $args['animations'] ) ) : ?>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( $args['overlay'] ) : ?>
		<div <?php arts_print_attributes( $args['overlay'] ); ?>></div>
	<?php endif; ?>

<?php if ( ! empty( $wrapper_attributes['outer'] ) ) : ?>
	</div>
<?php endif; ?>
