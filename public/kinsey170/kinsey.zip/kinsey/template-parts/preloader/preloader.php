<?php

$preloader_text                        = get_theme_mod( 'preloader_text', __( 'Loading...', 'kinsey' ) );
$preloader_theme                       = get_theme_mod( 'preloader_theme', 'bg-dark-1' );
$preloader_elements_theme              = get_theme_mod( 'preloader_elements_theme', 'light' );
$preloader_logo                        = get_theme_mod( 'preloader_logo', 'primary' );
$preloader_counter_enabled             = get_theme_mod( 'preloader_counter_enabled', true );
$preloader_counter_preset              = get_theme_mod( 'preloader_counter_preset', 'xxl' );
$preloader_logo_during_loading_enabled = get_theme_mod( 'preloader_logo_during_loading_enabled', true );
$preloader_loading_text_preset         = get_theme_mod( 'preloader_loading_text_preset', 'h6' );
$preloader_loading_image_url           = get_theme_mod( 'preloader_image_url', '' );

$preloader_attributes = array(
	'class'                    => array( 'preloader', 'preloader_header-menu-hidden', 'mask-reveal' ),
	'id'                       => 'js-preloader',
	'data-arts-theme-text'     => $preloader_elements_theme,
	'data-arts-preloader-logo' => $preloader_logo,
);

if ( ! $preloader_logo_during_loading_enabled ) {
	$preloader_attributes['class'][] = 'preloader_header-logo-hidden';
}

?>

<div <?php arts_print_attributes( $preloader_attributes ); ?>>
	<div class="mask-reveal__layer mask-reveal__layer-1 <?php echo esc_attr( $preloader_theme ); ?>">
		<div class="mask-reveal__layer mask-reveal__layer-2">
			<div class="preloader__wrapper">
				<?php if ( $preloader_counter_enabled ) : ?>
					<div class="preloader__counter preloader__counter_started me-auto mt-auto underline js-preloader__counter <?php echo esc_attr( $preloader_counter_preset ); ?>">00%</div>
				<?php endif; ?>
				<?php if ( ! empty( $preloader_text ) ) : ?>
					<div class="preloader__content ms-auto mt-auto js-preloader__content">
						<div class="preloader__loading-label <?php echo esc_attr( $preloader_loading_text_preset ); ?>"><?php echo esc_html( $preloader_text ); ?></div>
					</div>
				<?php endif; ?>
				<?php if ( $preloader_loading_image_url ) : ?>
					<img class="js-preloader__content preloader__img" src="<?php echo esc_attr( $preloader_loading_image_url ); ?>" alt>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
