<?php

$defaults = array(
	'categories' => array(),
	'categories_divider' => ',&nbsp;',
	'categories_links' => false,
	'years' => array(),
	'years_divider' => ',&nbsp;',
	'years_links' => false,
	'divider' => array(
		'class' => array( 'post-meta__divider' )
	)
);

$args = wp_parse_args( $args, $defaults );

$categories_amount = count( $args['categories'] );
$years_amount = count( $args['years'] );

?>

<ul class="post-meta post-meta_mini">
	<?php if ( $args['categories'] ) : ?>
		<li class="post-meta__categories">
			<?php foreach ( $args['categories'] as $index => $category ) : ?>
				<?php if  ( $args['categories_links'] ) : ?>
					<a href="<?php echo esc_attr( $category['url'] ); ?>"><?php echo esc_html( $category['name'] ); ?></a>
				<?php else : ?>
					<span><?php echo esc_html( $category['name'] ); ?><?php if ( $categories_amount > 1 && $index < $categories_amount - 1 ) : ?><?php echo esc_html( $args['categories_divider'] ); ?><?php endif; ?></span>
				<?php endif; ?>
			<?php endforeach; ?>
			<?php if ( $args['categories'] && $args['years'] ) : ?>
				<div <?php arts_print_attributes( $args['divider'] ); ?>></div>
			<?php endif; ?>
		</li>
	<?php endif; ?>
	<?php if ( $args['years'] ) : ?>
		<li class="post-meta__years">
			<?php foreach ( $args['years'] as $index => $year ) : ?>
				<?php if  ( $args['years_links'] ) : ?>
					<a href="<?php echo esc_attr( $year['url'] ); ?>"><?php echo esc_html( $year['name'] ); ?></a>
				<?php else : ?>
					<span><?php echo esc_html( $year['name'] ); ?><?php if ( $years_amount > 1 && $index < $years_amount - 1 ) :?><?php echo esc_html( $args['years_divider'] ); ?><?php endif; ?></span>
				<?php endif; ?>
			<?php endforeach; ?>
		</li>
	<?php endif; ?>
</ul>
