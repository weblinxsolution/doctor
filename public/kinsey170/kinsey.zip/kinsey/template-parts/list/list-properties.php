<?php

$defaults = array(
	'post_id' => false,
	'list'    => array(
		'class' => array( 'list-dots' ),
	),
	'name'    => array(
		'class' => array( 'list-dots__name', 'small' ),
	),
	'value'   => array(
		'class' => array( 'list-dots__value', 'h4' ),
	),
);

$args = wp_parse_args( $args, $defaults );

?>

<ul <?php arts_print_attributes( $args['list'] ); ?>>
	<?php while ( arts_have_rows( 'properties', $args['post_id'] ) ) : ?>
		<?php the_row(); ?>
		<?php
			$name  = get_sub_field( 'name' );
			$value = get_sub_field( 'value' );
		?>
		<?php if ( ! empty( $name ) || ! empty( $value ) ) : ?>
			<li>
				<div class="d-inline-block va-middle">
					<?php if ( ! empty( $name ) ) : ?>
						<span <?php arts_print_attributes( $args['name'] ); ?>><?php echo wp_kses( $name, wp_kses_allowed_html( 'post' ) ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $value ) ) : ?>
						<div class="w-100"></div>
						<span <?php arts_print_attributes( $args['value'] ); ?>><?php echo wp_kses( $value, wp_kses_allowed_html( 'post' ) ); ?></span>
					<?php endif; ?>
				</div>
			</li>
		<?php endif; ?>
	<?php endwhile; ?>
</ul>
