<?php

$defaults = array(
	'type'              => 'horizontal',
	'attributes'        => array(
		'class' => array( 'slider__arrow', 'material-icons' ),
	),
	'cursor_attributes' => array(),
	'output'            => array( 'prev', 'next' ),
);

$args = wp_parse_args( $args, $defaults );

if ( ! array_key_exists( 'output', $args ) || empty( $args['output'] ) ) {
	return;
}

if ( $args['cursor_attributes'] ) {
	$args['attributes'] = arts_get_cursor_attributes( $args['attributes'], $args['cursor_attributes'] );
} else {
	$args['attributes']['class'][] = 'js-arts-cursor-highlight';
}

$prev_string                = 'keyboard_arrow_left';
$prev_attributes            = $args['attributes'];
$prev_attributes['class'][] = 'js-slider__arrow-prev';

$next_string                = 'keyboard_arrow_right';
$next_attributes            = $args['attributes'];
$next_attributes['class'][] = 'js-slider__arrow-next';

if ( $args['type'] === 'vertical' ) {
	$prev_string = 'keyboard_arrow_up';
	$next_string = 'keyboard_arrow_down';
}

?>


<?php if ( in_array( 'prev', $args['output'] ) ) : ?>
	<div <?php arts_print_attributes( $prev_attributes ); ?>><?php echo esc_html( $prev_string ); ?></div>
<?php endif; ?>
<?php if ( in_array( 'next', $args['output'] ) ) : ?>
	<div <?php arts_print_attributes( $next_attributes ); ?>><?php echo esc_html( $next_string ); ?></div>
<?php endif; ?>
