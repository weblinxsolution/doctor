<?php

$defaults = array(
	'location' => 'main_menu',
);

$args = wp_parse_args( $args, $defaults );

wp_nav_menu(
	array(
		'theme_location' => $args['location'],
		'fallback_cb'    => '',
		'container'      => false,
		'menu_class'     => 'menu js-menu',
	)
);
