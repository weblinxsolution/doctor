<?php

$menu_style           = get_theme_mod( 'menu_style', 'classic' );
$header_layout        = arts_get_header_layout();
$is_split_layout_menu = $menu_style === 'classic' && $header_layout === 'classic-logo-center-menu-split';
$main_menu_id         = 'main_menu';
$additional_menu      = wp_nav_menu(
	array(
		'theme_location' => 'additional_menu',
		'fallback_cb'    => '',
		'container'      => false,
		'menu_class'     => 'menu-overlay js-menu-overlay',
		'link_before'    => '<div class="menu-overlay__item-wrapper arts-split-text js-arts-split-text" data-arts-split-text="lines,words" data-arts-split-text-set="lines" data-arts-split-text-overflow-wrap="lines">',
		'link_after'     => '</div>',
		'items_wrap'     => '%3$s',
		'walker'         => new Arts_Walker_Nav_Menu_Overlay(),
		'echo'           => false, // just save menu to var
	)
);

if ( $is_split_layout_menu && ! empty( $additional_menu ) ) {
	// print merged menu
	wp_nav_menu(
		array(
			'theme_location' => $main_menu_id,
			'fallback_cb'    => '',
			'container'      => false,
			'menu_class'     => 'menu-overlay js-menu-overlay',
			'link_before'    => '<div class="menu-overlay__item-wrapper arts-split-text js-arts-split-text" data-arts-split-text="lines,words" data-arts-split-text-set="lines" data-arts-split-text-overflow-wrap="lines">',
			'link_after'     => '</div>',
			'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s ' . $additional_menu . '</ul>',
			'walker'         => new Arts_Walker_Nav_Menu_Overlay(),
		)
	);
} else {
	// print normal fullscreen menu
	wp_nav_menu(
		array(
			'theme_location' => $main_menu_id,
			'fallback_cb'    => '',
			'container'      => false,
			'menu_class'     => 'menu-overlay js-menu-overlay',
			'link_before'    => '<div class="menu-overlay__item-wrapper arts-split-text js-arts-split-text" data-arts-split-text="lines,words" data-arts-split-text-set="lines" data-arts-split-text-overflow-wrap="lines">',
			'link_after'     => '</div>',
			'walker'         => new Arts_Walker_Nav_Menu_Overlay(),
		)
	);
}
