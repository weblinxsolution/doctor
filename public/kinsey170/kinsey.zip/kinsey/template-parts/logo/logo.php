<?php

$title                 = get_bloginfo( 'name' );
$tagline               = get_bloginfo( 'description' );
$display_title_tagline = get_theme_mod( 'header_text', true );
$logo_class            = 'logo ';
$logo_wrapper_class    = 'logo__wrapper-img ';
$has_custom_logo       = has_custom_logo();

$logo_attributes = array(
	'class' => array( 'logo' ),
	'href'  => home_url( '/' ),
);

$logo_primary_args = array(
	'class' => 'logo__img-primary',
	'alt'   => $title,
);

$logo_secondary_args = array(
	'class' => 'logo__img-secondary',
	'alt'   => $title,
);

$logo_wrapper_attributes = array(
	'class' => array( 'logo__wrapper-img' ),
);

if ( ! $display_title_tagline ) {
	$logo_wrapper_attributes['class'][] = 'me-0';
}

?>

<a <?php arts_print_attributes( $logo_attributes ); ?>>
	<?php if ( $has_custom_logo ) : ?>
		<div <?php arts_print_attributes( $logo_wrapper_attributes ); ?>>
			<?php echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', '', $logo_primary_args ); // primary logo ?>
			<?php echo wp_get_attachment_image( get_theme_mod( 'custom_logo_secondary' ), 'full', '', $logo_secondary_args ); // secondary logo ?>
		</div>
	<?php endif; ?>
	<?php if ( ! empty( $title ) && $display_title_tagline ) : ?>
		<div class="logo__text">
			<span class="logo__text-title"><?php echo esc_html( $title ); ?></span>
			<?php if ( ! empty( $tagline ) ) : ?>
				<span class="logo__text-tagline"><?php echo esc_html( $tagline ); ?></span>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</a>
