<?php

global $post;

$ajax_enabled                            = get_theme_mod( 'ajax_enabled', false );
$bottom_nav_direction                    = get_theme_mod( 'bottom_nav_direction', 'previous' );
$bottom_nav_prefetch_enabled             = get_theme_mod( 'bottom_nav_prefetch_enabled', true );
$bottom_nav_fixed_reveal_from            = get_theme_mod( 'bottom_nav_fixed_reveal_from', -33.0 );
$bottom_nav_fixed_reveal_from_opacity    = get_theme_mod( 'bottom_nav_fixed_reveal_from_opacity', 1.0 );
$bottom_nav_next_label                   = get_theme_mod( 'bottom_nav_next_label', __( 'Next Project', 'kinsey' ) );
$bottom_nav_scroll_label                 = get_theme_mod( 'bottom_nav_scroll_label', __( 'Keep Scrolling', 'kinsey' ) );
$bottom_nav_headings_preset              = get_theme_mod( 'bottom_nav_headings_preset', 'h1' );
$bottom_nav_labels_preset                = get_theme_mod( 'bottom_nav_labels_preset', 'small' );
$bottom_nav_seamless_transition_enabled  = get_theme_mod( 'bottom_nav_seamless_transition_enabled', true );
$botton_nav_include_portfolio_taxonomies = get_theme_mod( 'botton_nav_include_portfolio_taxonomies', '' );
$bottom_nav_cursor_enabled               = get_theme_mod( 'bottom_nav_cursor_next_link_enabled', false );
$prev_next_args                          = array( 'direction' => $bottom_nav_direction );

if ( ! empty( $botton_nav_include_portfolio_taxonomies ) ) {
	$prev_next_args['in_same_term'] = true;
	$prev_next_args['taxonomy']     = $botton_nav_include_portfolio_taxonomies;
}

$next_post                                    = arts_get_post_looped_overridden( 'next', $prev_next_args );
$next_link                                    = '#';
$next_title                                   = '';
$next_image_id                                = '';
$next_video_id                                = '';
$next_page_masthead_header_elements_theme     = 'dark';
$next_page_masthead_featured_background_color = '#f8f8f8';
$next_page_masthead_featured_video_enabled    = 'yes';

if ( $next_post ) {
	$next_link     = get_permalink( $next_post );
	$next_title    = $next_post->post_title;
	$next_image_id = get_post_thumbnail_id( $next_post->ID );
	$next_video_id = arts_get_field( 'featured_video', $next_post->ID );

	$next_page_masthead_header_elements_theme     = arts_get_document_option( 'page_masthead_header_elements_theme', 'dark', $next_post->ID );
	$next_page_masthead_featured_background_color = arts_get_document_option( 'page_masthead_featured_background_color', '#f8f8f8', $next_post->ID );
	$next_page_masthead_featured_video_enabled    = arts_get_document_option( 'page_masthead_featured_video_enabled', 'yes', $next_post->ID );
}

$next_has_post_thumbnail = $next_image_id || ( $next_page_masthead_featured_video_enabled && $next_video_id );

$section_attributes = array(
	'class'                               => array( 'section', 'section-nav-projects', 'section-nav-projects_post-' . $post->ID, 'section-nav-projects_auto-scroll', 'section-fullheight', 'container-fluid', 'text-center' ),
	'data-arts-theme-text'                => $next_page_masthead_header_elements_theme,
	'data-arts-fixed-reveal'              => 'true',
	'data-arts-fixed-reveal-from'         => "{$bottom_nav_fixed_reveal_from}vh",
	'data-arts-fixed-reveal-from-opacity' => "{$bottom_nav_fixed_reveal_from_opacity}",
	'data-arts-fixed-reveal-disabled-at'  => 'max-width: 767px',
);

$header_attributes = array(
	'class' => array( 'section-nav-projects__header' ),
);

$image_wrapper_attributes = array(
	'class' => array( 'section-nav-projects__next-image', 'mt-xsmall', 'mx-auto' ),
);

$link_attributes = array(
	'class' => array( 'section-nav-projects__link', 'pointer-events-none' ),
	'href'  => $next_link,
);

$next_label_attributes = array(
	'class' => array( 'section-nav-projects__label' ),
);

$scroll_label_attributes = array(
	'class' => array( 'section-nav-projects__label', 'section-nav-projects__label_scroll' ),
);

$thumbnail_args = array(
	'id'    => $next_image_id,
	'video' => array(
		'poster'     => false,
		'attributes' => array(
			'autoplay' => true,
		),
	),
	'type'  => 'image_limited',
);

$heading_attributes = array(
	'class' => array( 'section-nav-projects__heading', 'section-nav-projects__progress-underline', $bottom_nav_headings_preset, 'underline', 'mb-0' ),
);

$subheading_attributes = array(
	'class' => array( 'section-nav-projects__subheading', 'mb-2', $bottom_nav_labels_preset ),
);

$heading_attributes = arts_get_split_text_attributes(
	$heading_attributes,
	array(
		'by'        => 'lines,words,chars',
		'set'       => false,
		'overflow'  => false,
		'animation' => false,
	)
);

if ( $bottom_nav_cursor_enabled ) {
	$link_attributes['class'][] = 'js-arts-cursor-no-highlight';
} else {
	$header_attributes['class'][]        = 'js-arts-cursor-highlight';
	$image_wrapper_attributes['class'][] = 'js-arts-cursor-highlight';
}

if ( $ajax_enabled ) {
	if ( $bottom_nav_seamless_transition_enabled ) {
		$image_wrapper_attributes['class'][] = 'js-transition-img';
		$image_wrapper_attributes['class'][] = 'overflow';
		$heading_attributes['class'][]       = 'js-transition-heading';
		$thumbnail_args['inner']['class'][]  = 'js-transition-img__transformed-el';
	}

	if ( $bottom_nav_prefetch_enabled ) {
		$section_attributes['data-arts-prefetch-enabled'] = 'true';
	}
}

if ( $ajax_enabled && $bottom_nav_seamless_transition_enabled && $next_image_id ) {
	$link_attributes['data-pjax-link']                      = 'autoScrollNext';
	$link_attributes['data-pjax-featured-background-color'] = $next_page_masthead_featured_background_color;
}

if ( $next_page_masthead_featured_video_enabled ) {
	$thumbnail_args['video']['src'] = $next_video_id;
}

if ( ! empty( $bottom_nav_scroll_label ) ) {
	$next_label_attributes['class'][] = 'section-nav-projects__label_next';
} else {
	$next_label_attributes['class'][] = 'section-nav-projects__label_all';
}

$header_attributes        = arts_get_cursor_attributes_theme_mod( $header_attributes, 'bottom_nav_cursor_next_link' );
$image_wrapper_attributes = arts_get_cursor_attributes_theme_mod( $image_wrapper_attributes, 'bottom_nav_cursor_next_link' );

?>

<aside <?php arts_print_attributes( $section_attributes ); ?>>
	<!-- content -->
	<div class="section-nav-projects__inner container section-fullheight__inner">
		<!-- header -->
		<header <?php arts_print_attributes( $header_attributes ); ?>>
			<a <?php arts_print_attributes( $link_attributes ); ?>>
				<?php if ( ! empty( $bottom_nav_next_label ) || ! empty( $bottom_nav_scroll_label ) ) : ?>
					<!-- helping labels -->
					<div <?php arts_print_attributes( $subheading_attributes ); ?>>
						<?php if ( ! empty( $bottom_nav_next_label ) ) : ?>
							<span <?php arts_print_attributes( $next_label_attributes ); ?>><?php echo esc_html( $bottom_nav_next_label ); ?></span>
						<?php endif; ?>
						<?php if ( ! empty( $bottom_nav_scroll_label ) ) : ?>
							<span <?php arts_print_attributes( $scroll_label_attributes ); ?>><?php echo esc_html( $bottom_nav_scroll_label ); ?></span>
						<?php endif; ?>
					</div>
					<!-- - helping labels -->
				<?php endif; ?>
				<h2 <?php arts_print_attributes( $heading_attributes ); ?>><?php echo esc_html( $next_title ); ?></h2>
			</a>
		</header>
		<!-- - header-->
		<?php if ( $next_has_post_thumbnail ) : ?>
			<!-- next image-->
			<div <?php arts_print_attributes( $image_wrapper_attributes ); ?>>
				<div class="section-nav-projects__wrapper-image h-100">
					<?php get_template_part( 'template-parts/lazy/lazy', 'image', $thumbnail_args ); ?>
				</div>
			</div>
			<!-- - next image-->
		<?php endif; ?>
	</div>
	<!-- - content -->
	<!-- spacing element -->
	<div class="section-nav-projects__spacer d-md-block d-none"></div>
	<!-- - spacing element-->
</aside>

<?php wp_reset_postdata(); ?>
