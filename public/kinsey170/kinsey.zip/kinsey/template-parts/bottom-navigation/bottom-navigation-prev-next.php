<?php

global $post;

$bottom_nav_direction                            = get_theme_mod( 'bottom_nav_direction', 'previous' );
$bottom_nav_prev_next_vertical_padding           = get_theme_mod( 'bottom_nav_prev_next_vertical_padding', 'py-medium' );
$bottom_nav_prev_label                           = get_theme_mod( 'bottom_nav_prev_label', __( 'Previous Project', 'kinsey' ) );
$bottom_nav_next_label                           = get_theme_mod( 'bottom_nav_next_label', __( 'Next Project', 'kinsey' ) );
$bottom_nav_headings_preset                      = get_theme_mod( 'bottom_nav_headings_preset', 'h1' );
$bottom_nav_labels_preset                        = get_theme_mod( 'bottom_nav_labels_preset', 'small' );
$bottom_nav_seamless_transition_enabled          = get_theme_mod( 'bottom_nav_seamless_transition_enabled', true );
$botton_nav_include_portfolio_taxonomies         = get_theme_mod( 'botton_nav_include_portfolio_taxonomies', '' );
$bottom_nav_archive_button_enabled               = get_theme_mod( 'bottom_nav_archive_button_enabled', false );
$bottom_nav_archive_button_page_link             = get_permalink( get_theme_mod( 'bottom_nav_archive_button_page', '419' ) );
$bottom_nav_archive_button_border                = get_theme_mod( 'bottom_nav_archive_button_border', 'button_solid' );
$bottom_nav_archive_button_color                 = get_theme_mod( 'bottom_nav_archive_button_color', 'bg-dark-3' );
$bottom_nav_archive_button_counter_enabled       = get_theme_mod( 'bottom_nav_archive_button_counter_enabled', false );
$bottom_nav_archive_button_counter_custom_string = get_theme_mod( 'bottom_nav_archive_button_counter_custom_string', '' );

$prev_args = array(
	'direction' => $bottom_nav_direction === 'previous' ? 'next' : 'previous',
);
$next_args = array(
	'direction' => $bottom_nav_direction === 'previous' ? 'previous' : 'next',
);

if ( ! empty( $botton_nav_include_portfolio_taxonomies ) ) {
	$prev_args['in_same_term'] = true;
	$prev_args['taxonomy']     = $botton_nav_include_portfolio_taxonomies;

	$next_args['in_same_term'] = true;
	$next_args['taxonomy']     = $botton_nav_include_portfolio_taxonomies;
}

$next_post = arts_get_post_looped_overridden( 'next', $next_args );
$next_link;
$next_title;
$next_image;
$next_link_attributes  = array(
	'class' => array( 'background-hover', 'underline-hover', $bottom_nav_prev_next_vertical_padding, 'container-fluid' ),
);
$next_col_attributes   = array(
	'class' => array( 'col-12', 'order-sm-3', 'text-center' ),
);
$button_col_attributes = array(
	'class' => array( 'col-sm-2', 'col-12', 'order-sm-2' ),
);

$prev_post = arts_get_post_looped_overridden( 'prev', $prev_args );
$prev_link;
$prev_title;
$prev_image;
$prev_link_attributes = $next_link_attributes;
$prev_col_attributes  = array(
	'class' => array( 'col-12', 'order-sm-1', 'text-center' ),
);

if ( $next_post ) {
	$next_title                                = $next_post->post_title;
	$next_image_id                             = get_post_thumbnail_id( $next_post );
	$next_link_attributes['href']              = get_permalink( $next_post );
	$next_link_attributes['class'][]           = 'section-nav-projects__item-next';
	$next_link_attributes['class'][]           = 'posts-navigation__item_next';
	$next_page_masthead_header_elements_theme  = arts_get_document_option( 'page_masthead_header_elements_theme', 'dark', $next_post->ID );
	$next_page_masthead_featured_video_enabled = arts_get_document_option( 'page_masthead_featured_video_enabled', 'yes', $next_post->ID );

	$next_link_attributes['data-arts-theme-text'] = $next_page_masthead_header_elements_theme;
	$next_link_attributes                         = arts_get_cursor_attributes_theme_mod( $next_link_attributes, 'bottom_nav_cursor_next_link' );
}

if ( $prev_post ) {
	$prev_title                                = $prev_post->post_title;
	$prev_image_id                             = get_post_thumbnail_id( $prev_post );
	$prev_link_attributes['href']              = get_permalink( $prev_post );
	$prev_link_attributes['class'][]           = 'section-nav-projects__item-prev';
	$prev_link_attributes['class'][]           = 'posts-navigation__item_prev';
	$prev_page_masthead_header_elements_theme  = arts_get_document_option( 'page_masthead_header_elements_theme', 'dark', $prev_post->ID );
	$prev_page_masthead_featured_video_enabled = arts_get_document_option( 'page_masthead_featured_video_enabled', 'yes', $prev_post->ID );

	$prev_link_attributes['data-arts-theme-text'] = $prev_page_masthead_header_elements_theme;
	$prev_link_attributes                         = arts_get_cursor_attributes_theme_mod( $prev_link_attributes, 'bottom_nav_cursor_prev_link' );
}

if ( $prev_post && $next_post ) {

	if ( $bottom_nav_archive_button_enabled ) {
		$next_col_attributes['class'][] = 'col-sm-5';
		$prev_col_attributes['class'][] = 'col-sm-5';
	} else {
		$next_col_attributes['class'][] = 'col-sm-6';
		$prev_col_attributes['class'][] = 'col-sm-6';
	}

	$next_col_attributes['class'][] = 'text-sm-end';
	$prev_col_attributes['class'][] = 'text-sm-start';
}

$section_attributes = array(
	'class' => array( 'section-nav-projects', 'section-nav-projects_post-' . $post->ID, 'section-nav-projects_prev-next', 'posts-navigation' ),
);

$heading_attributes = array(
	'class' => array( 'section-nav-projects__heading', $bottom_nav_headings_preset, 'underline-hover__target' ),
);

$next_label_attributes = array(
	'class' => array( 'section-nav-projects__label', 'section-nav-projects__label_next', 'mb-2', $bottom_nav_labels_preset ),
);

$prev_label_attributes = array(
	'class' => array( 'section-nav-projects__label', 'section-nav-projects__label_prev', 'mb-2', $bottom_nav_labels_preset ),
);

$button_navbar_args               = array(
	'attributes' => array(
		'href'  => '#',
		'class' => array( 'section-nav-projects__button-archive', 'w-100', 'h-100', 'd-flex-centered', 'js-button-circles', $bottom_nav_archive_button_border, $bottom_nav_archive_button_color, $bottom_nav_prev_next_vertical_padding, 'container-fluid' ),
	),
	'big'        => true,
);
$button_navbar_args['attributes'] = arts_get_cursor_attributes_theme_mod( $button_navbar_args['attributes'], 'bottom_nav_cursor_archive_link' );

if ( ! empty( $bottom_nav_archive_button_page_link ) ) {
	$button_navbar_args['attributes']['href'] = $bottom_nav_archive_button_page_link;
}

if ( $bottom_nav_archive_button_counter_enabled ) {
	if ( empty( $bottom_nav_archive_button_counter_custom_string ) ) {
		$count_posts                   = wp_count_posts( get_post_type() );
		$button_navbar_args['counter'] = $count_posts->publish;
	} else {
		$button_navbar_args['counter'] = $bottom_nav_archive_button_counter_custom_string;
	}
}

?>

<aside <?php arts_print_attributes( $section_attributes ); ?>>
	<div class="row g-0">
		<?php if ( $next_post ) : ?>
			<div <?php arts_print_attributes( $next_col_attributes ); ?>>
				<a <?php arts_print_attributes( $next_link_attributes ); ?>>
					<?php if ( $next_image_id ) : ?>
						<div class="background-hover__image">
							<?php
							get_template_part(
								'template-parts/lazy/lazy',
								'image',
								array(
									'id'   => $next_image_id,
									'type' => 'background',
								)
							);
							?>
						</div>
					<?php endif; ?>
					<div class="background-hover__overlay overlay overlay_dark-60"></div>
					<div class="background-hover__content w-100">
						<?php if ( ! empty( $bottom_nav_next_label ) ) : ?>
							<span <?php arts_print_attributes( $next_label_attributes ); ?>><?php echo esc_html( $bottom_nav_next_label ); ?></span>
							<div class="w-100"></div>
						<?php endif; ?>
						<h2 <?php arts_print_attributes( $heading_attributes ); ?>><?php echo esc_html( $next_title ); ?></h2>
					</div>
				</a>
			</div>
		<?php endif; ?>
		<?php if ( $prev_post ) : ?>
			<div <?php arts_print_attributes( $prev_col_attributes ); ?>>
				<a <?php arts_print_attributes( $prev_link_attributes ); ?>>
					<?php if ( $prev_image_id ) : ?>
						<div class="background-hover__image">
							<?php
							get_template_part(
								'template-parts/lazy/lazy',
								'image',
								array(
									'id'   => $prev_image_id,
									'type' => 'background',
								)
							);
							?>
						</div>
					<?php endif; ?>
					<div class="background-hover__overlay overlay overlay_dark-60"></div>
					<div class="background-hover__content w-100">
						<?php if ( ! empty( $bottom_nav_prev_label ) ) : ?>
							<span <?php arts_print_attributes( $prev_label_attributes ); ?>><?php echo esc_html( $bottom_nav_prev_label ); ?></span>
							<div class="w-100"></div>
						<?php endif; ?>
						<h2 <?php arts_print_attributes( $heading_attributes ); ?>><?php echo esc_html( $prev_title ); ?></h2>
					</div>
				</a>
			</div>
		<?php endif; ?>
		<?php if ( $bottom_nav_archive_button_enabled ) : ?>
			<div <?php arts_print_attributes( $button_col_attributes ); ?>>
				<?php get_template_part( 'template-parts/button/button', 'circles', $button_navbar_args ); ?>
			</div>
		<?php endif; ?>
	</div>
</aside>
