<?php

$defaults = array(
	'attributes' => array(
		'href'  => '#',
		'class' => array( 'button', 'js-button-circles' ),
	),
	'counter'    => null,
	'big'        => false,
);

$wrapper_circles_attributes = array(
	'class' => array( 'button-circles' ),
);

$args = arts_parse_args_recursive( $args, $defaults );

if ( $args['big'] === true ) {
	$wrapper_circles_attributes['class'][] = 'button-circles_big';
}

if ( ! empty( $args['counter'] ) ) {
	$wrapper_circles_attributes['class'][] = 'block-counter';
}

?>

<a <?php arts_print_attributes( $args['attributes'] ); ?>>
	<div <?php arts_print_attributes( $wrapper_circles_attributes ); ?>>
		<?php for ( $i = 0; $i < 4; $i++ ) : ?>
			<div class="button-circles__circle">
				<svg class="svg-circle" viewBox="0 0 60 60">
					<circle class="circle" cx="30" cy="30" r="29" fill="none"></circle>
				</svg>
			</div>
		<?php endfor; ?>
		<?php if ( ! empty( $args['counter'] ) ) : ?>
			<span class="block-counter__counter"><?php echo esc_html( $args['counter'] ); ?></span>
		<?php endif; ?>
	</div>
</a>
