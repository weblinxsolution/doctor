<?php

$blog_os_animation_enabled       = get_theme_mod( 'blog_os_animation_enabled', false );
$blog_grid_columns               = get_theme_mod( 'blog_grid_columns', 1 );
$blog_grid_filter_enabled        = arts_blog_filter_is_active();
$blog_grid_space_between         = get_theme_mod( 'blog_grid_space_between', 3 );
$blog_grid_fancy_enabled         = get_theme_mod( 'blog_grid_fancy_enabled', false );
$blog_grid_equal_columns_enabled = get_theme_mod( 'blog_grid_equal_columns_enabled', false );
$blog_posts_preview_style        = get_theme_mod( 'blog_posts_preview_style', '' );
$is_grid_active                  = $blog_grid_columns > 1 || $blog_grid_filter_enabled;

// 5 columns filter
$desktop_columns_amount = $blog_grid_columns === '5' ? '2dot4' : 12 / $blog_grid_columns;

$grid_attributes = array(
	'class' => array( 'grid', 'js-grid' ),
);

$grid_sizer_attributes = array(
	'class' => array(
		'grid__sizer',
		'js-grid__sizer',
	),
);

$grid_item_attributes = array( 'class' => array() );

$wrapper_item_attributes = array(
	'class' => array( 'w-100', 'h-100', 'overflow', 'mb-md-0', 'mb-2' ),
);

if ( $blog_posts_preview_style === 'background' ) {
	$grid_attributes['class'][] = 'list-backgrounds';
	$grid_attributes['class'][] = 'list-backgrounds_striped';
	$desktop_columns_amount     = 12;
	$blog_grid_space_between    = 0;
}

if ( $is_grid_active ) {
	$grid_sizer_attributes['class'][] = 'grid__item_desktop-' . $desktop_columns_amount;

	if ( $blog_posts_preview_style !== 'background' ) {
		$grid_sizer_attributes['class'][] = 'grid__item_tablet-6';
		$grid_item_attributes['class'][]  = 'grid__item_tablet-6';
	}

	$grid_sizer_attributes['class'][] = 'grid__item_mobile-12';

	$grid_item_attributes['class'][] = 'grid__item';
	$grid_item_attributes['class'][] = 'grid__item_desktop-' . $desktop_columns_amount;
	$grid_item_attributes['class'][] = 'grid__item_mobile-12';
	$grid_item_attributes['class'][] = 'grid__item_mobile-12';
	$grid_item_attributes['class'][] = 'js-grid__item';

	if ( $blog_grid_columns === 1 && $blog_grid_filter_enabled ) {
		$grid_item_attributes['class'][] = 'section-blog__wrapper-post';
		$grid_item_attributes['class'][] = 'mb-small';
	} else {
		$grid_attributes['class'][]       = "grid_fluid-{$blog_grid_space_between}";
		$grid_sizer_attributes['class'][] = "grid__item_fluid-{$blog_grid_space_between}";
		$grid_item_attributes['class'][]  = "grid__item_fluid-{$blog_grid_space_between}";
	}

	if ( $blog_grid_fancy_enabled ) {
		$grid_sizer_attributes['class'][] = "grid__item_fluid-{$blog_grid_space_between}-fancy";
		$grid_item_attributes['class'][]  = "grid__item_fluid-{$blog_grid_space_between}-fancy";
	}

	if ( $blog_grid_equal_columns_enabled ) {
		$grid_attributes['class'][] = 'js-grid-equal-heights';
	}
} else {
	$grid_item_attributes['class'][] = 'section-blog__wrapper-post';

	if ( $blog_posts_preview_style !== 'background' ) {
		$grid_item_attributes['class'][] = 'mb-small';
	}
}

if ( $blog_os_animation_enabled ) {
	$wrapper_item_attributes = arts_get_animation_attributes(
		$wrapper_item_attributes,
		'animateJump',
		array(
			'direction' => 'up',
			'y'         => '33%',
			'scaleY'    => 1.5,
		)
	);
}

?>

<?php if ( $is_grid_active ) : ?>
	<div <?php arts_print_attributes( $grid_attributes ); ?>>
		<!-- sizer -->
		<div <?php arts_print_attributes( $grid_sizer_attributes ); ?>></div>
		<!-- - sizer -->
<?php endif; ?>
	<?php while ( have_posts() ) : ?>
		<?php
			the_post();
			$categories                   = get_the_category();
			$grid_current_item_attributes = $grid_item_attributes;

		if ( $is_grid_active && ! empty( $categories ) ) {
			foreach ( $categories as $category ) {
				$grid_current_item_attributes['class'][] = 'category-' . $category->slug;
			}
		}
		?>
		<div <?php arts_print_attributes( $grid_current_item_attributes ); ?>>
			<?php if ( $blog_os_animation_enabled ) : ?>
				<div <?php arts_print_attributes( $wrapper_item_attributes ); ?>>
			<?php endif; ?>
				<?php get_template_part( 'template-parts/blog/post/post', $blog_posts_preview_style ); ?>
			<?php if ( $blog_os_animation_enabled ) : ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endwhile; ?>
<?php if ( $is_grid_active ) : ?>
	</div>
<?php endif; ?>
