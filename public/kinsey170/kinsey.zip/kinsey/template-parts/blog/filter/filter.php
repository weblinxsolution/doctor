<?php

$blog_os_animation_enabled  = get_theme_mod( 'blog_os_animation_enabled', false );
$blog_grid_filter_all_label = get_theme_mod( 'blog_grid_filter_all_label', __( 'All Posts', 'kinsey' ) );
$posts_categories           = arts_get_posts_categories( 'current_page' );
$blog_filter_mobile_style   = get_theme_mod( 'blog_filter_mobile_style', 'dropdown' );

$filter_attributes = array(
	'class' => array( 'filter', 'text-center', 'js-filter' ),
);

$filter_inner_attributes = array(
	'class' => array( 'filter__inner' ),
);

$filter_dropdown_attributes = array(
	'class' => array( 'filter__wrapper-dropdown', 'd-lg-none' ),
);

$filter_underline_attributes = array(
	'class' => array( 'filter__underline', 'js-filter__underline' ),
);

$category_wrapper_attributes = array(
	'class' => array( 'col-lg-auto', 'col-12', 'filter__item', 'js-filter__item', 'js-arts-cursor-highlight' ),
);

$category_attributes = array(
	'class' => array( 'filter__item-inner', 'h6', 'block-counter' ),
);

if ( $blog_os_animation_enabled ) {
	$category_attributes = arts_get_split_text_attributes(
		$category_attributes,
		array(
			'by'        => 'lines, words',
			'set'       => 'words',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);

	$filter_attributes           = arts_get_animation_attributes( $filter_attributes, 'animateText' );
	$filter_dropdown_attributes  = arts_get_animation_attributes( $filter_dropdown_attributes, 'animateJump' );
	$filter_underline_attributes = arts_get_animation_attributes(
		$filter_underline_attributes,
		'animateHeadline',
		array(
			'transformOrigin' => 'left center',
		)
	);
}

if ( $blog_filter_mobile_style === 'dropdown' ) {
	$filter_inner_attributes['class'][] = 'd-lg-block';
	$filter_inner_attributes['class'][] = 'd-none';
}

?>

<?php if ( ! empty( $posts_categories ) ) : ?>
	<div <?php arts_print_attributes( $filter_attributes ); ?>>
		<?php if ( $blog_filter_mobile_style === 'dropdown' ) : ?>
			<!-- optional mobile dropdown filter-->
			<div <?php arts_print_attributes( $filter_dropdown_attributes ); ?>>
				<select class="js-filter__select d-block w-100">
					<?php if ( ! empty( $blog_grid_filter_all_label ) ) : ?>
						<option value="*" selected="selected"><?php echo esc_html( $blog_grid_filter_all_label ); ?> [*]</option>
					<?php endif; ?>
					<?php foreach ( $posts_categories as $category ) : ?>
						<?php
							$current_category_attributes = array(
								'value' => '.category-' . $category['slug'],
							);
							?>
						<option <?php arts_print_attributes( $current_category_attributes ); ?>><?php echo esc_html( $category['name'] ); ?> [<?php echo esc_html( $category['total'] ); ?>]</option>
					<?php endforeach; ?>
				</select>
			</div>
			<!-- - optional mobile dropdown filter-->
		<?php endif; ?>
		<div <?php arts_print_attributes( $filter_inner_attributes ); ?>>
			<div class="container-fluid no-gutters">
				<!-- items -->
				<div class="row justify-content-between">
					<?php if ( ! empty( $blog_grid_filter_all_label ) ) : ?>
						<?php
							$category_all_attributes                = $category_wrapper_attributes;
							$category_all_attributes['data-filter'] = '*';
							$category_all_attributes['class'][]     = 'filter__item_active';
						?>
						<!-- all (*) -->
						<div <?php arts_print_attributes( $category_all_attributes ); ?>>
							<div <?php arts_print_attributes( $category_attributes ); ?>>
								<span class="filter__item-label"><?php echo esc_html( $blog_grid_filter_all_label ); ?></span>
								<span class="block-counter__counter">*</span>
							</div>
						</div>
						<!-- - all (*) -->
					<?php endif; ?>
					<!-- items -->
					<?php foreach ( $posts_categories as $category ) : ?>
						<?php
							$current_category_wrapper_attributes                = $category_wrapper_attributes;
							$current_category_wrapper_attributes['data-filter'] = '.category-' . $category['slug'];
						?>
						<div <?php arts_print_attributes( $current_category_wrapper_attributes ); ?>>
							<div <?php arts_print_attributes( $category_attributes ); ?>>
								<span class="filter__item-label"><?php echo esc_html( $category['name'] ); ?></span>
								<span class="block-counter__counter"><?php echo esc_html( $category['total'] ); ?></span>
							</div>
						</div>
					<?php endforeach; ?>
					<!-- - items -->
				</div>
				<!-- underline -->
				<div <?php arts_print_attributes( $filter_underline_attributes ); ?>></div>
				<!-- - underline -->
			</div>
		</div>
	</div>
<?php endif; ?>
