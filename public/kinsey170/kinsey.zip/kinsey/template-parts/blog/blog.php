<?php

$sidebar_position         = get_theme_mod( 'sidebar_position', 'right_side' );
$is_active_sidebar        = is_active_sidebar( 'blog-sidebar' );
$has_pagination           = get_the_posts_pagination();
$blog_container           = get_theme_mod( 'blog_container', 'container' );
$blog_filter_container    = get_theme_Mod( 'blog_filter_container', 'container-fluid' );
$blog_posts_preview_style = get_theme_mod( 'blog_posts_preview_style', '' );
$blog_layout              = get_theme_mod( 'blog_layout', 'guttered' );
$blog_grid_columns        = get_theme_mod( 'blog_grid_columns', 1 );
$blog_grid_columns        = intval( $blog_grid_columns );
$blog_page_id             = get_option( 'page_for_posts' );
$has_post_thumbnail       = has_post_thumbnail( $blog_page_id );
$blog_grid_filter_enabled = arts_blog_filter_is_active();
$blog_grid_filter_mode    = get_theme_mod( 'blog_grid_filter_mode', '' );
$animation_enabled        = get_theme_mod( 'blog_os_animation_enabled', false );

$section_attributes = array(
	'class' => array( 'section', 'section-blog', 'section-grid' ),
);

$inner_attributes = array(
	'class' => array( 'section-blog__inner', 'bg-white-1' ),
);

$container_attributes = array(
	'class' => array( 'section-blog__container', $blog_container ),
);

$container_filter_attributes = array(
	'class' => array( $blog_filter_container ),
);

$row_attributes = array(
	'class' => array( 'section-blog__row', 'text-start', 'row', 'overflow' ),
);

$col_posts_attributes = array(
	'class' => array( 'section-blog__posts' ),
);

$col_sidebar_attributes = array(
	'class' => array( 'section-blog__sidebar', 'col-lg-3' ),
);

$pagination_attributes = array(
	'class' => array( 'container', 'section-blog__pagination', 'mt-small' ),
);

if ( $blog_layout === 'guttered' ) {
	$section_attributes['class'][] = 'container-fluid';
	$section_attributes['class'][] = 'container_p-md-0';
	$section_attributes['class'][] = 'mb-large';

	if ( $blog_grid_filter_enabled ) {
		$container_attributes['class'][] = 'pb-medium';
	} else {
		$container_attributes['class'][] = 'pb-large';
	}
} else {
	$container_attributes['class'][] = 'pb-large';
}

if ( $sidebar_position === 'right_side' ) {
	$col_posts_attributes['class'][]   = 'order-lg-1';
	$col_sidebar_attributes['class'][] = 'order-lg-2';
} else {
	$col_posts_attributes['class'][]   = 'order-lg-2';
	$col_sidebar_attributes['class'][] = 'order-lg-1';
}

if ( $is_active_sidebar ) {
	$row_attributes['class'][]       = 'justify-content-between';
	$col_posts_attributes['class'][] = 'col-lg-8';
} else {
	$row_attributes['class'][] = 'justify-content-center';

	if ( $blog_container === 'container' && $blog_posts_preview_style !== 'background' && $blog_grid_columns === 1 ) {
		$col_posts_attributes['class'][] = 'col-lg-8';
	} else {
		$col_posts_attributes['class'][] = 'col-12';
	}
}

if ( $has_post_thumbnail ) {
	$container_attributes['class'][] = 'pt-medium';
} else {

	if ( $blog_layout === 'guttered' ) {
		if ( $blog_grid_filter_enabled ) {
			$container_filter_attributes['class'][] = 'pt-small';
		} else {
			$container_attributes['class'][] = 'pt-large';
		}
	}
}

if ( $blog_grid_filter_enabled ) {
	$row_attributes['class'][] = 'pt-small';

	if ( $blog_grid_filter_mode === 'ajax' ) {
		$section_attributes['class'][]    = 'js-ajax-filter';
		$pagination_attributes['class'][] = 'js-grid-ajax__pagination';
	} else {
		$pagination_attributes['class'][] = 'js-ajax-pagination';
	}
} else {
	if ( $blog_posts_preview_style === 'background' ) {
		$col_posts_attributes['class'][] = 'section-blog__posts_striped';
	}
}

if ( $blog_posts_preview_style !== 'background' ) {
	$pagination_attributes['class'][] = 'px-0';
}

if ( $animation_enabled ) {
	$section_attributes['data-arts-os-animation-start'] = 'top bottom';
	$col_sidebar_attributes                             = arts_get_animation_attributes( $col_sidebar_attributes, 'animateJump' );
}

?>

<!-- section BLOG -->
<section <?php arts_print_attributes( $section_attributes ); ?>>
	<div <?php arts_print_attributes( $inner_attributes ); ?>>
		<?php if ( $blog_grid_filter_enabled ) : ?>
			<!-- filter -->
			<div <?php arts_print_attributes( $container_filter_attributes ); ?>>
				<?php get_template_part( 'template-parts/blog/filter/filter', $blog_grid_filter_mode ); ?>
			</div>
			<!-- - filter -->
		<?php endif; ?>
		<div <?php arts_print_attributes( $container_attributes ); ?>>
			<div <?php arts_print_attributes( $row_attributes ); ?>>
				<div <?php arts_print_attributes( $col_posts_attributes ); ?>>
					<?php if ( have_posts() ) : ?>
						<!-- posts -->
						<?php get_template_part( 'template-parts/blog/loop/loop' ); ?>
						<!-- - posts -->
					<?php else : ?>
						<!-- no published content -->
						<?php get_template_part( 'template-parts/blog/post/content/content', 'none' ); ?>
					<?php endif; ?>

					<?php if ( $has_pagination ) : ?>
						<!-- pagination -->
						<div <?php arts_print_attributes( $pagination_attributes ); ?>>
							<?php arts_posts_pagination(); ?>
						</div>
						<!-- - pagination -->
					<?php endif; ?>
				</div>
				<?php if ( $is_active_sidebar ) : ?>
					<div <?php arts_print_attributes( $col_sidebar_attributes ); ?>>
						<?php get_sidebar(); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<!-- - section BLOG -->
