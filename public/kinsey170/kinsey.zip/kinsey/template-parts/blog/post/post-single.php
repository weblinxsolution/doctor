<?php

/**
 * Single post
 */

?>

<article <?php post_class( 'post' ); ?> id="post-<?php the_ID(); ?>">
	<!-- post content -->
	<div class="post__content clearfix">
		<?php the_content(); ?>
		<?php
			wp_link_pages(
				array(
					'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'kinsey' ),
					'after'       => '</div>',
					'link_before' => '<span class="page-number">',
					'link_after'  => '</span>',
				)
			);
			?>
	</div>
	<!-- - post content -->
	<?php if ( wp_get_post_tags( $post->ID ) ) : ?>
		<!-- post tags -->
		<div class="post__tags mt-xsmall">
			<div class="tagcloud">
				<?php the_tags( '', '', '' ); ?>
			</div>
		</div>
		<!-- - post tags -->
	<?php endif; ?>

	<?php if ( comments_open() || get_comments_number() ) : ?>
		<!-- post comments -->
		<div class="post__comments mt-small" data-barba-prevent="all">
			<?php comments_template(); ?>
		</div>
		<!-- - post comments -->
	<?php endif; ?>
</article>
