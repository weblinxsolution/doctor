<?php

$defaults = array(
	'id'    => get_the_ID(),
	'class' => array( 'categories' ),
);

$args = wp_parse_args( $args, $defaults );

$post_categories        = wp_get_post_categories( $args['id'] );
$post_categories_amount = count( $post_categories );

?>

<?php if ( $post_categories_amount > 0 ) : ?>
	<?php echo get_the_category_list( '', '', $args['id'] ); ?>
	<?php
endif;
