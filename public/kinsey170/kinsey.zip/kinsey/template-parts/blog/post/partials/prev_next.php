<?php

$next_post = get_previous_post();
$next_link;
$next_title;
$next_image;
$next_label           = get_theme_mod( 'post_prev_next_nav_next_title', __( 'Next Post', 'kinsey' ) );
$next_link_attributes = array(
	'class' => array( 'background-hover', 'underline-hover', 'py-small', 'container-fluid' ),
);
$next_col_attributes  = array(
	'class' => array( 'col-12', 'order-sm-2', 'text-center' ),
);

$prev_post = get_next_post();
$prev_link;
$prev_title;
$prev_image;
$prev_label           = get_theme_mod( 'post_prev_next_nav_prev_title', __( 'Previous Post', 'kinsey' ) );
$prev_link_attributes = $next_link_attributes;
$prev_col_attributes  = array(
	'class' => array( 'col-12', 'order-sm-1', 'text-center' ),
);

if ( $next_post ) {
	$next_title                      = $next_post->post_title;
	$next_image_id                   = get_post_thumbnail_id( $next_post );
	$next_link_attributes['href']    = get_permalink( $next_post );
	$next_link_attributes['class'][] = 'posts-navigation__item_next';

	$next_link_attributes = arts_get_cursor_attributes_theme_mod( $next_link_attributes, 'blog_single_post_cursor_next_link' );
}

if ( $prev_post ) {
	$prev_title                      = $prev_post->post_title;
	$prev_image_id                   = get_post_thumbnail_id( $prev_post );
	$prev_link_attributes['href']    = get_permalink( $prev_post );
	$prev_link_attributes['class'][] = 'posts-navigation__item_prev';

	$prev_link_attributes = arts_get_cursor_attributes_theme_mod( $prev_link_attributes, 'blog_single_post_cursor_prev_link' );
}

if ( $prev_post && $next_post ) {
	$next_col_attributes['class'][] = 'col-sm-6';
	$next_col_attributes['class'][] = 'text-sm-end';

	$prev_col_attributes['class'][] = 'col-sm-6';
	$prev_col_attributes['class'][] = 'text-sm-start';
}

?>

<aside class="posts-navigation">
	<div class="row g-0">
		<?php if ( $next_post ) : ?>
			<div <?php arts_print_attributes( $next_col_attributes ); ?>>
				<a <?php arts_print_attributes( $next_link_attributes ); ?>>
					<?php if ( $next_image_id ) : ?>
						<div class="background-hover__image">
							<?php
							get_template_part(
								'template-parts/lazy/lazy',
								'image',
								array(
									'id'   => $next_image_id,
									'type' => 'background',
								)
							);
							?>
						</div>
					<?php endif; ?>
					<div class="background-hover__overlay overlay overlay_dark-60"></div>
					<div class="background-hover__content w-100">
						<span class="small"><?php echo esc_html( $next_label ); ?></span>
						<div class="w-100"></div>
						<h2 class="h4 underline-hover__target"><?php echo esc_html( $next_title ); ?></h2>
					</div>
				</a>
			</div>
		<?php endif; ?>
		<?php if ( $prev_post ) : ?>
			<div <?php arts_print_attributes( $prev_col_attributes ); ?>>
				<a <?php arts_print_attributes( $prev_link_attributes ); ?>>
					<?php if ( $prev_image_id ) : ?>
						<div class="background-hover__image">
							<?php
							get_template_part(
								'template-parts/lazy/lazy',
								'image',
								array(
									'id'   => $prev_image_id,
									'type' => 'background',
								)
							);
							?>
						</div>
					<?php endif; ?>
					<div class="background-hover__overlay overlay overlay_dark-60"></div>
					<div class="background-hover__content w-100">
						<span class="small"><?php echo esc_html( $prev_label ); ?></span>
						<div class="w-100"></div>
						<h2 class="h4 underline-hover__target"><?php echo esc_html( $prev_title ); ?></h2>
					</div>
				</a>
			</div>
		<?php endif; ?>
	</div>
</aside>
