<?php

$defaults = array(
	'id'         => get_the_ID(),
	'attributes' => array(
		'class' => array( 'post-meta' ),
	),
	'set'        => array( 'date', 'categories', 'comments', 'author' ),
);

$args = wp_parse_args( $args, $defaults );

$post_meta_set          = $args['set'];
$blog_posts_date_style  = get_theme_mod( 'blog_posts_date_style', 'info' );
$date_link              = get_month_link( get_post_time( 'Y', false, $args['id'] ), get_post_time( 'm', false, $args['id'] ) );
$author                 = arts_get_post_author( $args['id'] );
$post_categories        = wp_get_post_categories( $args['id'] );
$post_categories_amount = count( $post_categories );

?>

<ul <?php arts_print_attributes( $args['attributes'] ); ?>>
	<?php if ( in_array( 'date', $post_meta_set ) && ( $blog_posts_date_style === 'info' || is_single() ) ) : ?>
		<li>
			<a href="<?php echo esc_attr( $date_link ); ?>"><i class="post-meta__icon material-icons">event</i> <span><?php echo esc_html( get_the_date( '', $args['id'] ) ); ?></span></a>
		</li>
	<?php endif; ?>
	<?php if ( in_array( 'categories', $post_meta_set ) && $post_categories_amount > 0 ) : ?>
		<li>
			<?php if ( $post_categories_amount === 1 ) : ?>
				<a href="<?php echo esc_url( get_category_link( $post_categories[0] ) ); ?>"><i class="post-meta__icon material-icons">subject</i><span><?php echo esc_html( get_cat_name( $post_categories[0] ) ); ?></span></a>
			<?php else : ?>
				<i class="post-meta__icon material-icons">subject</i><?php the_category( ',&nbsp;', '', $args['id'] ); ?>
			<?php endif; ?>
		</li>
	<?php endif; ?>
	<?php if ( in_array( 'comments', $post_meta_set ) ) : ?>
		<li>
			<a href="<?php echo get_comments_link( $args['id'] ); ?>">
				<i class="post-meta__icon material-icons">comment</i><span><?php comments_number( esc_html__( 'No Comments', 'kinsey' ), esc_html__( '1 Comment', 'kinsey' ), esc_html__( '% Comments', 'kinsey' ), $args['id'] ); ?></span>
			</a>
		</li>
	<?php endif; ?>
	<?php if ( ! empty( $author['name'] ) && in_array( 'author', $post_meta_set ) ) : ?>
		<li>
			<span><span><?php esc_html_e( 'by', 'kinsey' ); ?>&nbsp;</span></span><a href="<?php echo esc_url( $author['url'] ); ?>"><span><?php echo esc_html( $author['name'] ); ?></span></a>
		</li>
	<?php endif; ?>
</ul>
