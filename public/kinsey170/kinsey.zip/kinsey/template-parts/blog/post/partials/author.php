<?php

$defaults = array(
	'id' => get_the_ID(),
);

$args = wp_parse_args( $args, $defaults );

$author                 = arts_get_post_author( $args['id'] );
$author_date_attributes = array(
	'class' => array( 'author__post-date' ),
);
$author_name_attributes = array(
	'class' => array( 'author__name' ),
);
$post_date              = get_the_date( '', $args['id'] );
$blog_posts_date_style  = get_theme_mod( 'blog_posts_date_style', 'info' );

if ( $blog_posts_date_style === 'info' ) {
	$author_date_attributes['class'][] = 'h5';
	$author_name_attributes['class'][] = 'small';
} else {
	$author_name_attributes['class'][] = 'h5';
}

?>

<div class="author">
	<div class="author__avatar">
		<?php echo get_avatar( $author['id'], 50 ); ?>
	</div>
	<div class="author__content">
		<?php if ( $blog_posts_date_style === 'info' ) : ?>
			<div <?php arts_print_attributes( $author_date_attributes ); ?>><?php echo esc_html( $post_date ); ?></div>
		<?php endif; ?>
		<div <?php arts_print_attributes( $author_name_attributes ); ?>><?php esc_html_e( 'by', 'kinsey' ); ?>&nbsp;<a href="<?php echo esc_url( $author['url'] ); ?>"><?php echo esc_html( $author['name'] ); ?></a></div>
	</div>
</div>
