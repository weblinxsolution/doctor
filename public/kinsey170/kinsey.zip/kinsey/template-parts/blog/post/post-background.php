<?php

/**
 * Posts Preview Style: Fullwidth Backgrounds
 */
$post_show_info      = get_theme_mod( 'post_show_info', true );
$post_meta_set       = get_theme_mod( 'post_meta_set', array( 'date', 'categories', 'comments', 'author' ) );
$post_thumbnail_size = get_theme_mod( 'blog_style_posts_thumbnail', 'full' );
$post_permalink      = get_permalink();
$animation_enabled   = get_theme_mod( 'blog_os_animation_enabled', false );

$post_attributes = array(
	'id'    => 'post-' . get_the_ID(),
	'class' => get_post_class( 'post background-hover py-medium h-100' ),
);

$thumbnail_args = array(
	'id'   => get_post_thumbnail_id(),
	'type' => 'background',
	'size' => $post_thumbnail_size,
);

$info_attributes = array(
	'class' => array( 'mt-2' ),
);

$date_attributes = array(
	'class' => array( 'h5', 'mt-md-1', 'mb-md-1', 'mb-2' ),
);

$link_heading_attributes = array(
	'class'           => array( 'd-inline-block', 'underline-hover' ),
	'href'            => $post_permalink,
	'data-arts-hover' => 'trigger',
);

$link_heading_attributes = arts_get_cursor_attributes_theme_mod( $link_heading_attributes, 'blog_home_cursor_clickable_links' );

$container_attributes = array(
	'class' => array( 'container', 'background-hover__content' ),
);

if ( $animation_enabled ) {
	$container_attributes = arts_get_animation_attributes( $container_attributes, 'animateJump' );
}

?>

<article <?php arts_print_attributes( $post_attributes ); ?>>
	<div class="background-hover__image list-backgrounds__wrapper-img">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php get_template_part( 'template-parts/lazy/lazy', 'image', $thumbnail_args ); ?>
		<?php endif; ?>
	</div>

	<div class="list-backgrounds__overlay background-hover__overlay overlay overlay_dark-60"></div>

	<div <?php arts_print_attributes( $container_attributes ); ?>>
		<div class="row align-items-center">
			<div class="col-lg-4">
				<div <?php arts_print_attributes( $date_attributes ); ?>><?php echo esc_html( get_the_date() ); ?></div>
			</div>
			<div class="col-lg-8">
				<a <?php arts_print_attributes( $link_heading_attributes ); ?>>
					<h2 class="h3 my-0 underline-hover__target"><?php the_title(); ?></h2>
				</a>
				<?php if ( $post_show_info ) : ?>
					<div <?php arts_print_attributes( $info_attributes ); ?>>
						<?php get_template_part( 'template-parts/blog/post/partials/meta', 'categories' ); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</article>
