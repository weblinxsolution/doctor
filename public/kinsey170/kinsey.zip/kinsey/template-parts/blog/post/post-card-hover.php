<?php

/**
 * Posts Preview Style: Cards Hover
 */
$post_show_info      = get_theme_mod( 'post_show_info', true );
$post_meta_set       = get_theme_mod( 'post_meta_set', array( 'date', 'categories', 'comments', 'author' ) );
$post_thumbnail_size = get_theme_mod( 'blog_style_posts_thumbnail', 'full' );
$post_permalink      = get_permalink();

$post_attributes = array(
	'id'    => 'post-' . get_the_ID(),
	'class' => get_post_class( 'post figure-post figure-post_card background-hover p-xsmall h-100' ),
);

$post_attributes = arts_get_animation_attributes(
	$post_attributes,
	'animateJump',
	array(
		'direction' => 'up',
		'y'         => '33%',
		'scaleY'    => 1.5,
	)
);

$thumbnail_args = array(
	'id'   => get_post_thumbnail_id(),
	'type' => 'background',
	'size' => $post_thumbnail_size,
);

$link_heading_attributes = array(
	'class' => array( 'underline-hover' ),
	'href'  => $post_permalink,
);

$link_heading_attributes = arts_get_cursor_attributes_theme_mod( $link_heading_attributes, 'blog_home_cursor_clickable_links' );

?>

<article <?php arts_print_attributes( $post_attributes ); ?>>
	<div class="background-hover__image">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php get_template_part( 'template-parts/lazy/lazy', 'image', $thumbnail_args ); ?>
		<?php endif; ?>
	</div>
	<div class="background-hover__overlay overlay overlay_dark-60"></div>
	<div class="background-hover__content figure-post__content figure-post__content_card">
		<div class="figure-post__wrapper-info small">
			<?php get_template_part( 'template-parts/blog/post/partials/author' ); ?>
		</div>
		<div class="figure-post__header py-medium">
			<a <?php arts_print_attributes( $link_heading_attributes ); ?>>
				<h2 class="figure-post__heading h3 my-0 underline-hover__target"><?php the_title(); ?></h2>
			</a>
		</div>
		<?php if ( $post_show_info ) : ?>
			<div class="figure-post__wrapper-info small">
				<?php
				get_template_part(
					'template-parts/blog/post/partials/meta',
					'',
					array(
						'attributes' => array(
							'class' => array( 'post-meta', 'post-meta_flex' ),
						),
						'set'        => array( 'categories', 'comments' ),
					)
				);
				?>
			</div>
		<?php endif; ?>
	</div>
</article>
