<?php

/**
 * Posts Preview Style: Meta Left Column
 */

$post_permalink  = get_permalink();
$post_attributes = array(
	'id'                    => 'post-' . get_the_ID(),
	'class'                 => get_post_class( 'post figure-post' ),
	'data-arts-hover-class' => array( 'hover-zoom-underline', 'underline-hover' ),
);

$blog_read_more_enabled = get_theme_mod( 'blog_read_more_enabled', true );
$blog_read_more_label   = get_theme_mod( 'blog_read_more_label', __( 'Read More', 'kinsey' ) );
$blog_posts_date_style  = get_theme_mod( 'blog_posts_date_style', 'info' );
$post_show_info         = get_theme_mod( 'post_show_info', true );
$post_meta_set          = get_theme_mod( 'post_meta_set', array( 'date', 'categories', 'comments', 'author' ) );
$post_thumbnail_size    = get_theme_mod( 'blog_style_posts_thumbnail', 'large' );

$thumbnail_args = array(
	'id'    => get_post_thumbnail_id(),
	'type'  => 'image',
	'size'  => $post_thumbnail_size,
	'outer' => array(
		'class' => array( 'js-transition-img', 'overflow' ),
	),
	'image' => array(
		'class' => array( 'js-transition-img__transformed-el' ),
	),
);

$link_media_attributes = array(
	'class'           => array( 'figure-post__media-link' ),
	'href'            => $post_permalink,
	'data-arts-hover' => 'trigger',
);

$link_heading_attributes = array(
	'class'           => array( 'underline-hover__target' ),
	'href'            => $post_permalink,
	'data-arts-hover' => 'trigger',
);

$button_args = array(
	'title'       => $blog_read_more_label,
	'title_hover' => $blog_read_more_label,
	'icon'        => array(
		'after' => 'knz-arrow-right',
	),
	'attributes'  => array(
		'href'            => $post_permalink,
		'class'           => array( 'button', 'button_bordered', 'bg-dark-2' ),
		'data-arts-hover' => 'trigger',
	),
);

$link_media_attributes   = arts_get_cursor_attributes_theme_mod( $link_media_attributes, 'blog_home_cursor_clickable_links' );
$link_heading_attributes = arts_get_cursor_attributes_theme_mod( $link_heading_attributes, 'blog_home_cursor_clickable_links' );

?>

<article <?php arts_print_attributes( $post_attributes ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<!-- post media -->
		<div class="figure-post__media mb-4">
			<a <?php arts_print_attributes( $link_media_attributes ); ?>>
				<?php get_template_part( 'template-parts/lazy/lazy', 'image', $thumbnail_args ); ?>
			</a>
			<?php if ( $post_show_info && in_array( 'date', $post_meta_set ) && $blog_posts_date_style === 'square_box' ) : ?>
				<?php
					$date_full  = get_the_date( DATE_W3C );
					$date_day   = get_the_date( 'd' );
					$date_month = get_the_date( 'M' );
				?>
				<!-- post date -->
				<time class="figure-post__date" datetime="<?php echo esc_html( $date_full ); ?>">
					<span class="figure-post__date-day h3"><?php echo esc_html( $date_day ); ?></span>
					<span class="figure-post__date-month small mt-1"><?php echo esc_html( $date_month ); ?></span>
				</time>
				<!-- - post date -->
			<?php endif; ?>
		</div>
		<!-- - post media -->
		<div class="w-100"></div>
	<?php endif; ?>

	<div class="row">
		<?php if ( $post_show_info ) : ?>
			<div class="col-lg-4">
				<!-- post info & author -->
				<div class="figure-post__wrapper-info my-2 small">
					<?php get_template_part( 'template-parts/blog/post/partials/author' ); ?>
					<?php
					get_template_part(
						'template-parts/blog/post/partials/meta',
						'',
						array(
							'attributes' => array(
								'class' => array( 'post-meta', 'post-meta_block' ),
							),
							'set'        => array( 'categories', 'comments' ),
						)
					);
					?>
				</div>
				<!-- - post info & author -->
			</div>
		<?php endif; ?>

		<div class="col-lg-8">
			<div class="figure-post__header mt-1">
				<h2 class="figure-post__heading h3 mt-2">
					<a <?php arts_print_attributes( $link_heading_attributes ); ?>><?php the_title(); ?></a>
				</h2>
				<div class="figure-post__content mt-1">
					<p><?php get_template_part( 'template-parts/blog/post/content/content', get_post_format() ); ?></p>
				</div>
			</div>

			<div class="figure-post__wrapper-readmore mt-4">
				<?php if ( $blog_read_more_enabled ) : ?>
					<!-- post "read more" button -->
					<div class="figure-post__wrapper-readmore mt-4">
						<?php get_template_part( 'template-parts/button/button', 'normal', $button_args ); ?>
					</div>
					<!-- - post "read more" button -->
				<?php endif; ?>
			</div>
		</div>
	</div>
</article>
