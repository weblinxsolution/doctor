<?php

/**
 * Content Post Type: Image
 */

the_content();
