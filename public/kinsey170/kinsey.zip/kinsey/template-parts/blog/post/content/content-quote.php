<?php

/**
 * Content Post Type: Quote
 */

the_content();
