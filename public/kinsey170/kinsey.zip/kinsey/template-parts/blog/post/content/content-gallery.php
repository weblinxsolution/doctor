<?php

/**
 * Content Post Type: Gallery
 */

if ( ! is_single() ) {
	// If not a single post, highlight the gallery.
	if ( get_post_gallery() ) : ?>
		<div class="post__gallery">
			<?php echo wp_kses( get_post_gallery(), wp_kses_allowed_html( 'post' ) ); ?>
		</div>
	<?php endif; ?>
	<?php
}
