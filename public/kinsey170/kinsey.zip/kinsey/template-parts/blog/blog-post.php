<?php

$sidebar_position                  = get_theme_mod( 'sidebar_position', 'right_side' );
$is_active_sidebar                 = is_active_sidebar( 'blog-sidebar' );
$blog_single_post_container        = get_theme_mod( 'blog_single_post_container', 'container' );
$blog_single_post_layout           = get_theme_mod( 'blog_single_post_layout', 'guttered' );
$has_post_thumbnail                = has_post_thumbnail();
$post_image_layout                 = get_theme_mod( 'post_image_layout', 'responsive' );
$post_image_masthead_fixed_enabled = get_theme_mod( 'post_image_masthead_fixed_enabled', true );
$is_fullscreen_layout              = $post_image_layout === 'fullscreen';
$is_fixed_effect_enabled           = $is_fullscreen_layout && $post_image_masthead_fixed_enabled;
$post_prev_next_nav_enabled        = get_theme_mod( 'post_prev_next_nav_enabled', false );

$section_attributes = array(
	'class' => array( 'section', 'section-blog', 'section-content' ),
);

$inner_attributes = array(
	'class' => array( 'section-blog__inner', 'bg-white-1' ),
);

$container_attributes = array(
	'class' => array( 'section-blog__container', 'pb-large', $blog_single_post_container ),
);

$row_attributes = array(
	'class' => array( 'section-blog__row', 'text-start', 'row', 'overflow' ),
);

$col_posts_attributes = array(
	'class' => array( 'section-blog__posts' ),
);

$col_sidebar_attributes = array(
	'class' => array( 'section-blog__sidebar', 'col-lg-3' ),
);

if ( $blog_single_post_layout === 'guttered' ) {
	$section_attributes['class'][] = 'container-fluid';
	$section_attributes['class'][] = 'container_p-md-0';

	if ( ! $is_fixed_effect_enabled && ! $post_prev_next_nav_enabled ) {
		$section_attributes['class'][] = 'mb-large';
	}
}

if ( $sidebar_position === 'right_side' ) {
	$col_posts_attributes['class'][]   = 'order-lg-1';
	$col_sidebar_attributes['class'][] = 'order-lg-2';
} else {
	$col_posts_attributes['class'][]   = 'order-lg-2';
	$col_sidebar_attributes['class'][] = 'order-lg-1';
}

if ( $is_active_sidebar ) {
	$row_attributes['class'][]       = 'justify-content-between';
	$col_posts_attributes['class'][] = 'col-lg-8';
} else {
	$row_attributes['class'][] = 'justify-content-center';

	$col_posts_attributes['class'][] = 'col-lg-8';
}

if ( $has_post_thumbnail ) {
	if ( $is_fullscreen_layout ) {
		$container_attributes['class'][] = 'pt-large';
	} else {
		$container_attributes['class'][] = 'pt-medium';
	}
} else {

	if ( $blog_single_post_layout === 'guttered' ) {
		$container_attributes['class'][] = 'pt-large';
	}
}

if ( $is_fixed_effect_enabled ) {
	$section_attributes['class'][]                      = 'section-offset';
	$section_attributes['class'][]                      = 'pb-large';
	$section_attributes['class'][]                      = 'offset_top';
	$section_attributes['data-arts-os-animation-start'] = 'top-=100% bottom';
	$inner_attributes['class'][]                        = 'section-offset__content';

	if ( $blog_single_post_layout === 'fullwidth' ) {
		$section_attributes['class'][] = 'mb-minus-large';
	}
}

?>

<!-- section BLOG -->
<section <?php arts_print_attributes( $section_attributes ); ?>>
	<div <?php arts_print_attributes( $inner_attributes ); ?>>
		<div <?php arts_print_attributes( $container_attributes ); ?>>
			<div <?php arts_print_attributes( $row_attributes ); ?>>
				<div <?php arts_print_attributes( $col_posts_attributes ); ?>>
					<?php the_post(); ?>
					<!-- single post -->
					<?php get_template_part( 'template-parts/blog/post/post', 'single' ); ?>
					<!-- - single post -->
				</div>
				<?php if ( $is_active_sidebar ) : ?>
					<div <?php arts_print_attributes( $col_sidebar_attributes ); ?>>
						<?php get_sidebar(); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php if ( $post_prev_next_nav_enabled ) : ?>
			<!-- prev & next posts navigation -->
			<?php get_template_part( 'template-parts/blog/post/partials/prev_next' ); ?>
			<!-- - prev & next posts navigation -->
		<?php endif; ?>
	</div>
</section>
<!-- - section BLOG -->
