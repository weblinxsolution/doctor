<?php

$footer_container = get_theme_mod( 'footer_container', 'container' );

$widget_area_top_id    = 'footer-sidebar-top';
$widget_area_middle_id = 'footer-sidebar-middle';
$widget_area_bottom_id = 'footer-sidebar-bottom';

$has_widgets_top    = is_active_sidebar( $widget_area_top_id );
$has_widgets_middle = is_active_sidebar( $widget_area_middle_id );
$has_widgets_bottom = is_active_sidebar( $widget_area_bottom_id );

$container_attributes = array(
	'class' => array( 'footer__container', $footer_container ),
);

?>

<div class="footer__inner">
	<div <?php arts_print_attributes( $container_attributes ); ?>>
		<?php if ( $has_widgets_top ) : ?>
			<!-- widget area TOP -->
			<div class="footer__widget-area footer__widget-area_top">
				<?php dynamic_sidebar( $widget_area_top_id ); ?>
			</div>
			<!-- - widget area TOP -->
		<?php endif; ?>
		<?php if ( $has_widgets_middle ) : ?>
			<!-- widget area MIDDLE -->
			<div class="footer__widget-area footer__widget-area_middle">
				<div class="footer__divider"></div>
				<?php dynamic_sidebar( $widget_area_middle_id ); ?>
			</div>
			<!-- - widget area MIDDLE -->
		<?php endif; ?>
		<?php if ( $has_widgets_bottom ) : ?>
			<!-- widget area BOTTOM -->
			<div class="footer__widget-area footer__widget-area_bottom align-items-center">
				<div class="footer__divider"></div>
				<?php dynamic_sidebar( $widget_area_bottom_id ); ?>
			</div>
			<!-- - widget area BOTTOM -->
			<?php endif; ?>
	</div>
</div>

