<?php

global $post;

$titles                          = arts_get_page_titles();
$page_title                      = $titles[0];
$page_subtitle                   = $titles[1];
$page_description                = $titles[2];
$ajax_enabled                    = get_theme_mod( 'ajax_enabled', false );
$page_masthead_animation_enabled = arts_get_document_option( 'page_masthead_animation_enabled', 'yes' );
$categories                      = arts_get_taxonomy_term_names( $post->ID, 'arts_portfolio_category' );
$years                           = arts_get_taxonomy_term_names( $post->ID, 'arts_portfolio_year' );
$has_properties                  = arts_have_rows( 'properties' );
$has_buttons                     = arts_have_rows( 'buttons' );
$has_content                     = $has_properties || ! empty( $page_description ) || $has_buttons;
$featured_video                  = arts_get_field( 'featured_video' );

$page_masthead_header_alignment      = arts_get_document_option( 'page_masthead_header_alignment', 'text-center' );
$page_masthead_header_container      = arts_get_document_option( 'page_masthead_header_container', 'container-fluid' );
$page_masthead_header_elements_theme = arts_get_document_option( 'page_masthead_header_elements_theme', 'dark' );

$page_masthead_content_alignment = arts_get_document_option( 'page_masthead_content_alignment', 'text-center' );
$page_masthead_content_container = arts_get_document_option( 'page_masthead_content_container', 'container' );

$page_masthead_image_container           = arts_get_document_option( 'page_masthead_image_container', 'container' );
$page_masthead_image_placement           = arts_get_document_option( 'page_masthead_image_placement', 'image_limited' );
$page_masthead_image_parallax_enabled    = arts_get_document_option( 'page_masthead_image_parallax_enabled', 'yes' );
$page_masthead_image_parallax_speed_x    = arts_get_document_option( 'page_masthead_image_parallax_speed_x', array( 'size' => 0.0 ) );
$page_masthead_image_parallax_speed_y    = arts_get_document_option( 'page_masthead_image_parallax_speed_y', array( 'size' => 0.1 ) );
$page_masthead_image_parallax_scale_from = arts_get_document_option( 'page_masthead_image_parallax_scale_from', array( 'size' => 1.0 ) );
$page_masthead_image_parallax_scale_to   = arts_get_document_option( 'page_masthead_image_parallax_scale_to', array( 'size' => 1.0 ) );

$page_masthead_featured_video_enabled  = arts_get_document_option( 'page_masthead_featured_video_enabled', 'yes' );
$page_masthead_featured_elements_theme = arts_get_document_option( 'page_masthead_featured_elements_theme', 'dark' );

$page_masthead_heading_preset            = arts_get_document_option( 'page_masthead_heading_preset', 'xl' );
$page_masthead_category_preset           = arts_get_document_option( 'page_masthead_category_preset', 'small' );
$page_masthead_subheading_preset         = arts_get_document_option( 'page_masthead_subheading_preset', 'h6' );
$page_masthead_text_preset               = arts_get_document_option( 'page_masthead_text_preset', 'h3' );
$page_masthead_properties_name_preset    = arts_get_document_option( 'page_masthead_properties_name_preset', 'small' );
$page_masthead_properties_value_preset   = arts_get_document_option( 'page_masthead_properties_value_preset', 'h4' );
$page_masthead_featured_background_color = arts_get_document_option( 'page_masthead_featured_background_color', '#f8f8f8' );

$page_masthead_pt = arts_get_document_option( 'page_masthead_pt', 'pt-xlarge' );
$page_masthead_pb = arts_get_document_option( 'page_masthead_pb', 'pb-large' );
$page_masthead_mt = arts_get_document_option( 'page_masthead_mt', '' );
$page_masthead_mb = arts_get_document_option( 'page_masthead_mb', '' );

$page_masthead_subheading_enabled       = arts_get_document_option( 'page_masthead_subheading_enabled', 'yes' );
$page_masthead_categories_years_enabled = arts_get_document_option( 'page_masthead_categories_years_enabled', 'yes' );
$page_masthead_description_enabled      = arts_get_document_option( 'page_masthead_description_enabled', 'yes' );
$page_masthead_properties_enabled       = arts_get_document_option( 'page_masthead_properties_enabled', 'yes' );

$has_post_thumbnail = has_post_thumbnail() || ( $page_masthead_featured_video_enabled && $featured_video );

$section_attributes = array(
	'class' => array( 'section', 'section-masthead', 'section-masthead_post-' . $post->ID, $page_masthead_mt, $page_masthead_mb, $page_masthead_pt, $page_masthead_pb ),
);

$thumbnail_args = array(
	'id'         => get_post_thumbnail_id(),
	'video'      => array(
		'attributes' => array(
			'autoplay' => true,
		),
	),
	'type'       => 'background',
	'outer'      => array(
		'class' => array( 'section-masthead__background', 'section-masthead__background_fullscreen' ),
	),
	'overlay'    => array(
		'class' => array( 'overlay', 'z-0', 'section-masthead__overlay' ),
	),
	'parallax'   => array(
		'enabled' => $page_masthead_image_parallax_enabled,
		'factor'  => array(
			'x' => $page_masthead_image_parallax_speed_x['size'],
			'y' => $page_masthead_image_parallax_speed_y['size'],
		),
		'scale'   => array(
			'from' => $page_masthead_image_parallax_scale_from['size'],
			'to'   => $page_masthead_image_parallax_scale_to['size'],
		),
	),
	'animations' => array(),
);

$properties_args = array(
	'name'  => array(
		'class' => array( 'list-dots__name', $page_masthead_properties_name_preset ),
	),
	'value' => array(
		'class' => array( 'list-dots__value', $page_masthead_properties_value_preset ),
	),
);

if ( $page_masthead_featured_video_enabled ) {
	$thumbnail_args['video']['src'] = $featured_video;
}

$categories_args = array(
	'categories' => $categories,
	'years'      => $years,
	'divider'    => array(
		'class' => array( 'section-masthead__meta-divider', 'post-meta__divider' ),
	),
);

$header_attributes = array(
	'class'                => array( 'section-masthead__header', $page_masthead_header_alignment, $page_masthead_header_container ),
	'data-arts-theme-text' => $page_masthead_header_elements_theme,
);

$content_attributes = array(
	'class'                => array( 'section-masthead__wrapper-content', $page_masthead_content_alignment ),
	'data-arts-theme-text' => $page_masthead_featured_elements_theme,
);

$info_attributes = array(
	'class' => array( 'section-masthead__info', $page_masthead_content_container ),
);

$heading_attributes = array(
	'class' => array( 'section-masthead__heading', 'my-0', 'entry-title', $page_masthead_heading_preset ),
);

$heading_attributes = arts_get_split_text_attributes(
	$heading_attributes,
	array(
		'by'        => 'lines,words,chars',
		'set'       => $page_masthead_animation_enabled ? 'chars' : false,
		'overflow'  => 'lines',
		'animation' => false,
	)
);

$subheading_attributes = array(
	'class' => array( 'section-masthead__subheading', 'mt-0', $page_masthead_subheading_preset ),
);

$category_attributes = array(
	'class' => array( 'section-masthead__category', 'mt-xsmall', $page_masthead_category_preset ),
);

$text_attributes = array(
	'class' => array( 'section-masthead__text', 'my-0', $page_masthead_text_preset ),
);

$properties_attributes = array(
	'class' => array(),
);

$background_attributes = array(
	'class' => array( 'section-masthead__bg', 'section__bg', 'top-offset', 'top-offset_large' ),
);

$wrapper_image_attributes = array(
	'class' => array( 'section-masthead__wrapper-image', 'text-center', $page_masthead_image_container ),
);

$wrapper_content_attributes = array(
	'class' => array( 'section-masthead__content', 'mt-small' ),
);

$wrapper_properties_attributes = array(
	'class' => array( 'section-masthead__properties', 'mt-small' ),
);

$wrapper_button_attributes = array(
	'class' => array( 'section-masthead__button', 'mt-xsmall', 'row', 'justify-content-center' ),
);

if ( $ajax_enabled ) {
	$heading_attributes['class'][]      = 'js-transition-heading';
	$thumbnail_args['outer']['class'][] = 'js-transition-img';
	$thumbnail_args['inner']['class'][] = 'js-transition-img__transformed-el';
	$background_attributes['class'][]   = 'js-transition-bg';
}

if ( $page_masthead_animation_enabled ) {
	$section_attributes['data-arts-os-animation'] = 'true';

	$subheading_attributes = arts_get_split_text_attributes(
		$subheading_attributes,
		array(
			'by'        => 'lines,words',
			'set'       => 'words',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);

	$category_attributes = arts_get_split_text_attributes(
		$category_attributes,
		array(
			'by'        => 'lines,words',
			'set'       => 'words',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);

	$text_attributes = arts_get_split_text_attributes(
		$text_attributes,
		array(
			'by'        => 'lines',
			'set'       => 'lines',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);

	$properties_attributes = arts_get_split_text_attributes(
		$properties_attributes,
		array(
			'by'       => 'words',
			'set'      => 'words',
			'overflow' => 'words',
		)
	);

	$thumbnail_args['animations']['animateMask'] = array(
		'enabled' => false,
		'outer'   => array(
			'class' => array( 'mask-reveal' ),
		),
	);

	$wrapper_content_attributes    = arts_get_animation_attributes( $wrapper_content_attributes, 'animateText' );
	$wrapper_properties_attributes = arts_get_animation_attributes( $wrapper_properties_attributes, 'animateText' );
	$wrapper_button_attributes     = arts_get_animation_attributes( $wrapper_button_attributes, 'animateJump' );
} else {
	$background_attributes['class'][] = 'js-transition-animated';
}

?>

<section <?php arts_print_attributes( $section_attributes ); ?>>
	<div class="section-masthead__inner">
		<div <?php arts_print_attributes( $header_attributes ); ?>>
			<?php if ( ! empty( $page_subtitle ) && $page_masthead_subheading_enabled ) : ?>
				<h2 <?php arts_print_attributes( $subheading_attributes ); ?>><?php echo wp_kses( $page_subtitle, wp_kses_allowed_html( 'post' ) ); ?></h2>
			<?php endif; ?>
			<?php if ( ! empty( $page_title ) ) : ?>
				<h1 <?php arts_print_attributes( $heading_attributes ); ?>><?php echo esc_html( $page_title ); ?></h1>
			<?php endif; ?>
			<?php if ( ! empty( $categories ) || ! empty( $years ) && $page_masthead_categories_years_enabled ) : ?>
				<div <?php arts_print_attributes( $category_attributes ); ?>><?php get_template_part( 'template-parts/list/list', 'categories', $categories_args ); ?></div>
			<?php endif; ?>
		</div>

		<?php if ( $has_content ) : ?>
			<div class="section__content mt-small">
				<div <?php arts_print_attributes( $content_attributes ); ?>>
					<?php if ( $has_content ) : ?>
					<!-- intro content -->
					<div <?php arts_print_attributes( $info_attributes ); ?>>
						<?php if ( $has_properties && $page_masthead_properties_enabled ) : ?>
							<!-- properties -->
							<div <?php arts_print_attributes( $wrapper_properties_attributes ); ?>>
								<div <?php arts_print_attributes( $properties_attributes ); ?>>
									<?php get_template_part( 'template-parts/list/list', 'properties', $properties_args ); ?>
								</div>
							</div>
							<!-- - properties -->
						<?php endif; ?>

						<?php if ( ! empty( $page_description && $page_masthead_description_enabled ) ) : ?>
							<!-- description -->
							<div <?php arts_print_attributes( $wrapper_content_attributes ); ?>>
								<p <?php arts_print_attributes( $text_attributes ); ?>><?php echo wp_kses( $page_description, wp_kses_allowed_html( 'post' ) ); ?></p>
							</div>
							<!-- - description -->
						<?php endif; ?>

						<?php if ( $has_buttons ) : ?>
						<!-- button(s) -->
						<div <?php arts_print_attributes( $wrapper_button_attributes ); ?>>
							<?php while ( have_rows( 'buttons' ) ) : ?>
								<?php the_row(); ?>
								<?php $button = get_sub_field( 'button' ); ?>
								<?php if ( $button && is_array( $button ) ) : ?>
									<?php
									$button = array_merge( $button, get_sub_field( 'button_appearance' ), get_sub_field( 'button_cursor' ) );
									$button = arts_get_button_attributes( array( 'class' => array( 'button' ) ), $button );
									?>
									<div class="col-auto"><?php get_template_part( 'template-parts/button/button', 'normal', $button ); ?></div>
								<?php endif; ?>
							<?php endwhile; ?>
						</div>
						<!-- - button(s) -->
						<?php endif; ?>
					</div>
					<!-- - intro content -->
					<?php endif; ?>
				</div>
				<?php if ( $page_masthead_featured_background_color ) : ?>
					<div <?php arts_print_attributes( $background_attributes ); ?>></div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>

	<?php if ( $has_post_thumbnail ) : ?>
		<?php get_template_part( 'template-parts/lazy/lazy', 'image', $thumbnail_args ); ?>
	<?php endif; ?>
</section>
