<?php

global $post;

$page_title                                    = get_the_title();
$post_image_layout                             = get_theme_mod( 'post_image_layout', 'responsive' );
$post_show_info                                = get_theme_mod( 'post_show_info', true );
$post_meta_set                                 = get_theme_mod( 'post_meta_set', array( 'date', 'categories', 'comments', 'author' ) );
$post_image_masthead_fixed_enabled             = get_theme_mod( 'post_image_masthead_fixed_enabled', true );
$post_image_masthead_force_light_theme_enabled = get_theme_mod( 'post_image_masthead_force_light_theme_enabled', true );
$post_image_parallax_enabled                   = get_theme_mod( 'post_image_parallax_enabled', false );
$post_image_parallax_speed                     = get_theme_mod( 'post_image_parallax_speed', 0.15 );
$blog_single_post_container                    = get_theme_mod( 'blog_single_post_container', 'container' );
$blog_single_post_layout                       = get_theme_mod( 'blog_single_post_layout', 'guttered' );
$has_post_thumbnail                            = has_post_thumbnail();
$animation_enabled                             = get_theme_mod( 'blog_os_animation_enabled', false );
$ajax_enabled                                  = get_theme_mod( 'ajax_enabled', false );
$is_fullscreen_layout                          = $post_image_layout === 'fullscreen';
$is_fixed_effect_enabled                       = $is_fullscreen_layout && $post_image_masthead_fixed_enabled;

$section_attributes = array(
	'class' => array( 'section', 'section-masthead', 'section-masthead_post-' . $post->ID, 'text-center' ),
);

$section_inner_attributes = array(
	'class' => array( 'section-masthead__inner', 'container-fluid' ),
);

$image_wrapper_attributes = array(
	'class' => array(),
);

$heading_attributes = array(
	'class' => array( 'section-masthead__heading', 'd-inline-block', 'my-0', 'xl' ),
);

$subheading_attributes = array(
	'class' => array( 'section-masthead__category', 'mb-3', 'small' ),
);

$thumbnail_args = array(
	'id'       => get_post_thumbnail_id(),
	'type'     => $post_image_layout === 'responsive' ? 'image_limited' : 'background',
	'parallax' => array(
		'enabled' => $post_image_parallax_enabled,
		'factor'  => array(
			'y' => $post_image_parallax_speed,
		),
	),
);

$wrapper_scroll_down_attributes = array(
	'class' => array( 'section-masthead__wrapper-scroll-down' ),
);

$scroll_down_icon_attributes = array(
	'class'                 => array( 'section-masthead__scroll-down', 'material-icons' ),
	'data-arts-scroll-down' => 'true',
);

$scroll_down_icon_attributes = arts_get_cursor_attributes(
	$scroll_down_icon_attributes,
	array(
		'data-arts-cursor'             => 'true',
		'data-arts-cursor-hide-native' => 'true',
		'data-arts-cursor-magnetic'    => 'true',
		'data-arts-cursor-scale'       => 1.7,
	)
);

if ( $post_image_layout === 'fullwidth' ) {
	$thumbnail_args['outer']['class'][] = 'section-masthead__single-post-background';
}

if ( $is_fullscreen_layout ) {
	$section_attributes['class'][]       = 'section-fullheight';
	$section_inner_attributes['class'][] = 'section-fullheight__inner';
	$section_inner_attributes['class'][] = 'section-fullheight__inner_mobile';

	$thumbnail_args['outer']['class'][] = 'section-masthead__background';
	$thumbnail_args['outer']['class'][] = 'section-masthead__background_fullscreen';
	$thumbnail_args['overlay']['class'] = array( 'overlay', 'z-0', 'section-masthead__overlay', 'section-masthead__overlay_fullscreen' );

	if ( $post_image_masthead_force_light_theme_enabled ) {
		$section_attributes['class'][]              = 'bg-dark-1';
		$section_attributes['data-arts-theme-text'] = 'light';
	} else {
		$section_attributes['class'][] = 'bg-white-1';
	}
} else {

	$section_attributes['class'][]      = 'pt-xlarge';
	$thumbnail_args['outer']['class'][] = 'section-masthead__wrapper-image';
	$thumbnail_args['outer']['class'][] = 'mt-small';

	if ( $blog_single_post_layout === 'guttered' ) {
		if ( $has_post_thumbnail ) {
			$section_attributes['class'][] = 'pb-medium';
		} else {
			$section_attributes['class'][] = 'pb-large';
		}
	} else {
		$section_attributes['class'][] = 'bg-white-1';
	}
}

if ( $animation_enabled ) {
	$section_attributes['data-arts-os-animation'] = 'true';

	$heading_attributes = arts_get_split_text_attributes(
		$heading_attributes,
		array(
			'by'        => 'lines, words, chars',
			'set'       => 'chars',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);

	$subheading_attributes = arts_get_split_text_attributes(
		$subheading_attributes,
		array(
			'by'        => 'lines, words',
			'set'       => 'words',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);

	$thumbnail_args['animations']['animateMask'] = array(
		'enabled' => false,
		'outer'   => array(
			'class' => array( 'mask-reveal' ),
		),
	);
}

if ( $ajax_enabled ) {
	$heading_attributes['class'][]      = 'js-transition-heading';
	$thumbnail_args['outer']['class'][] = 'js-transition-img';
	$thumbnail_args['inner']['class'][] = 'js-transition-img__transformed-el';
}

if ( $is_fixed_effect_enabled ) {
	$section_attributes['class'][]                = 'section-masthead_fixed';
	$section_attributes['data-arts-scroll-fixed'] = 'true';
	$wrapper_scroll_down_attributes['class'][]    = 'd-lg-none';
}

?>

<section <?php arts_print_attributes( $section_attributes ); ?>>
	<div <?php arts_print_attributes( $section_inner_attributes ); ?>>
		<?php if ( $post_show_info && ! empty( $post_meta_set ) ) : ?>
			<div <?php arts_print_attributes( $subheading_attributes ); ?>>
				<?php get_template_part( 'template-parts/blog/post/partials/meta', '', array( 'set' => $post_meta_set ) ); ?>
			</div>
		<?php endif; ?>
		<h1 <?php arts_print_attributes( $heading_attributes ); ?>><?php echo wp_kses( $page_title, wp_kses_allowed_html( 'post' ) ); ?></h1>
	</div>
	<?php if ( $has_post_thumbnail ) : ?>
		<?php get_template_part( 'template-parts/lazy/lazy', 'image', $thumbnail_args ); ?>
	<?php endif; ?>

	<?php if ( $is_fullscreen_layout ) : ?>
		<!-- scroll down -->
		<div <?php arts_print_attributes( $wrapper_scroll_down_attributes ); ?>>
			<div <?php arts_print_attributes( $scroll_down_icon_attributes ); ?>>keyboard_arrow_down</div>
		</div>
		<!-- - scroll down -->
	<?php endif; ?>
</section>
