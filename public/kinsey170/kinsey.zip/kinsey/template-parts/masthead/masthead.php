<?php

global $post;

$titles            = arts_get_page_titles();
$page_title        = $titles[0];
$page_subtitle     = $titles[1];
$animation_enabled = get_theme_mod( 'blog_os_animation_enabled', false );
$ajax_enabled      = get_theme_mod( 'ajax_enabled', false );

$section_attributes = array(
	'class' => array( 'section', 'section-masthead', 'section-masthead_post-' . $post->ID, 'text-center', 'pt-xlarge', 'pb-large' ),
);

$heading_attributes = array(
	'class' => array( 'section-masthead__heading', 'd-inline-block', 'my-0', 'xl' ),
);

if ( $animation_enabled ) {
	$section_attributes['data-arts-os-animation'] = 'true';
	$heading_attributes                           = arts_get_split_text_attributes(
		$heading_attributes,
		array(
			'by'        => 'lines, words, chars',
			'set'       => 'chars',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);
}

if ( $ajax_enabled ) {
	$heading_attributes['class'][] = 'js-transition-heading';
}

?>

<section <?php arts_print_attributes( $section_attributes ); ?>>
	<div class="container">
		<h1 <?php arts_print_attributes( $heading_attributes ); ?>><?php echo wp_kses( $page_title, wp_kses_allowed_html( 'post' ) ); ?></h1>
	</div>
</section>
