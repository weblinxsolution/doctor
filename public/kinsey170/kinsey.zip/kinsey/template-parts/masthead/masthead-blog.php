<?php

$titles                   = arts_get_page_titles();
$page_title               = $titles[0];
$page_subtitle            = $titles[1];
$page_description         = $titles[2];
$parallax_enabled         = false;
$animation_enabled        = get_theme_mod( 'blog_os_animation_enabled', false );
$ajax_enabled             = get_theme_mod( 'ajax_enabled', false );
$blog_page_id             = get_option( 'page_for_posts' );
$has_post_thumbnail       = is_home() && has_post_thumbnail( $blog_page_id );
$blog_grid_filter_enabled = arts_blog_filter_is_active();
$blog_layout              = get_theme_mod( 'blog_layout', 'guttered' );

$section_attributes = array(
	'class' => array( 'section', 'section-masthead', 'text-center', 'pt-xlarge' ),
);

$heading_attributes = array(
	'class' => array( 'section-masthead__heading', 'd-inline-block', 'my-0', 'xl' ),
);

$subheading_attributes = array();

if ( $ajax_enabled ) {
	$heading_attributes['class'][] = 'js-transition-heading';
}

$text_attributes = array(
	'class' => array( 'section-masthead__text', 'paragraph' ),
);

$wrapper_content_attributes = array(
	'class' => array( 'section-masthead__content', 'mt-3' ),
);

$thumbnail_args = array(
	'id'         => get_post_thumbnail_id( $blog_page_id ),
	'parallax'   => array(
		'enabled' => $parallax_enabled,
		'factor'  => array(
			'y' => 0.15,
		),
	),
	'animations' => array(),
);

if ( $animation_enabled ) {
	$section_attributes['data-arts-os-animation'] = 'true';

	$heading_attributes = arts_get_split_text_attributes(
		$heading_attributes,
		array(
			'by'        => 'lines, words, chars',
			'set'       => 'chars',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);

	$subheading_attributes = arts_get_split_text_attributes(
		$subheading_attributes,
		array(
			'by'        => 'lines, words',
			'set'       => 'words',
			'overflow'  => 'lines',
			'animation' => false,
		)
	);

	$text_attributes = arts_get_split_text_attributes(
		$text_attributes,
		array(
			'by'        => 'lines',
			'set'       => 'lines',
			'overflow'  => 'lines',
			'animation' => true,
		)
	);

	$thumbnail_args['animations']['animateMask'] = array(
		'enabled' => false,
		'outer'   => array(
			'class' => array( 'mask-reveal' ),
		),
	);
}

if ( $has_post_thumbnail ) {
	$section_attributes['class'][] = 'pb-medium';
} else {

	if ( $blog_grid_filter_enabled ) {
		$section_attributes['class'][] = 'pb-small';
	} else {
		$section_attributes['class'][] = 'pb-large';
	}
}

if ( $blog_layout === 'fullwidth' ) {
	$section_attributes['class'][] = 'bg-white-1';
}

?>

<section <?php arts_print_attributes( $section_attributes ); ?>>
	<div class="container-fluid">
		<h1 <?php arts_print_attributes( $heading_attributes ); ?>><?php echo wp_kses( $page_title, wp_kses_allowed_html( 'post' ) ); ?></h1>
		<?php if ( ! empty( $page_description ) ) : ?>
			<div <?php arts_print_attributes( $wrapper_content_attributes ); ?>>
				<!-- Archive description -->
				<div <?php arts_print_attributes( $text_attributes ); ?>><?php echo wp_kses( $page_description, wp_kses_allowed_html( 'post' ) ); ?></div>
				<!-- - Archive description -->
			</div>
		<?php endif; ?>
	</div>
	<?php if ( $has_post_thumbnail ) : ?>
		<div class="section-masthead__wrapper-image mt-small">
			<?php get_template_part( 'template-parts/lazy/lazy', 'image', $thumbnail_args ); ?>
		</div>
	<?php endif; ?>
</section>
